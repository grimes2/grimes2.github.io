#include "stdafx.h"

#include <wininet.h>


DECLARE_COMPONENT_VERSION(
	"Bandsintown",
	"0.2",
	"Bandsintown v0.2\n"
	"Created by grimes\n"
	"Build: " __DATE__ " " __TIME__ "\n\n"
	"Mainmenu command:\n"
	"Menu | Help | Bandsintown\n"
);

VALIDATE_COMPONENT_FILENAME("foo_bandsintown.dll");


pfc::string8 tag1;
pfc::string8 a_artist;
HINTERNET hINet, hFile;
char buffer[19000];

std::wstring s2ws(const std::string& s)
{
    int len;
	int slength = (int)s.length() + 1;
	len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
	wchar_t* buf = new wchar_t[len];
	MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
	std::wstring r(buf);
	delete[] buf;
	return r;
}

// {816A63F3-BC29-405B-A10F-0D247D79C07B}
static const GUID guid_cfg_menu_bandsintown  = { 0x816a63f3, 0xbc29, 0x405b, { 0xa1, 0xf, 0xd, 0x24, 0x7d, 0x79, 0xc0, 0x7b } };


class mainmenu_commands_bandsintown : public mainmenu_commands
{

	public:

		// Return the number of commands we provide.
		virtual t_uint32 get_command_count()
		{
			return 1;
		}

		// All commands are identified by a GUID.
		virtual GUID get_command(t_uint32 p_index)
		{
			// {BB4D0821-1765-4332-B5AB-B784B9A711EA}
			static const GUID guid_main_bandsintown_toggle = { 0xbb4d0821, 0x1765, 0x4332, { 0xb5, 0xab, 0xb7, 0x84, 0xb9, 0xa7, 0x11, 0xea } };

			if (p_index == 0)
				return guid_main_bandsintown_toggle;
			return pfc::guid_null;
		}

		// Set p_out to the name of the n-th command.
		// This name is used to identify the command and determines
		// the default position of the command in the menu.
		virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
		{
			if (p_index == 0)
				p_out = "Bandsintown";
		}

		// Set p_out to the description for the n-th command.
		virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
		{
			if (p_index == 0)
				p_out = "Bands on Tour";
			else
				return false;
			return true;
		}

		// Every set of commands needs to declare which group it belongs to.
		virtual GUID get_parent()
		{
			return mainmenu_groups::help;
		}

		// Execute n-th command.
		// p_callback is reserved for future use.
		virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
		{
			if (p_index == 0 && core_api::assert_main_thread())
			{
				if (a_artist.length() > 0)
				{
					//console::formatter() << "Bandsintown: " << a_artist;
					hINet = InternetOpen(L"InetURL/1.0", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0 );
					if(hINet == NULL)
					{
						console::info("Open the internet session failed");
					}
					std::string url = "http://api.bandsintown.com/artists/";
					url.append(a_artist);
					url.append("/events.xml?app_id=Foobar2000");
					std::string tempurl;
					if(tempurl.compare(url) != 0)
					{
						std::wstring stemp = s2ws(url);
						LPCWSTR result = stemp.c_str();
						try
						{
							hFile = InternetOpenUrl(hINet, result, NULL, 0, 0, 0) ;
						}
						catch (int e)
						{
							console::formatter() << "Open the required URL failed. Exception No." << e;
						}
						if(hFile)
						{
							DWORD numberofbytesread = 0;
							InternetReadFile(hFile, buffer, 18999, &numberofbytesread);
							buffer[numberofbytesread] = '\0';
							//console::formatter() << buffer;
						}
						// Close the HINTERNET handle.
						InternetCloseHandle(hINet);
						InternetCloseHandle(hFile);
					}
					tempurl = url;
					popup_message::g_show(buffer, a_artist, popup_message::icon_information);
				}
				else
				{
					popup_message::g_show("No artist selected. Start playback to select artist", "Bandsintown", popup_message::icon_error);
					//console::info("Bandsintown: No artist selected. Start playback to select artist");
				}
			}
		}

		virtual t_uint32 get_sort_priority() {return sort_priority_last;}

};

static mainmenu_commands_factory_t<mainmenu_commands_bandsintown> g_mainmenu_commands_bandsintown;


class play_callback_bandsintown : public play_callback_static
{

public:

	virtual unsigned get_flags(void)
	{
		return(flag_on_playback_new_track);
	}

	virtual void on_playback_new_track(metadb_handle_ptr p_track)
	{
		p_track->metadb_lock();

		service_ptr_t<titleformat_object> tagobj1;
		
		static_api_ptr_t<titleformat_compiler> compiler;

		tag1 = "%artist%";
		compiler->compile_safe(tagobj1, tag1);
		
		p_track->format_title(NULL, a_artist, tagobj1, NULL);
		
		p_track->metadb_unlock();

		tagobj1.release();
	}
	virtual void on_playback_stop(play_control::t_stop_reason p_reason) {}
	virtual void on_playback_seek(double p_time) {}
	virtual void on_playback_pause(bool p_state) {}
	virtual void on_playback_starting(play_control::t_track_command p_command, bool p_paused) {}
	virtual void on_playback_edited(metadb_handle_ptr p_track) {}
	virtual void on_playback_dynamic_info(const file_info & info) {}
	virtual void on_playback_dynamic_info_track(const file_info & info) {}
	virtual void on_playback_time(double p_time) {}
	virtual void on_volume_change(float p_new_val) {}
};

static play_callback_static_factory_t<play_callback_bandsintown> g_play_callback_bandsintown;



//EOF