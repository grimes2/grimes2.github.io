#include "stdafx.h"
#include "config.h"

/**************************
Storing settings.

Here settings refer to any information that needs to be
remembered across sessions, like window positions and such.
foobar2000 provides configuration variables to do this,
which come in two different flavors: private and public.
Private configuration variables are derived from cfg_var in
the pfc library; they can only be accessed in the component
that declares them. Public configuration variables are
dervided from config_object; they can be accessed
from any component. Public configuration variables can be
used from any thread, since they have builtin synchronization,
whereas access to private configuration variables has to be
synchronized by the component where necessary.

We won't use threads in this component, and we don't want
our settings to be publicly available, so we will use the
cfg_var subclasses from the SDK.

Note: Variables are internally identified by a GUID you
pass as the first parameter to the constructor. The second
parameter of the contructor is the default value. Some types
of configuration variables have an implicit default value,
so their constructor takes only one parameter.
**************************/

// boolean variable
// Stores whether playback menu command are enabled.

// {1F33969F-FBFB-4780-8C0D-4CD69ABE86B5}
static const GUID guid_cfg_menu_fastforward1_enabled = { 0x1f33969f, 0xfbfb, 0x4780, { 0x8c, 0xd, 0x4c, 0xd6, 0x9a, 0xbe, 0x86, 0xb5 } };
cfg_bool cfg_menu_fastforward1_enabled(guid_cfg_menu_fastforward1_enabled, false);

// {3099C6B3-9E38-4E14-9B61-9D58D6A42AAC}
static const GUID guid_cfg_menu_fastforward2_enabled = { 0x3099c6b3, 0x9e38, 0x4e14, { 0x9b, 0x61, 0x9d, 0x58, 0xd6, 0xa4, 0x2a, 0xac } };
cfg_bool cfg_menu_fastforward2_enabled(guid_cfg_menu_fastforward2_enabled, false);

// {2D3940A2-FCC1-453A-9D97-2D93E217B753}
static const GUID guid_cfg_menu_fastforward3_enabled = { 0x2d3940a2, 0xfcc1, 0x453a, { 0x9d, 0x97, 0x2d, 0x93, 0xe2, 0x17, 0xb7, 0x53 } };
cfg_bool cfg_menu_fastforward3_enabled(guid_cfg_menu_fastforward3_enabled, false);

// {E6EEE2ED-4CD0-47BE-B0BF-BC94ED9B566E}
static const GUID guid_cfg_menu_fastforward4_enabled = { 0xe6eee2ed, 0x4cd0, 0x47be, { 0xb0, 0xbf, 0xbc, 0x94, 0xed, 0x9b, 0x56, 0x6e } };
cfg_bool cfg_menu_fastforward4_enabled(guid_cfg_menu_fastforward4_enabled, false);

// {85EABC32-1E1A-4F7B-AF68-F437AC7D2455}
static const GUID guid_cfg_menu_rewind1_enabled = { 0x85eabc32, 0x1e1a, 0x4f7b, { 0xaf, 0x68, 0xf4, 0x37, 0xac, 0x7d, 0x24, 0x55 } };
cfg_bool cfg_menu_rewind1_enabled(guid_cfg_menu_rewind1_enabled, false);

// {81C9A4E3-FB22-453F-8CBC-C2D268C734FB}
static const GUID guid_cfg_menu_rewind2_enabled = { 0x81c9a4e3, 0xfb22, 0x453f, { 0x8c, 0xbc, 0xc2, 0xd2, 0x68, 0xc7, 0x34, 0xfb } };
cfg_bool cfg_menu_rewind2_enabled(guid_cfg_menu_rewind2_enabled, false);

// {69088D8F-5074-452C-807A-6AC0A15F0E7C}
static const GUID guid_cfg_menu_rewind3_enabled = { 0x69088d8f, 0x5074, 0x452c, { 0x80, 0x7a, 0x6a, 0xc0, 0xa1, 0x5f, 0xe, 0x7c } };
cfg_bool cfg_menu_rewind3_enabled(guid_cfg_menu_rewind3_enabled, false);

// {8BC5B9B4-F54C-4F37-9E57-486D9AFE7651}
static const GUID guid_cfg_menu_rewind4_enabled = { 0x8bc5b9b4, 0xf54c, 0x4f37, { 0x9e, 0x57, 0x48, 0x6d, 0x9a, 0xfe, 0x76, 0x51 } };
cfg_bool cfg_menu_rewind4_enabled(guid_cfg_menu_rewind4_enabled, false);

// {ED54683A-8F53-4420-B29F-428AD8646A50}
static const GUID guid_cfg_menu_loop_enabled = { 0xed54683a, 0x8f53, 0x4420, { 0xb2, 0x9f, 0x42, 0x8a, 0xd8, 0x64, 0x6a, 0x50 } };
cfg_bool cfg_menu_loop_enabled(guid_cfg_menu_loop_enabled, false);

// {4A063A1B-F595-4FA5-A618-CFB93E73A426}
static const GUID guid_cfg_menu_preview_enabled = { 0x4a063a1b, 0xf595, 0x4fa5, { 0xa6, 0x18, 0xcf, 0xb9, 0x3e, 0x73, 0xa4, 0x26 } };
cfg_bool cfg_menu_preview_enabled(guid_cfg_menu_preview_enabled, false);

// {A50BA348-28D1-45CA-8D78-D2AA924B2EBD}
static const GUID guid_cfg_menu_preview_length1_enabled = { 0xa50ba348, 0x28d1, 0x45ca, { 0x8d, 0x78, 0xd2, 0xaa, 0x92, 0x4b, 0x2e, 0xbd } };
cfg_bool cfg_menu_preview_length1_enabled(guid_cfg_menu_preview_length1_enabled, false);

// {3DD079E6-CCFB-4F33-A6DE-E7FDF1E03C56}
static const GUID guid_cfg_menu_preview_length2_enabled = { 0x3dd079e6, 0xccfb, 0x4f33, { 0xa6, 0xde, 0xe7, 0xfd, 0xf1, 0xe0, 0x3c, 0x56 } };
cfg_bool cfg_menu_preview_length2_enabled(guid_cfg_menu_preview_length2_enabled, false);

// {E570F650-32F6-40B2-817F-5F103E10B0F2}
static const GUID guid_cfg_menu_preview_length3_enabled = { 0xe570f650, 0x32f6, 0x40b2, { 0x81, 0x7f, 0x5f, 0x10, 0x3e, 0x10, 0xb0, 0xf2 } };
cfg_bool cfg_menu_preview_length3_enabled(guid_cfg_menu_preview_length3_enabled, true);

// {16A6431B-5387-4C1A-AD1D-A6F633CC22E1}
static const GUID guid_cfg_menu_preview_length4_enabled = { 0x16a6431b, 0x5387, 0x4c1a, { 0xad, 0x1d, 0xa6, 0xf6, 0x33, 0xcc, 0x22, 0xe1 } };
cfg_bool cfg_menu_preview_length4_enabled(guid_cfg_menu_preview_length4_enabled, false);

// {5C78B880-EDB3-4181-BAC9-BC0B5200B6BF}
static const GUID guid_cfg_menu_preview_length5_enabled = { 0x5c78b880, 0xedb3, 0x4181, { 0xba, 0xc9, 0xbc, 0xb, 0x52, 0x0, 0xb6, 0xbf } };
cfg_bool cfg_menu_preview_length5_enabled(guid_cfg_menu_preview_length5_enabled, false);

// {99E69A8C-3682-4FF0-9B2B-A60A5C238A79}
static const GUID guid_cfg_menu_preview_length6_enabled = { 0x99e69a8c, 0x3682, 0x4ff0, { 0x9b, 0x2b, 0xa6, 0xa, 0x5c, 0x23, 0x8a, 0x79 } };
cfg_bool cfg_menu_preview_length6_enabled(guid_cfg_menu_preview_length6_enabled, false);

// {4D77AF15-AD0B-4110-A969-DACE2EF3766D}
static const GUID guid_cfg_menu_preview_length7_enabled = { 0x4d77af15, 0xad0b, 0x4110, { 0xa9, 0x69, 0xda, 0xce, 0x2e, 0xf3, 0x76, 0x6d } };
cfg_bool cfg_menu_preview_length7_enabled(guid_cfg_menu_preview_length7_enabled, false);

// {CB784DCC-D374-4563-91E7-095085BBCE3B}
static const GUID guid_cfg_menu_preview_length8_enabled = { 0xcb784dcc, 0xd374, 0x4563, { 0x91, 0xe7, 0x9, 0x50, 0x85, 0xbb, 0xce, 0x3b } };
cfg_bool cfg_menu_preview_length8_enabled(guid_cfg_menu_preview_length8_enabled, false);

// {468708BE-010B-49E6-81F4-218F494F53D4}
static const GUID guid_cfg_menu_preview_length_default_enabled = { 0x468708be, 0x10b, 0x49e6, { 0x81, 0xf4, 0x21, 0x8f, 0x49, 0x4f, 0x53, 0xd4 } };
cfg_bool cfg_menu_preview_length_default_enabled(guid_cfg_menu_preview_length_default_enabled, false);

// {20505AC4-9FB1-4587-A2F4-0D371BCA7015}
static const GUID guid_cfg_menu_loop_length1_enabled = { 0x20505ac4, 0x9fb1, 0x4587, { 0xa2, 0xf4, 0xd, 0x37, 0x1b, 0xca, 0x70, 0x15 } };
cfg_bool cfg_menu_loop_length1_enabled(guid_cfg_menu_loop_length1_enabled, false);

// {D100A7CB-5952-4608-B752-AE21CB1C9D09}
static const GUID guid_cfg_menu_loop_length2_enabled = { 0xd100a7cb, 0x5952, 0x4608, { 0xb7, 0x52, 0xae, 0x21, 0xcb, 0x1c, 0x9d, 0x9 } };
cfg_bool cfg_menu_loop_length2_enabled(guid_cfg_menu_loop_length2_enabled, false);

// {0C2BC455-4135-49D2-A348-B40DDFA0EE1E}
static const GUID guid_cfg_menu_loop_length3_enabled = { 0xc2bc455, 0x4135, 0x49d2, { 0xa3, 0x48, 0xb4, 0xd, 0xdf, 0xa0, 0xee, 0x1e } };
cfg_bool cfg_menu_loop_length3_enabled(guid_cfg_menu_loop_length3_enabled, true);

// {58AAEF62-DE88-4A74-8583-0FBCE03034D3}
static const GUID guid_cfg_menu_loop_length4_enabled = { 0x58aaef62, 0xde88, 0x4a74, { 0x85, 0x83, 0xf, 0xbc, 0xe0, 0x30, 0x34, 0xd3 } };
cfg_bool cfg_menu_loop_length4_enabled(guid_cfg_menu_loop_length4_enabled, false);

// {31BDC126-26DA-4E62-8BD2-B2B376FFBFC6}
static const GUID guid_cfg_menu_loop_length5_enabled = { 0x31bdc126, 0x26da, 0x4e62, { 0x8b, 0xd2, 0xb2, 0xb3, 0x76, 0xff, 0xbf, 0xc6 } };
cfg_bool cfg_menu_loop_length5_enabled(guid_cfg_menu_loop_length5_enabled, false);

// {857BF0A9-6A86-4FCA-B788-D9E829199494}
static const GUID guid_cfg_menu_loop_length6_enabled = { 0x857bf0a9, 0x6a86, 0x4fca, { 0xb7, 0x88, 0xd9, 0xe8, 0x29, 0x19, 0x94, 0x94 } };
cfg_bool cfg_menu_loop_length6_enabled(guid_cfg_menu_loop_length6_enabled, false);

// {7F58163C-79F6-47D8-9879-DFEC612C8EF5}
static const GUID guid_cfg_menu_loop_length7_enabled = { 0x7f58163c, 0x79f6, 0x47d8, { 0x98, 0x79, 0xdf, 0xec, 0x61, 0x2c, 0x8e, 0xf5 } };
cfg_bool cfg_menu_loop_length7_enabled(guid_cfg_menu_loop_length7_enabled, false);

// {13E68E9E-155E-4727-883B-52605B572149}
static const GUID guid_cfg_menu_loop_length8_enabled = { 0x13e68e9e, 0x155e, 0x4727, { 0x88, 0x3b, 0x52, 0x60, 0x5b, 0x57, 0x21, 0x49 } };
cfg_bool cfg_menu_loop_length8_enabled(guid_cfg_menu_loop_length8_enabled, false);

// {9816F2D6-E960-45DC-8780-EFCC75D2847F}
static const GUID guid_cfg_menu_loop_length_default_enabled = { 0x9816f2d6, 0xe960, 0x45dc, { 0x87, 0x80, 0xef, 0xcc, 0x75, 0xd2, 0x84, 0x7f } };
cfg_bool cfg_menu_loop_length_default_enabled(guid_cfg_menu_loop_length_default_enabled, false);

// {0F6B425E-E7BA-4EC4-BD61-20FCEA0E9EC2}
static const GUID guid_cfg_menu_loop_length_mode_enabled = { 0xf6b425e, 0xe7ba, 0x4ec4, { 0xbd, 0x61, 0x20, 0xfc, 0xea, 0xe, 0x9e, 0xc2 } };
cfg_bool cfg_menu_loop_length_mode_enabled(guid_cfg_menu_loop_length_mode_enabled, false);

//advanced preferences branch

// {2A2F55E5-110A-43BF-8377-1DCB133EF19B}
static const GUID guid_cfg_branch = { 0x2a2f55e5, 0x110a, 0x43bf, { 0x83, 0x77, 0x1d, 0xcb, 0x13, 0x3e, 0xf1, 0x9b } };
static advconfig_branch_factory cfg_branch("Seek", guid_cfg_branch, advconfig_entry::guid_branch_playback, 0);

// {7B2D7884-DBF1-4862-BDA3-F6253D57DB6B}
static const GUID guid_cfg_branch_preview = { 0x7b2d7884, 0xdbf1, 0x4862, { 0xbd, 0xa3, 0xf6, 0x25, 0x3d, 0x57, 0xdb, 0x6b } };
static advconfig_branch_factory cfg_branch_preview("Preview", guid_cfg_branch_preview, guid_cfg_branch, 0);

// {60EA752B-A870-4AEA-B5DA-F70EC2234690}
static const GUID guid_cfg_branch_loop = { 0x60ea752b, 0xa870, 0x4aea, { 0xb5, 0xda, 0xf7, 0xe, 0xc2, 0x23, 0x46, 0x90 } };
static advconfig_branch_factory cfg_branch_loop("Loop", guid_cfg_branch_loop, guid_cfg_branch, 0);

// {3C979CB4-7EEF-45A8-B546-B3037AE99475}
static const GUID guid_cfg_branch_ffrw = { 0x3c979cb4, 0x7eef, 0x45a8, { 0xb5, 0x46, 0xb3, 0x3, 0x7a, 0xe9, 0x94, 0x75 } };
static advconfig_branch_factory cfg_branch_ffrw("FF/RW", guid_cfg_branch_ffrw, guid_cfg_branch, 0);

// {40F8ED07-03CB-4F69-B01E-C84BB17E51B3}
static const GUID guid_cfg_playtime = { 0x40f8ed07, 0x3cb, 0x4f69, { 0xb0, 0x1e, 0xc8, 0x4b, 0xb1, 0x7e, 0x51, 0xb3 } };
advconfig_string_factory cfg_playtime( "FF/RW playback time [ms]", guid_cfg_playtime, guid_cfg_branch_ffrw, 0, "2000" );

// {05975419-4006-404C-BAC0-E15450B32075}
static const GUID guid_cfg_loop = { 0x5975419, 0x4006, 0x404c, { 0xba, 0xc0, 0xe1, 0x54, 0x50, 0xb3, 0x20, 0x75 } };
advconfig_string_factory cfg_loop( "Loop length [ms]", guid_cfg_loop, guid_cfg_branch_loop, 0, "8000" );

// {EA82016E-99D3-4787-A2E6-24DB36C1A5BA}
static const GUID guid_cfg_preview = { 0xea82016e, 0x99d3, 0x4787, { 0xa2, 0xe6, 0x24, 0xdb, 0x36, 0xc1, 0xa5, 0xba } };
advconfig_string_factory cfg_preview( "Preview length [ms]", guid_cfg_preview, guid_cfg_branch_preview, 0, "8000" );

// {1D3D07EF-2015-4024-945F-2B4638B98255}
static const GUID guid_cfg_playback_position_preview = { 0x1d3d07ef, 0x2015, 0x4024, { 0x94, 0x5f, 0x2b, 0x46, 0x38, 0xb9, 0x82, 0x55 } };
advconfig_string_factory cfg_playback_position_preview( "Playback position preview [s]", guid_cfg_playback_position_preview, guid_cfg_branch_preview, 0, "0" );

// {56D7852B-174A-41F7-8BC5-172499BE7FEC}
static const GUID guid_cfg_playback_position_loop = { 0x56d7852b, 0x174a, 0x41f7, { 0x8b, 0xc5, 0x17, 0x24, 0x99, 0xbe, 0x7f, 0xec } };
advconfig_string_factory cfg_playback_position_loop( "Playback position loop [s]", guid_cfg_playback_position_loop, guid_cfg_branch_loop, 0, "0" );

// {933C8996-CBAC-4271-87DF-A4AD66173AF2}
static const GUID guid_cfg_reset_preview_position_enabled = { 0x933c8996, 0xcbac, 0x4271, { 0x87, 0xdf, 0xa4, 0xad, 0x66, 0x17, 0x3a, 0xf2 } };
advconfig_checkbox_factory_t<false> cfg_reset_preview_position_enabled("Reset next track to playback position preview", guid_cfg_reset_preview_position_enabled, guid_cfg_branch_preview, 0, false);

// {E87BFFBE-AAA4-426D-AB25-580A2373C1D4}
static const GUID guid_cfg_reset_loop_position_enabled = { 0xe87bffbe, 0xaaa4, 0x426d, { 0xab, 0x25, 0x58, 0xa, 0x23, 0x73, 0xc1, 0xd4 } };
advconfig_checkbox_factory_t<false> cfg_reset_loop_position_enabled("Reset next track to playback position loop", guid_cfg_reset_loop_position_enabled, guid_cfg_branch_loop, 0, false);

// {B121A905-6B32-4C68-8D4D-28A4598521A7}
static const GUID guid_cfg_automatic_start_stop_enabled = { 0xb121a905, 0x6b32, 0x4c68, { 0x8d, 0x4d, 0x28, 0xa4, 0x59, 0x85, 0x21, 0xa7 } };
advconfig_checkbox_factory_t<false> cfg_automatic_start_stop_enabled("Automatic start/stop", guid_cfg_automatic_start_stop_enabled, guid_cfg_branch, 0, true);

// {A1BD1916-C641-4331-AF1B-3D00D91FFC97}
static const GUID guid_cfg_skip_shorter_tracks_enabled = { 0xa1bd1916, 0xc641, 0x4331, { 0xaf, 0x1b, 0x3d, 0x0, 0xd9, 0x1f, 0xfc, 0x97 } };
advconfig_checkbox_factory_t<false> cfg_skip_shorter_tracks_enabled("Skip shorter tracks in preview", guid_cfg_skip_shorter_tracks_enabled, guid_cfg_branch_preview, 0, false);

//EOF