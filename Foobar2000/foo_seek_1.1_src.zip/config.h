#pragma once

// Please see config.cpp for a description of these variables.

extern cfg_bool cfg_menu_fastforward1_enabled;
extern cfg_bool cfg_menu_fastforward2_enabled;
extern cfg_bool cfg_menu_fastforward3_enabled;
extern cfg_bool cfg_menu_fastforward4_enabled;
extern cfg_bool cfg_menu_rewind1_enabled;
extern cfg_bool cfg_menu_rewind2_enabled;
extern cfg_bool cfg_menu_rewind3_enabled;
extern cfg_bool cfg_menu_rewind4_enabled;
extern cfg_bool cfg_menu_loop_enabled;
extern cfg_bool cfg_menu_preview_enabled;
extern cfg_bool cfg_menu_preview_length1_enabled;
extern cfg_bool cfg_menu_preview_length2_enabled;
extern cfg_bool cfg_menu_preview_length3_enabled;
extern cfg_bool cfg_menu_preview_length4_enabled;
extern cfg_bool cfg_menu_preview_length5_enabled;
extern cfg_bool cfg_menu_preview_length6_enabled;
extern cfg_bool cfg_menu_preview_length7_enabled;
extern cfg_bool cfg_menu_preview_length8_enabled;
extern cfg_bool cfg_menu_preview_length_default_enabled;
extern cfg_bool cfg_menu_loop_length1_enabled;
extern cfg_bool cfg_menu_loop_length2_enabled;
extern cfg_bool cfg_menu_loop_length3_enabled;
extern cfg_bool cfg_menu_loop_length4_enabled;
extern cfg_bool cfg_menu_loop_length5_enabled;
extern cfg_bool cfg_menu_loop_length6_enabled;
extern cfg_bool cfg_menu_loop_length7_enabled;
extern cfg_bool cfg_menu_loop_length8_enabled;
extern cfg_bool cfg_menu_loop_length_default_enabled;
extern cfg_bool cfg_menu_loop_length_mode_enabled;
extern advconfig_string_factory cfg_playtime;
extern advconfig_string_factory cfg_loop;
extern advconfig_string_factory cfg_preview;
extern advconfig_string_factory cfg_playback_position_preview;
extern advconfig_string_factory cfg_playback_position_loop;
extern advconfig_checkbox_factory_t<false> cfg_reset_preview_position_enabled;
extern advconfig_checkbox_factory_t<false> cfg_reset_loop_position_enabled;
extern advconfig_checkbox_factory_t<false> cfg_automatic_start_stop_enabled;
extern advconfig_checkbox_factory_t<false> cfg_skip_shorter_tracks_enabled;

//EOF