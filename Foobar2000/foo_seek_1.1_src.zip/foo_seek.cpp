#include "stdafx.h"

#include "config.h"
#include "option.h"

#define ID_TIMER2 1011
#define ID_TIMER3 1111

DECLARE_COMPONENT_VERSION(
	"Seek",
	"1.1",
	"Seek v1.1\n"
	"Created by grimes\n"
	"Build: " __DATE__ " " __TIME__ "\n\n"
	"Thanks to fooamp, q-stankovic, kumbbl\n\n"
	"Mainmenu commands:\n"
	"Menu | Playback | Seek Control | Preview length (6s-20s, Default)\n"
	"Menu | Playback | Seek Control | Loop length (6s-20s, Default, End point mode, Set end point, Remove end point)\n"
	"Menu | Playback | Seek Control | Preview (ON/OFF)\n"
	"Menu | Playback | Seek Control | Loop (ON/OFF)\n"
	"Menu | Playback | Seek Control | Rewind (5s-30s) (ON/OFF)\n"
	"Menu | Playback | Seek Control | Fast Forward (5s-30s) (ON/OFF)\n\n"
	"Advanced Preferences:\n"
	"Preferences | Advanced | Playback | Seek | Automatic start/stop (ON/OFF)\n"
	"Preferences | Advanced | Playback | Seek | FF/RW | FF/RW playback time [ms]\n"
	"Preferences | Advanced | Playback | Seek | Loop | Loop length [ms]\n"
	"Preferences | Advanced | Playback | Seek | Loop | Playback position loop [s]\n"
	"Preferences | Advanced | Playback | Seek | Loop | Reset next track to playback position loop (ON/OFF)\n"
	"Preferences | Advanced | Playback | Seek | Preview | Playback position preview [s]\n"
	"Preferences | Advanced | Playback | Seek | Preview | Preview length [ms]\n"
	"Preferences | Advanced | Playback | Seek | Preview | Reset next track to playback position preview (ON/OFF)\n"
	"Preferences | Advanced | Playback | Seek | Preview | Skip shorter tracks in preview (ON/OFF)\n"
);

VALIDATE_COMPONENT_FILENAME("foo_seek.dll");
pfc::string8 playtime;
UINT playtime2;
pfc::string8 loop;
UINT loop2;
pfc::string8 preview;
UINT preview2;
UINT_PTR ptr2;
UINT_PTR ptr3;
pfc::string8 playback_position_preview_string;
double playback_position_preview;
pfc::string8 playback_position_loop_string;
double playback_position_loop;
double loop_position_end;
double compare_playback_position_preview_old;
double compare_playback_position_preview_new;
double compare_playback_position_loop_old;
double compare_playback_position_loop_new;

pfc::string8 tag1;
pfc::string8 length;
UINT length2;

bool set_end_point = false;


class position : public initquit
{

public:

	virtual void on_init()
	{
		cfg_playback_position_preview.get(playback_position_preview_string);
		playback_position_preview = atoi(playback_position_preview_string);
		compare_playback_position_preview_new = atoi(playback_position_preview_string);
		cfg_playback_position_loop.get(playback_position_loop_string);
		playback_position_loop = atoi(playback_position_loop_string);
		compare_playback_position_loop_new = atoi(playback_position_loop_string);
	}

	virtual void on_quit()
	{
		option::set_option(1);
		KillTimer(NULL,ptr2);
	}
};

initquit_factory_t<position> g_position;


VOID CALLBACK Seek2(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent3,     // timer identifier
    DWORD dwTime)     // current system time
{
	static_api_ptr_t<playback_control>()->pause(false);
	if (cfg_menu_preview_enabled)
	{
		if (!cfg_skip_shorter_tracks_enabled && length2 < playback_position_preview + preview2 / 1000)
		{
			static_api_ptr_t<playback_control>()->playback_seek(length2 - 1 - preview2 / 1000);
		}
		else
		{
			static_api_ptr_t<playback_control>()->playback_seek(playback_position_preview);
		}
		if (cfg_reset_preview_position_enabled)
		{
			cfg_playback_position_preview.get(playback_position_preview_string);
			playback_position_preview = atoi(playback_position_preview_string);
		}
	}
	if (cfg_menu_loop_enabled)
	{
		if (length2 < playback_position_loop + loop2 / 1000)
		{
			static_api_ptr_t<playback_control>()->playback_seek(length2 - 1 - loop2 / 1000);
		}
		else
		{
			static_api_ptr_t<playback_control>()->playback_seek(playback_position_loop);
		}
	}
	KillTimer(NULL,idEvent3);
}

VOID CALLBACK Seek(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent1,     // timer identifier
    DWORD dwTime)     // current system time
{
	if (cfg_menu_fastforward1_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(5);
	}
	else if (cfg_menu_fastforward2_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(10);
	}
	else if (cfg_menu_fastforward3_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(20);
	}
	else if (cfg_menu_fastforward4_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(30);
	}
	else if (cfg_menu_rewind1_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(-7);
	}
	else if (cfg_menu_rewind2_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(-12);
	}
	else if (cfg_menu_rewind3_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(-22);
	}
	else if (cfg_menu_rewind4_enabled)
	{
		static_api_ptr_t<playback_control>()->playback_seek_delta(-32);
	}
	else if (cfg_menu_loop_enabled)
	{
		if (static_api_ptr_t<playback_control>()->get_stop_after_current())
		{
			static_api_ptr_t<playback_control>()->stop();
		}
		else
		{
			static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,true);
		}
	}
	else if (cfg_menu_preview_enabled)
	{
		if (static_api_ptr_t<playback_control>()->get_stop_after_current())
		{
			static_api_ptr_t<playback_control>()->stop();
		}
		else
		{
			static_api_ptr_t<playback_control>()->start(playback_control::track_command_next,true);
		}
	}
	else
	{
		KillTimer(NULL,idEvent1);
		option::set_option(1);
	}
}


// {9F6D3199-E68A-4FAD-B590-6D133D84801E}
static const GUID guid_cfg_menu_seekcontrol = { 0x9f6d3199, 0xe68a, 0x4fad, { 0xb5, 0x90, 0x6d, 0x13, 0x3d, 0x84, 0x80, 0x1e } };

// {FF5D73C5-E9C1-47B8-951B-7B23C1C25334}
static const GUID guid_cfg_menu_fastforward = { 0xff5d73c5, 0xe9c1, 0x47b8, { 0x95, 0x1b, 0x7b, 0x23, 0xc1, 0xc2, 0x53, 0x34 } };

class mainmenu_commands_fastforward : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 4;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {F2EF6762-73E4-4A6A-A76F-07A5BC3816C3}
		static const GUID guid_main_fastforward1_toggle = { 0xf2ef6762, 0x73e4, 0x4a6a, { 0xa7, 0x6f, 0x7, 0xa5, 0xbc, 0x38, 0x16, 0xc3 } };
		// {F6AC8BF3-C887-475D-8F59-9D8FA7FD60DA}
		static const GUID guid_main_fastforward2_toggle = { 0xf6ac8bf3, 0xc887, 0x475d, { 0x8f, 0x59, 0x9d, 0x8f, 0xa7, 0xfd, 0x60, 0xda } };
		// {12BD3292-654A-4B8F-8844-91E6A93BC406}
		static const GUID guid_main_fastforward3_toggle = { 0x12bd3292, 0x654a, 0x4b8f, { 0x88, 0x44, 0x91, 0xe6, 0xa9, 0x3b, 0xc4, 0x6 } };
		// {F2F5040B-1914-4F19-80C1-82846025E44C}
		static const GUID guid_main_fastforward4_toggle = { 0xf2f5040b, 0x1914, 0x4f19, { 0x80, 0xc1, 0x82, 0x84, 0x60, 0x25, 0xe4, 0x4c } };

		if (p_index == 0)
			return guid_main_fastforward1_toggle;
		if (p_index == 1)
			return guid_main_fastforward2_toggle;
		if (p_index == 2)
			return guid_main_fastforward3_toggle;
		if (p_index == 3)
			return guid_main_fastforward4_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "5s";
		if (p_index == 1)
			p_out = "10s";
		if (p_index == 2)
			p_out = "20s";
		if (p_index == 3)
			p_out = "30s";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Fast Forward speed 5s/playback";
		else if (p_index == 1)
			p_out = "Fast Forward speed 10s/playback";
		else if (p_index == 2)
			p_out = "Fast Forward speed 20s/playback";
		else if (p_index == 3)
			p_out = "Fast Forward speed 30s/playback";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_fastforward;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		cfg_playtime.get(playtime);
		playtime2 = atoi(playtime);
		KillTimer(NULL,ptr2);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_fastforward1_enabled = !cfg_menu_fastforward1_enabled;
			if (cfg_menu_fastforward1_enabled)
			{
				option::set_option(1);
				cfg_menu_fastforward1_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_fastforward2_enabled = !cfg_menu_fastforward2_enabled;
			if (cfg_menu_fastforward2_enabled)
			{
				option::set_option(1);
				cfg_menu_fastforward2_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_fastforward3_enabled = !cfg_menu_fastforward3_enabled;
			if (cfg_menu_fastforward3_enabled)
			{
				option::set_option(1);
				cfg_menu_fastforward3_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_fastforward4_enabled = !cfg_menu_fastforward4_enabled;
			if (cfg_menu_fastforward4_enabled)
			{
				option::set_option(1);
				cfg_menu_fastforward4_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index,p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_fastforward1_enabled;
		if (p_index == 1)
			return cfg_menu_fastforward2_enabled;
		if (p_index == 2)
			return cfg_menu_fastforward3_enabled;
		if (p_index == 3)
			return cfg_menu_fastforward4_enabled;
		return false;
	}
};


static mainmenu_group_popup_factory mainmenu_group(guid_cfg_menu_seekcontrol,
        mainmenu_groups::playback_controls, mainmenu_commands::sort_priority_last,
        "Seek Control");

static mainmenu_commands_factory_t<mainmenu_commands_fastforward> g_mainmenu_commands_fastforward;

static mainmenu_group_popup_factory mainmenu_group3(guid_cfg_menu_fastforward,
        guid_cfg_menu_seekcontrol, mainmenu_commands::sort_priority_last,
        "Fast Forward");


// {25C7A259-B5B4-4C83-A276-AE86AE8E78AA}
static const GUID guid_cfg_menu_rewind = { 0x25c7a259, 0xb5b4, 0x4c83, { 0xa2, 0x76, 0xae, 0x86, 0xae, 0x8e, 0x78, 0xaa } };

class mainmenu_commands_rewind : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 4;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {D86A8115-A575-4610-9AB3-B425FF02A1F4}
		static const GUID guid_main_rewind1_toggle = { 0xd86a8115, 0xa575, 0x4610, { 0x9a, 0xb3, 0xb4, 0x25, 0xff, 0x2, 0xa1, 0xf4 } };
		// {B073C3F5-1998-483F-9FEF-38E2DDFC24C9}
		static const GUID guid_main_rewind2_toggle = { 0xb073c3f5, 0x1998, 0x483f, { 0x9f, 0xef, 0x38, 0xe2, 0xdd, 0xfc, 0x24, 0xc9 } };
		// {E9388CE6-43B9-4726-9884-D2DA0A385180}
		static const GUID guid_main_rewind3_toggle = { 0xe9388ce6, 0x43b9, 0x4726, { 0x98, 0x84, 0xd2, 0xda, 0xa, 0x38, 0x51, 0x80 } };
		// {C89602CC-F4F0-4703-83D0-3F8C3F24A5F7}
		static const GUID guid_main_rewind4_toggle = { 0xc89602cc, 0xf4f0, 0x4703, { 0x83, 0xd0, 0x3f, 0x8c, 0x3f, 0x24, 0xa5, 0xf7 } };

		if (p_index == 0)
			return guid_main_rewind1_toggle;
		if (p_index == 1)
			return guid_main_rewind2_toggle;
		if (p_index == 2)
			return guid_main_rewind3_toggle;
		if (p_index == 3)
			return guid_main_rewind4_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "5s";
		if (p_index == 1)
			p_out = "10s";
		if (p_index == 2)
			p_out = "20s";
		if (p_index == 3)
			p_out = "30s";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Rewind speed 5s/playback";
		else if (p_index == 1)
			p_out = "Rewind speed 10s/playback";
		else if (p_index == 2)
			p_out = "Rewind speed 20s/playback";
		else if (p_index == 3)
			p_out = "Rewind speed 30s/playback";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_rewind;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		cfg_playtime.get(playtime);
		playtime2 = atoi(playtime);
		KillTimer(NULL,ptr2);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_rewind1_enabled = !cfg_menu_rewind1_enabled;
			if (cfg_menu_rewind1_enabled)
			{
				option::set_option(1);
				cfg_menu_rewind1_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_rewind2_enabled = !cfg_menu_rewind2_enabled;
			if (cfg_menu_rewind2_enabled)
			{
				option::set_option(1);
				cfg_menu_rewind2_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_rewind3_enabled = !cfg_menu_rewind3_enabled;
			if (cfg_menu_rewind3_enabled)
			{
				option::set_option(1);
				cfg_menu_rewind3_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_rewind4_enabled = !cfg_menu_rewind4_enabled;
			if (cfg_menu_rewind4_enabled)
			{
				option::set_option(1);
				cfg_menu_rewind4_enabled = true;
				if (cfg_automatic_start_stop_enabled && !static_api_ptr_t<playback_control>()->is_paused() && !static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,false);
				}
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
			else
			{
				option::set_option(1);
			}
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index,p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_rewind1_enabled;
		if (p_index == 1)
			return cfg_menu_rewind2_enabled;
		if (p_index == 2)
			return cfg_menu_rewind3_enabled;
		if (p_index == 3)
			return cfg_menu_rewind4_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_rewind> g_mainmenu_commands_rewind;

static mainmenu_group_popup_factory mainmenu_group2(guid_cfg_menu_rewind,
        guid_cfg_menu_seekcontrol, mainmenu_commands::sort_priority_last,
        "Rewind");


class mainmenu_commands_loop : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 1;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {62C96C10-7899-492B-B42C-E351F061A766}
		static const GUID guid_main_loop_toggle = { 0x62c96c10, 0x7899, 0x492b, { 0xb4, 0x2c, 0xe3, 0x51, 0xf0, 0x61, 0xa7, 0x66 } };

		if (p_index == 0)
			return guid_main_loop_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Loop";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Repeat part of current track";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_seekcontrol;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		KillTimer(NULL,ptr2);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_loop_enabled = !cfg_menu_loop_enabled;
			if (cfg_menu_loop_enabled)
			{
				if (cfg_menu_loop_length1_enabled)
				{
					loop2 = 6000;
				}
				else if (cfg_menu_loop_length2_enabled)
				{
					loop2 = 8000;
				}
				else if (cfg_menu_loop_length3_enabled)
				{
					loop2 = 10000;
				}
				else if (cfg_menu_loop_length4_enabled)
				{
					loop2 = 12000;
				}
				else if (cfg_menu_loop_length5_enabled)
				{
					loop2 = 14000;
				}
				else if (cfg_menu_loop_length6_enabled)
				{
					loop2 = 16000;
				}
				else if (cfg_menu_loop_length7_enabled)
				{
					loop2 = 18000;
				}
				else if (cfg_menu_loop_length8_enabled)
				{
					loop2 = 20000;
				}
				else if (cfg_menu_loop_length_default_enabled)
				{
					cfg_loop.get(loop);
					loop2 = atoi(loop);
					if (loop2 < 200)
					{
						loop2 = 200;
					}
				}
				else if (cfg_menu_loop_length_mode_enabled)
				{
					loop2 = 10000000;
				}
				option::set_option(1);
				cfg_menu_loop_enabled = true;
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					playback_position_loop = static_api_ptr_t<playback_control>()->playback_get_position();
					ptr2 = SetTimer(NULL,ID_TIMER2,loop2,(TIMERPROC)Seek);
				}
				else
				{
					if (cfg_automatic_start_stop_enabled)
					{
						static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,true);
					}
				}
			}
			else
			{
				option::set_option(1);
			}
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index,p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_dontcare;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_loop_enabled;
		return false;
	}

};

static mainmenu_commands_factory_t<mainmenu_commands_loop> g_mainmenu_commands_loop;


class mainmenu_commands_preview : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 1;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {B75C68E4-7644-4F46-AEDC-30B483D6A0B2}
		static const GUID guid_main_preview_toggle = { 0xb75c68e4, 0x7644, 0x4f46, { 0xae, 0xdc, 0x30, 0xb4, 0x83, 0xd6, 0xa0, 0xb2 } };

		if (p_index == 0)
			return guid_main_preview_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Preview";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Listen to parts of consecutive tracks";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_seekcontrol;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		KillTimer(NULL,ptr2);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_preview_enabled = !cfg_menu_preview_enabled;
			if (cfg_menu_preview_enabled)
			{
				if (cfg_menu_preview_length1_enabled)
				{
					preview2 = 6000;
				}
				else if (cfg_menu_preview_length2_enabled)
				{
					preview2 = 8000;
				}
				else if (cfg_menu_preview_length3_enabled)
				{
					preview2 = 10000;
				}
				else if (cfg_menu_preview_length4_enabled)
				{
					preview2 = 12000;
				}
				else if (cfg_menu_preview_length5_enabled)
				{
					preview2 = 14000;
				}
				else if (cfg_menu_preview_length6_enabled)
				{
					preview2 = 16000;
				}
				else if (cfg_menu_preview_length7_enabled)
				{
					preview2 = 18000;
				}
				else if (cfg_menu_preview_length8_enabled)
				{
					preview2 = 20000;
				}
				else
				{
					cfg_preview.get(preview);
					preview2 = atoi(preview);
					if (preview2 < 200)
					{
						preview2 = 200;
					}
				}
				option::set_option(1);
				cfg_menu_preview_enabled = true;
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					playback_position_preview = static_api_ptr_t<playback_control>()->playback_get_position();
					ptr2 = SetTimer(NULL,ID_TIMER2,preview2,(TIMERPROC)Seek);
				}
				else
				{
					if (cfg_automatic_start_stop_enabled)
					{
						static_api_ptr_t<playback_control>()->start(playback_control::track_command_play,true);
					}
				}
			}
			else
			{
				option::set_option(1);
			}
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index,p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_dontcare;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_preview_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_preview> g_mainmenu_commands_preview;


// {06BA6B6B-687E-43E2-95B8-741BFBDD38E1}
static const GUID guid_cfg_menu_preview_length = { 0x6ba6b6b, 0x687e, 0x43e2, { 0x95, 0xb8, 0x74, 0x1b, 0xfb, 0xdd, 0x38, 0xe1 } };

class mainmenu_commands_preview_length_sub : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 9;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{

		// {8D9E334F-AD5E-4E26-9893-7F6596EC2BC2}
		static const GUID guid_main_preview_length1_toggle = { 0x8d9e334f, 0xad5e, 0x4e26, { 0x98, 0x93, 0x7f, 0x65, 0x96, 0xec, 0x2b, 0xc2 } };
		// {3E7C2DCD-64D3-40DB-9E8C-88A8E807690C}
		static const GUID guid_main_preview_length2_toggle = { 0x3e7c2dcd, 0x64d3, 0x40db, { 0x9e, 0x8c, 0x88, 0xa8, 0xe8, 0x7, 0x69, 0xc } };
		// {FC118358-CA88-45C8-AE5F-6AD51924D3A2}
		static const GUID guid_main_preview_length3_toggle = { 0xfc118358, 0xca88, 0x45c8, { 0xae, 0x5f, 0x6a, 0xd5, 0x19, 0x24, 0xd3, 0xa2 } };
		// {675FC653-2F73-4C28-BB19-91EE05E6EEC1}
		static const GUID guid_main_preview_length4_toggle = { 0x675fc653, 0x2f73, 0x4c28, { 0xbb, 0x19, 0x91, 0xee, 0x5, 0xe6, 0xee, 0xc1 } };
		// {05897A75-A6DE-4227-A7DC-960BB16532D6}
		static const GUID guid_main_preview_length5_toggle = { 0x5897a75, 0xa6de, 0x4227, { 0xa7, 0xdc, 0x96, 0xb, 0xb1, 0x65, 0x32, 0xd6 } };
		// {E92BC06E-A1F0-4979-B49C-2F8866C6AD0F}
		static const GUID guid_main_preview_length6_toggle = { 0xe92bc06e, 0xa1f0, 0x4979, { 0xb4, 0x9c, 0x2f, 0x88, 0x66, 0xc6, 0xad, 0xf } };
		// {4F0F82A8-8A53-44FC-925B-E5A744F9ADFA}
		static const GUID guid_main_preview_length7_toggle = { 0x4f0f82a8, 0x8a53, 0x44fc, { 0x92, 0x5b, 0xe5, 0xa7, 0x44, 0xf9, 0xad, 0xfa } };
		// {279AF56D-89E1-4F8F-845D-06897C8DFECF}
		static const GUID guid_main_preview_length8_toggle = { 0x279af56d, 0x89e1, 0x4f8f, { 0x84, 0x5d, 0x6, 0x89, 0x7c, 0x8d, 0xfe, 0xcf } };
		// {43C98DE0-A99F-422E-8F90-BD686C8DC7C9}
		static const GUID guid_main_preview_length_default_toggle = { 0x43c98de0, 0xa99f, 0x422e, { 0x8f, 0x90, 0xbd, 0x68, 0x6c, 0x8d, 0xc7, 0xc9 } };


		if (p_index == 0)
			return guid_main_preview_length1_toggle;
		if (p_index == 1)
			return guid_main_preview_length2_toggle;
		if (p_index == 2)
			return guid_main_preview_length3_toggle;
		if (p_index == 3)
			return guid_main_preview_length4_toggle;
		if (p_index == 4)
			return guid_main_preview_length5_toggle;
		if (p_index == 5)
			return guid_main_preview_length6_toggle;
		if (p_index == 6)
			return guid_main_preview_length7_toggle;
		if (p_index == 7)
			return guid_main_preview_length8_toggle;
		if (p_index == 8)
			return guid_main_preview_length_default_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "6s";
		if (p_index == 1)
			p_out = "8s";
		if (p_index == 2)
			p_out = "10s";
		if (p_index == 3)
			p_out = "12s";
		if (p_index == 4)
			p_out = "14s";
		if (p_index == 5)
			p_out = "16s";
		if (p_index == 6)
			p_out = "18s";
		if (p_index == 7)
			p_out = "20s";
		if (p_index == 8)
			p_out = "Default";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Preview length is 6s";
		else if (p_index == 1)
			p_out = "Preview length is 8s";
		else if (p_index == 2)
			p_out = "Preview length is 10s";
		else if (p_index == 3)
			p_out = "Preview length is 12s";
		else if (p_index == 4)
			p_out = "Preview length is 14s";
		else if (p_index == 5)
			p_out = "Preview length is 16s";
		else if (p_index == 6)
			p_out = "Preview length is 18s";
		else if (p_index == 7)
			p_out = "Preview length is 20s";
		else if (p_index == 8)
			p_out = "Preview length taken from Advanced Preferences";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_preview_length;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length1_enabled = true;
			preview2 = 6000;
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length2_enabled = true;
			preview2 = 8000;
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length3_enabled = true;
			preview2 = 10000;
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length4_enabled = true;
			preview2 = 12000;
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length5_enabled = true;
			preview2 = 14000;
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length6_enabled = true;
			preview2 = 16000;
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length7_enabled = true;
			preview2 = 18000;
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length8_enabled = true;
			preview2 = 20000;
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			option::set_option(2);
			cfg_menu_preview_length_default_enabled = true;
			cfg_preview.get(preview);
			preview2 = atoi(preview);
			if (preview2 < 200)
			{
				preview2 = 200;
			}
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_radiochecked;
		get_name(p_index,p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_dontcare;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_preview_length1_enabled;
		if (p_index == 1)
			return cfg_menu_preview_length2_enabled;
		if (p_index == 2)
			return cfg_menu_preview_length3_enabled;
		if (p_index == 3)
			return cfg_menu_preview_length4_enabled;
		if (p_index == 4)
			return cfg_menu_preview_length5_enabled;
		if (p_index == 5)
			return cfg_menu_preview_length6_enabled;
		if (p_index == 6)
			return cfg_menu_preview_length7_enabled;
		if (p_index == 7)
			return cfg_menu_preview_length8_enabled;
		if (p_index == 8)
			return cfg_menu_preview_length_default_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_preview_length_sub> g_mainmenu_commands_preview_length_sub;

static mainmenu_group_popup_factory mainmenu_group10(guid_cfg_menu_preview_length,
        guid_cfg_menu_seekcontrol, mainmenu_commands::sort_priority_base,
        "Preview length");


// {31731042-443A-4E0A-B263-69E1852AAC4D}
static const GUID guid_cfg_menu_loop_length = { 0x31731042, 0x443a, 0x4e0a, { 0xb2, 0x63, 0x69, 0xe1, 0x85, 0x2a, 0xac, 0x4d } };

class mainmenu_commands_loop_length_sub : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 12;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{

		// {8F070C3D-FF15-4D68-AF3B-602E48846B7F}
		static const GUID guid_main_loop_length1_toggle = { 0x8f070c3d, 0xff15, 0x4d68, { 0xaf, 0x3b, 0x60, 0x2e, 0x48, 0x84, 0x6b, 0x7f } };
		// {9ABCCED5-B28A-4358-9FE3-77BFAC79EAEC}
		static const GUID guid_main_loop_length2_toggle = { 0x9abcced5, 0xb28a, 0x4358, { 0x9f, 0xe3, 0x77, 0xbf, 0xac, 0x79, 0xea, 0xec } };
		// {C089AD98-4D56-4880-A50B-E6D527C8705C}
		static const GUID guid_main_loop_length3_toggle = { 0xc089ad98, 0x4d56, 0x4880, { 0xa5, 0xb, 0xe6, 0xd5, 0x27, 0xc8, 0x70, 0x5c } };
		// {87D8585A-2A9D-4716-A835-C164CC85217B}
		static const GUID guid_main_loop_length4_toggle = { 0x87d8585a, 0x2a9d, 0x4716, { 0xa8, 0x35, 0xc1, 0x64, 0xcc, 0x85, 0x21, 0x7b } };
		// {C793F862-56BC-4619-8AC4-DD15BA316BA2}
		static const GUID guid_main_loop_length5_toggle = { 0xc793f862, 0x56bc, 0x4619, { 0x8a, 0xc4, 0xdd, 0x15, 0xba, 0x31, 0x6b, 0xa2 } };
		// {EE9095DF-D852-488C-9A37-4580D01A1B35}
		static const GUID guid_main_loop_length6_toggle = { 0xee9095df, 0xd852, 0x488c, { 0x9a, 0x37, 0x45, 0x80, 0xd0, 0x1a, 0x1b, 0x35 } };
		// {7E5755D8-FEAA-4D42-8577-EA254CE99DBC}
		static const GUID guid_main_loop_length7_toggle = { 0x7e5755d8, 0xfeaa, 0x4d42, { 0x85, 0x77, 0xea, 0x25, 0x4c, 0xe9, 0x9d, 0xbc } };
		// {1E65A42B-9E8E-4D74-9D90-37473D77CBA1}
		static const GUID guid_main_loop_length8_toggle = { 0x1e65a42b, 0x9e8e, 0x4d74, { 0x9d, 0x90, 0x37, 0x47, 0x3d, 0x77, 0xcb, 0xa1 } };
		// {D360ACAD-9289-497F-8B98-C3CC9BB00F75}
		static const GUID guid_main_loop_length_default_toggle = { 0xd360acad, 0x9289, 0x497f, { 0x8b, 0x98, 0xc3, 0xcc, 0x9b, 0xb0, 0xf, 0x75 } };
		// {2C77FEA1-C0AC-4A15-8528-793B99D408A5}
		static const GUID guid_main_loop_length_mode_toggle = { 0x2c77fea1, 0xc0ac, 0x4a15, { 0x85, 0x28, 0x79, 0x3b, 0x99, 0xd4, 0x8, 0xa5 } };
		// {A50DFA39-657B-4293-A504-923FCE45EA1C}
		static const GUID guid_main_loop_length_end_toggle = { 0xa50dfa39, 0x657b, 0x4293, { 0xa5, 0x4, 0x92, 0x3f, 0xce, 0x45, 0xea, 0x1c } };
		// {E8E625A6-EA5D-4CC6-BF12-7E19906FCC99}
		static const GUID guid_main_loop_length_remove_toggle = { 0xe8e625a6, 0xea5d, 0x4cc6, { 0xbf, 0x12, 0x7e, 0x19, 0x90, 0x6f, 0xcc, 0x99 } };


		if (p_index == 0)
			return guid_main_loop_length1_toggle;
		if (p_index == 1)
			return guid_main_loop_length2_toggle;
		if (p_index == 2)
			return guid_main_loop_length3_toggle;
		if (p_index == 3)
			return guid_main_loop_length4_toggle;
		if (p_index == 4)
			return guid_main_loop_length5_toggle;
		if (p_index == 5)
			return guid_main_loop_length6_toggle;
		if (p_index == 6)
			return guid_main_loop_length7_toggle;
		if (p_index == 7)
			return guid_main_loop_length8_toggle;
		if (p_index == 8)
			return guid_main_loop_length_default_toggle;
		if (p_index == 9)
			return guid_main_loop_length_mode_toggle;
		if (p_index == 10)
			return guid_main_loop_length_end_toggle;
		if (p_index == 11)
			return guid_main_loop_length_remove_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "6s";
		if (p_index == 1)
			p_out = "8s";
		if (p_index == 2)
			p_out = "10s";
		if (p_index == 3)
			p_out = "12s";
		if (p_index == 4)
			p_out = "14s";
		if (p_index == 5)
			p_out = "16s";
		if (p_index == 6)
			p_out = "18s";
		if (p_index == 7)
			p_out = "20s";
		if (p_index == 8)
			p_out = "Default";
		if (p_index == 9)
			p_out = "End point mode";
		if (p_index == 10)
			p_out = "Set end point";
		if (p_index == 11)
			p_out = "Remove end point";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Loop length is 6s";
		else if (p_index == 1)
			p_out = "Loop length is 8s";
		else if (p_index == 2)
			p_out = "Loop length is 10s";
		else if (p_index == 3)
			p_out = "Loop length is 12s";
		else if (p_index == 4)
			p_out = "Loop length is 14s";
		else if (p_index == 5)
			p_out = "Loop length is 16s";
		else if (p_index == 6)
			p_out = "Loop length is 18s";
		else if (p_index == 7)
			p_out = "Loop length is 20s";
		else if (p_index == 8)
			p_out = "Loop length taken from Advanced Preferences";
		else if (p_index == 9)
			p_out = "End point mode";
		else if (p_index == 10)
			p_out = "Set end point";
		else if (p_index == 11)
			p_out = "Remove end point";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_loop_length;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length1_enabled = true;
			loop2 = 6000;
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length2_enabled = true;
			loop2 = 8000;
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length3_enabled = true;
			loop2 = 10000;
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length4_enabled = true;
			loop2 = 12000;
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length5_enabled = true;
			loop2 = 14000;
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length6_enabled = true;
			loop2 = 16000;
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length7_enabled = true;
			loop2 = 18000;
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length8_enabled = true;
			loop2 = 20000;
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length_default_enabled = true;
			cfg_loop.get(loop);
			loop2 = atoi(loop);
			if (loop2 < 200)
			{
				loop2 = 200;
			}
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			option::set_option(3);
			cfg_menu_loop_length_mode_enabled = true;
			KillTimer(NULL,ptr2);
			KillTimer(NULL,ptr3);
			if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
			{
				loop2 = UINT(length2 - 1 - playback_position_loop) * 1000;
			}
			else
			{
				loop2 = 10000000;
			}
			set_end_point = false;
		}
		if (p_index == 10 && core_api::assert_main_thread())
		{
			if (cfg_menu_loop_enabled && cfg_menu_loop_length_mode_enabled && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
			{
				loop_position_end = static_api_ptr_t<playback_control>()->playback_get_position();
				loop2 = UINT((loop_position_end - playback_position_loop) * 1000);
				console::formatter() << "New loop length: " << loop2 << " ms";
				set_end_point = true;
				KillTimer(NULL,ptr3);
				ptr3 = SetTimer(NULL,ID_TIMER3,0,(TIMERPROC)Seek2);
			}
		}
		if (p_index == 11 && core_api::assert_main_thread())
		{
			if (cfg_menu_loop_enabled)
			{
				option::set_option(3);
				cfg_menu_loop_length_mode_enabled = true;
				KillTimer(NULL,ptr2);
				KillTimer(NULL,ptr3);
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					loop2 = UINT(length2 - 1 - playback_position_loop) * 1000;
				}
				else
				{
					loop2 = 10000000;
				}
				set_end_point = false;
				console::info("Loop length resetted");
			}
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_radiochecked;
		get_name(p_index,p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_dontcare;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_loop_length1_enabled;
		if (p_index == 1)
			return cfg_menu_loop_length2_enabled;
		if (p_index == 2)
			return cfg_menu_loop_length3_enabled;
		if (p_index == 3)
			return cfg_menu_loop_length4_enabled;
		if (p_index == 4)
			return cfg_menu_loop_length5_enabled;
		if (p_index == 5)
			return cfg_menu_loop_length6_enabled;
		if (p_index == 6)
			return cfg_menu_loop_length7_enabled;
		if (p_index == 7)
			return cfg_menu_loop_length8_enabled;
		if (p_index == 8)
			return cfg_menu_loop_length_default_enabled;
		if (p_index == 9)
			return cfg_menu_loop_length_mode_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_loop_length_sub> g_mainmenu_commands_loop_length_sub;

static mainmenu_group_popup_factory mainmenu_group11(guid_cfg_menu_loop_length,
        guid_cfg_menu_seekcontrol, mainmenu_commands::sort_priority_base,
        "Loop length");


class play_callback_seek : public play_callback_static
{

public:

	virtual unsigned get_flags(void)
	{
		return(flag_on_playback_new_track | flag_on_playback_stop | flag_on_playback_seek | flag_on_playback_pause);
	}

	virtual void FB2KAPI on_playback_new_track(metadb_handle_ptr p_track)
	{
		p_track->metadb_lock();
		service_ptr_t<titleformat_object> tagobj1;
		static_api_ptr_t<titleformat_compiler> compiler;
		tag1 = "%length_seconds%";
		compiler->compile(tagobj1, tag1);
		p_track->format_title(NULL, length, tagobj1, NULL);
		tagobj1.release();
		p_track->metadb_unlock();
		SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(length));
		length2 = atoi(length);
		if (cfg_menu_preview_length1_enabled)
		{
			preview2 = 6000;
		}
		else if (cfg_menu_preview_length2_enabled)
		{
			preview2 = 8000;
		}
		else if (cfg_menu_preview_length3_enabled)
		{
			preview2 = 10000;
		}
		else if (cfg_menu_preview_length4_enabled)
		{
			preview2 = 12000;
		}
		else if (cfg_menu_preview_length5_enabled)
		{
			preview2 = 14000;
		}
		else if (cfg_menu_preview_length6_enabled)
		{
			preview2 = 16000;
		}
		else if (cfg_menu_preview_length7_enabled)
		{
			preview2 = 18000;
		}
		else if (cfg_menu_preview_length8_enabled)
		{
			preview2 = 20000;
		}
		else if (cfg_menu_preview_length_default_enabled)
		{
			cfg_preview.get(preview);
			preview2 = atoi(preview);
			if (preview2 < 200)
			{
				preview2 = 200;
			}
		}
		if (cfg_menu_preview_enabled)
		{
			if (length2 < preview2 / 1000 && !cfg_skip_shorter_tracks_enabled && cfg_reset_preview_position_enabled)
			{
				preview2 = length2 * 1000;
			}
			compare_playback_position_preview_old = compare_playback_position_preview_new;
			cfg_playback_position_preview.get(playback_position_preview_string);
			compare_playback_position_preview_new = atoi(playback_position_preview_string);
			if (compare_playback_position_preview_new != compare_playback_position_preview_old)
			{
				playback_position_preview = compare_playback_position_preview_new;
			}
			if (cfg_reset_preview_position_enabled)
			{
				cfg_playback_position_preview.get(playback_position_preview_string);
				playback_position_preview = atoi(playback_position_preview_string);
			}
			KillTimer(NULL,ptr3);
			ptr3 = SetTimer(NULL,ID_TIMER3,0,(TIMERPROC)Seek2);
		}
		if (length2 < playback_position_loop + loop2 / 1000)
		{
			loop2 = UINT(length2 - 1 - playback_position_loop) * 1000;
		}
		if (cfg_menu_loop_enabled)
		{
			if (cfg_menu_loop_length_default_enabled)
			{
				compare_playback_position_loop_old = compare_playback_position_loop_new;
				cfg_playback_position_loop.get(playback_position_loop_string);
				compare_playback_position_loop_new = atoi(playback_position_loop_string);
				if (compare_playback_position_loop_new != compare_playback_position_loop_old)
				{
					playback_position_loop = compare_playback_position_loop_new;
				}
			}
			KillTimer(NULL,ptr3);
			ptr3 = SetTimer(NULL,ID_TIMER3,0,(TIMERPROC)Seek2);
		}
		if (cfg_menu_rewind1_enabled || cfg_menu_rewind2_enabled || cfg_menu_rewind3_enabled || cfg_menu_rewind4_enabled || cfg_menu_fastforward1_enabled || cfg_menu_fastforward2_enabled || cfg_menu_fastforward3_enabled || cfg_menu_fastforward4_enabled)
		{
			cfg_playtime.get(playtime);
			playtime2 = atoi(playtime);
		}
	}
	virtual void on_playback_stop(play_control::t_stop_reason p_reason)
	{
		//p_reason: 0=user;1=eof;2=starting another;3=shuting down
		if (p_reason == 0 || p_reason == 1 || p_reason == 3)
		{
			if (cfg_automatic_start_stop_enabled)
			{
				option::set_option(1);
			}
			KillTimer(NULL,ptr2);
			KillTimer(NULL,ptr3);
			cfg_playback_position_preview.get(playback_position_preview_string);
			playback_position_preview = atoi(playback_position_preview_string);
			cfg_playback_position_loop.get(playback_position_loop_string);
			playback_position_loop = atoi(playback_position_loop_string);
		}
		if (p_reason == 2 && cfg_menu_loop_enabled && cfg_reset_loop_position_enabled)
		{
			cfg_playback_position_loop.get(playback_position_loop_string);
			playback_position_loop = atoi(playback_position_loop_string);
		}
	}
	virtual void on_playback_seek(double p_time)
	{
		if (cfg_menu_preview_enabled)
		{
			if (length2 >= playback_position_preview + preview2 / 1000 && !cfg_reset_preview_position_enabled)
			{
				playback_position_preview = p_time;
			}
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,preview2,(TIMERPROC)Seek);
		}
		if (cfg_menu_loop_enabled)
		{
			playback_position_loop = p_time;
			if (length2 < playback_position_loop + loop2 / 1000 && !cfg_menu_loop_length_mode_enabled)
			{
				KillTimer(NULL,ptr3);
				ptr3 = SetTimer(NULL,ID_TIMER3,0,(TIMERPROC)Seek2);
			}
			else if (cfg_menu_loop_length_mode_enabled && !set_end_point)
			{
				loop2 = UINT(length2 - 1 - playback_position_loop) * 1000;
				KillTimer(NULL,ptr2);
				ptr2 = SetTimer(NULL,ID_TIMER2,loop2,(TIMERPROC)Seek);
			}
			else
			{
				KillTimer(NULL,ptr2);
				ptr2 = SetTimer(NULL,ID_TIMER2,loop2,(TIMERPROC)Seek);
			}
		}
	}
	virtual void on_playback_pause(bool p_state)
	{
		if (cfg_menu_rewind1_enabled || cfg_menu_rewind2_enabled || cfg_menu_rewind3_enabled || cfg_menu_rewind4_enabled || cfg_menu_fastforward1_enabled || cfg_menu_fastforward2_enabled || cfg_menu_fastforward3_enabled || cfg_menu_fastforward4_enabled)
		{
			if (p_state)
			{
				KillTimer(NULL,ptr2);
			}
			else
			{
				ptr2 = SetTimer(NULL,ID_TIMER2,playtime2,(TIMERPROC)Seek);
			}
		}
	}
	virtual void on_playback_starting(play_control::t_track_command p_command, bool p_paused) {}
	virtual void on_playback_edited(metadb_handle_ptr p_track) {}
	virtual void on_playback_dynamic_info(const file_info & info) {}
	virtual void on_playback_dynamic_info_track(const file_info & info) {}
	virtual void on_playback_time(double p_time) {}
	virtual void on_volume_change(float p_new_val) {}
};

static play_callback_static_factory_t<play_callback_seek> g_play_callback_seek;

//EOF