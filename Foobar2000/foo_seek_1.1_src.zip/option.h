//Helper classes for foo_stopafteralbum.cpp

class option
{

public:

	static void set_option(int p_option)
	{
		if (p_option == 1)
		{
			cfg_menu_fastforward1_enabled = false;
			cfg_menu_fastforward2_enabled = false;
			cfg_menu_fastforward3_enabled = false;
			cfg_menu_fastforward4_enabled = false;
			cfg_menu_rewind1_enabled = false;
			cfg_menu_rewind2_enabled = false;
			cfg_menu_rewind3_enabled = false;
			cfg_menu_rewind4_enabled = false;
			cfg_menu_loop_enabled = false;
			cfg_menu_preview_enabled = false;
		}
		if (p_option == 2)
		{
			cfg_menu_preview_length1_enabled = false;
			cfg_menu_preview_length2_enabled = false;
			cfg_menu_preview_length3_enabled = false;
			cfg_menu_preview_length4_enabled = false;
			cfg_menu_preview_length5_enabled = false;
			cfg_menu_preview_length6_enabled = false;
			cfg_menu_preview_length7_enabled = false;
			cfg_menu_preview_length8_enabled = false;
			cfg_menu_preview_length_default_enabled = false;
		}
		if (p_option == 3)
		{
			cfg_menu_loop_length1_enabled = false;
			cfg_menu_loop_length2_enabled = false;
			cfg_menu_loop_length3_enabled = false;
			cfg_menu_loop_length4_enabled = false;
			cfg_menu_loop_length5_enabled = false;
			cfg_menu_loop_length6_enabled = false;
			cfg_menu_loop_length7_enabled = false;
			cfg_menu_loop_length8_enabled = false;
			cfg_menu_loop_length_default_enabled = false;
			cfg_menu_loop_length_mode_enabled = false;
		}
	}
};

//EOF