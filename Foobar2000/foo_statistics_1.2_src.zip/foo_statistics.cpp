#include "stdafx.h"

#include "config.h"

#define ID_TIMER2 1011

DECLARE_COMPONENT_VERSION(
    "Statistics",
    "1.2",
    "Statistics v1.2\n"
    "Created by grimes\n"
    "Build: " __DATE__ " " __TIME__ "\n\n"
    "Mainmenu commands:\n"
    "Menu | Help | Statistics to console | Session times\n"
    "Menu | Help | Statistics to console | Total times\n"
    "Menu | Help | Statistics to console | Session events\n"
    "Menu | Help | Statistics to console | Total events\n"
    "Menu | Help | Statistics to console | Session averages\n"
    "Menu | Help | Statistics to console | Total averages\n"
    "Menu | Help | Statistics to console | Session codecs\n"
    "Menu | Help | Statistics to console | Total codecs\n"
    "Menu | Help | Statistics to console | Status\n"
    "Menu | Help | Statistics to console | Reset | Reset total times\n"
    "Menu | Help | Statistics to console | Reset | Reset total events\n"
    "Menu | Help | Statistics to console | Reset | Reset total averages\n"
    "Menu | Help | Statistics to console | Reset | Reset total codecs\n"
    "Menu | Help | Statistics to console | Reset | Complete reset\n"
    "Menu | Help | Statistics to console | Monitor events (ON/OFF)"
);

VALIDATE_COMPONENT_FILENAME("foo_statistics.dll");

t_uint32 playback_new_track;
t_uint32 playback_stop;
t_uint32 stop_reason;
t_uint32 playback_seek;
double seek_time;
t_uint32 playback_pause;
t_uint32 playback_starting;
t_uint32 playback_command;
t_uint32 playback_command0;
t_uint32 playback_command1;
t_uint32 playback_command2;
t_uint32 playback_command3;
t_uint32 playback_command4;
t_uint32 playback_command5;
t_uint32 playback_command6;
t_uint32 playback_edited;
t_uint32 playback_dynamic_info;
t_uint32 playback_dynamic_info_track;
double playback_time;
t_uint32 volume_change;
float volume_new_value;
t_uint32 p_reason0;
t_uint32 p_reason1;
t_uint32 p_reason2;
t_uint32 p_reason3;
double total_playback_time;
double startup_time;
double idle_time;
t_uint32 item_played;

t_uint32 items_selection_change;
t_uint32 playlist_activate;
t_uint32 playback_order_changed;
t_uint32 playlist_created;
t_uint32 playlist_renamed;
t_uint32 playlists_removed;
t_uint32 playlists_reorder;

t_uint32 sum;

UINT ptr20;

pfc::string8 tag1;
pfc::string8 tag2;
pfc::string8 tag3;
pfc::string8 tag4;
pfc::string8 tag5;
pfc::string8 tag6;
pfc::string8 tag7;
pfc::string8 tag8;
pfc::string8 tag9;
pfc::string8 tag10;
pfc::string8 tag11;

pfc::string8 a_rating;
pfc::string8 a_playcount;
pfc::string8 a_bitrate;
pfc::string8 a_filesize;
pfc::string8 a_tracklength;
pfc::string8 a_date;
pfc::string8 a_samplerate;
pfc::string8 a_bitspersample;
pfc::string8 a_channels;
pfc::string8 a_encoding;
pfc::string8 a_codec;
pfc::string8 a_version;

pfc::string8 version;

t_uint32 sum_rating;
t_uint32 sum_playcount;
t_uint32 bitrate;
t_uint32 sum_bitrate;
t_uint32 sum_filesize;
t_uint32 sum_tracklength;
t_uint32 date;
t_uint32 sum_date;
t_uint32 samplerate;
t_uint32 bitspersample;
t_uint32 channels;
t_uint32 compression;
t_uint32 sum_compression;

t_uint32 lossless;
t_uint32 lossy;
double lossless_percent;
double lossy_percent;
double total_lossless_percent;
double total_lossy_percent;

t_uint32 mono;
t_uint32 stereo;
t_uint32 other;
double mono_percent;
double stereo_percent;
double total_mono_percent;
double total_stereo_percent;

t_uint32 sample11025;
t_uint32 sample22050;
t_uint32 sample44100;
t_uint32 sample48000;
t_uint32 sample88200;
t_uint32 sample96000;
t_uint32 sample192000;
t_uint32 sampleother;
double sample44100_percent;
double sample48000_percent;
double total_sample44100_percent;
double total_sample48000_percent;

t_uint32 bits8;
t_uint32 bits12;
t_uint32 bits16;
t_uint32 bits24;
t_uint32 bits32;
t_uint32 bitsother;
double bits16_percent;
double bits24_percent;
double total_bits16_percent;
double total_bits24_percent;

t_uint32 cdda;
t_uint32 shorten;
t_uint32 flac;
t_uint32 mp3;
t_uint32 mp2;
t_uint32 pcm;
t_uint32 monkeys;
t_uint32 tak;
t_uint32 alac;
t_uint32 musepack;
t_uint32 optimfrog;
t_uint32 dualstream;
t_uint32 vorbis;
t_uint32 speex;
t_uint32 trueaudio;
t_uint32 wavpack;
t_uint32 wma;
t_uint32 aac;
t_uint32 othercodec;

SYSTEMTIME systime;

double average_trackplaybacktime;
double average_rating;
double average_playcount;
double average_bitrate;
t_uint32 average_filesize;
double average_tracklength;
t_uint32 average_date;
t_uint32 average_compression;
double playbacktime_percent;

double total_average_trackplaybacktime;
double total_average_rating;
double total_average_playcount;
double total_average_bitrate;
t_uint32 total_average_filesize;
double total_average_tracklength;
double total_average_date;
t_uint32 total_average_compression;
double total_playbacktime_percent;

t_uint32 library_items_added_count;
t_uint32 library_items_modified_count;
t_uint32 library_items_removed_count;
t_uint32 library_items_added;
t_uint32 library_items_modified;
t_uint32 library_items_removed;

VOID CALLBACK Startup(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent3,     // timer identifier
    DWORD dwTime)     // current system time
{
	startup_time++;
	cfg_startup_time = cfg_startup_time + 1;
}

class start : public initquit
{

public:

	virtual void on_init()
	{
		ptr20 = SetTimer(NULL, ID_TIMER2, 1000, (TIMERPROC)Startup);
		cfg_init = cfg_init + 1;
		cfg_init2 = cfg_init2 + 1;
		if (!cfg_playback_new_track_average == 0)
		{
			total_average_trackplaybacktime = double(cfg_total_playback_time_average) / double(cfg_playback_new_track_average);
			total_average_rating = double(cfg_sum_rating) / double(cfg_playback_new_track_average);
			total_average_playcount = double(cfg_sum_playcount) / double(cfg_playback_new_track_average);
			total_average_bitrate = double(cfg_sum_bitrate) / double(cfg_playback_new_track_average);
			total_average_filesize = cfg_sum_filesize / cfg_playback_new_track_average;
			total_average_tracklength = double(cfg_sum_tracklength) / double(cfg_playback_new_track_average);
			total_average_date = double(cfg_sum_date) / double(cfg_playback_new_track_average);
			total_average_compression = cfg_sum_compression / cfg_playback_new_track_average;
			total_playbacktime_percent = double(total_average_trackplaybacktime) * 100 / double(total_average_tracklength);
		}
		GetSystemTime(&systime);
		if (cfg_timesyear == 0)
		{
			cfg_timesyear = systime.wYear;
			cfg_timesmonth = systime.wMonth;
			cfg_timesday = systime.wDay;
			cfg_timeshour = systime.wHour;
			cfg_timesminute = systime.wMinute;
			cfg_timessecond = systime.wSecond;
		}
		if (cfg_eventsyear == 0)
		{
			cfg_eventsyear = systime.wYear;
			cfg_eventsmonth = systime.wMonth;
			cfg_eventsday = systime.wDay;
			cfg_eventshour = systime.wHour;
			cfg_eventsminute = systime.wMinute;
			cfg_eventssecond = systime.wSecond;
			cfg_averagesyear = systime.wYear;
		}
		if (cfg_averagesyear == 0)
		{
			cfg_averagesmonth = systime.wMonth;
			cfg_averagesday = systime.wDay;
			cfg_averageshour = systime.wHour;
			cfg_averagesminute = systime.wMinute;
			cfg_averagessecond = systime.wSecond;
			cfg_codecsyear = systime.wYear;
		}
		if (cfg_codecsyear == 0)
		{
			cfg_codecsmonth = systime.wMonth;
			cfg_codecsday = systime.wDay;
			cfg_codecshour = systime.wHour;
			cfg_codecsminute = systime.wMinute;
			cfg_codecssecond = systime.wSecond;
		}
		a_version = static_api_ptr_t<core_version_info_v2>()->get_version_as_text();
		if (cfg_old_version == "")
		{
			cfg_old_version = a_version;
			cfg_version_history = a_version;
			cfg_version_count = 1;
		}
		if (cfg_old_version != a_version)
		{
			cfg_version_count = cfg_version_count + 1;
			cfg_old_version = a_version;
			cfg_version_history.add_string(", ", 2);
			cfg_version_history.add_string(a_version, a_version.length());
		}
	}
	virtual void on_quit()
	{
		KillTimer(NULL, ptr20);
	}
};

initquit_factory_t<start> g_start;


// {528A79E4-4C53-4BA9-82BE-A2CA35BF16D2}
static const GUID guid_cfg_menu_statistics = { 0x528a79e4, 0x4c53, 0x4ba9, { 0x82, 0xbe, 0xa2, 0xca, 0x35, 0xbf, 0x16, 0xd2 } };


class mainmenu_commands_statistics : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 9;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {4AF34345-2232-42F2-BE8E-A66C4A316575}
		static const GUID guid_main_times_session_toggle = { 0x4af34345, 0x2232, 0x42f2, { 0xbe, 0x8e, 0xa6, 0x6c, 0x4a, 0x31, 0x65, 0x75 } };
		// {1A500F4B-5B4F-4070-B068-0924155C4A29}
		static const GUID guid_main_times_total_toggle = { 0x1a500f4b, 0x5b4f, 0x4070, { 0xb0, 0x68, 0x9, 0x24, 0x15, 0x5c, 0x4a, 0x29 } };
		// {BD2E1F49-B7DC-4C5F-8D2B-A160F08D3BF1}
		static const GUID guid_main_statistics_session_toggle = { 0xbd2e1f49, 0xb7dc, 0x4c5f, { 0x8d, 0x2b, 0xa1, 0x60, 0xf0, 0x8d, 0x3b, 0xf1 } };
		// {44149CDF-7952-4F7F-A9D5-9B513B24452C}
		static const GUID guid_main_statistics_total_toggle = { 0x44149cdf, 0x7952, 0x4f7f, { 0xa9, 0xd5, 0x9b, 0x51, 0x3b, 0x24, 0x45, 0x2c } };
		// {845980F4-8DDC-48D7-A9B2-2147D71CE4A9}
		static const GUID guid_main_average_session_toggle = { 0x845980f4, 0x8ddc, 0x48d7, { 0xa9, 0xb2, 0x21, 0x47, 0xd7, 0x1c, 0xe4, 0xa9 } };
		// {ABE1BD24-3F46-4A77-9E21-F52225E6E670}
		static const GUID guid_main_average_total_toggle = { 0xabe1bd24, 0x3f46, 0x4a77, { 0x9e, 0x21, 0xf5, 0x22, 0x25, 0xe6, 0xe6, 0x70 } };
		// {B2C8156C-7A7C-4562-8F9E-800964C53647}
		static const GUID guid_main_codecs_session_toggle = { 0xb2c8156c, 0x7a7c, 0x4562, { 0x8f, 0x9e, 0x80, 0x9, 0x64, 0xc5, 0x36, 0x47 } };
		// {93A5E38E-9F2D-4F27-A7C4-1B584B2E7FCF}
		static const GUID guid_main_codecs_total_toggle = { 0x93a5e38e, 0x9f2d, 0x4f27, { 0xa7, 0xc4, 0x1b, 0x58, 0x4b, 0x2e, 0x7f, 0xcf } };
		// {07E43324-0385-4BC8-A2E2-35E7F49FE6A1}
		static const GUID guid_main_status_toggle = { 0x7e43324, 0x385, 0x4bc8, { 0xa2, 0xe2, 0x35, 0xe7, 0xf4, 0x9f, 0xe6, 0xa1 } };


		if (p_index == 0)
			return guid_main_times_session_toggle;
		if (p_index == 1)
			return guid_main_times_total_toggle;
		if (p_index == 2)
			return guid_main_statistics_session_toggle;
		if (p_index == 3)
			return guid_main_statistics_total_toggle;
		if (p_index == 4)
			return guid_main_average_session_toggle;
		if (p_index == 5)
			return guid_main_average_total_toggle;
		if (p_index == 6)
			return guid_main_codecs_session_toggle;
		if (p_index == 7)
			return guid_main_codecs_total_toggle;
		if (p_index == 8)
			return guid_main_status_toggle;

		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Session times";
		if (p_index == 1)
			p_out = "Total times";
		if (p_index == 2)
			p_out = "Session events";
		if (p_index == 3)
			p_out = "Total events";
		if (p_index == 4)
			p_out = "Session averages";
		if (p_index == 5)
			p_out = "Total averages";
		if (p_index == 6)
			p_out = "Session codecs";
		if (p_index == 7)
			p_out = "Total codecs";
		if (p_index == 8)
			p_out = "Status";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Send times of the session to console";
		else if (p_index == 1)
			p_out = "Send total times to console";
		else if (p_index == 2)
			p_out = "Send events of the session to console";
		else if (p_index == 3)
			p_out = "Send total events to console";
		else if (p_index == 4)
			p_out = "Send averages of the session to console";
		else if (p_index == 5)
			p_out = "Send total averages to console";
		else if (p_index == 6)
			p_out = "Send codecs of the session to console";
		else if (p_index == 7)
			p_out = "Send total codecs to console";
		else if (p_index == 8)
			p_out = "Send status information to console";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it bet_uint64 s to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_statistics;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			console::info("======== session times ========");
			console::formatter() << "session time: " << t_uint64(startup_time) / 24 / 60 / 60 << "d " << t_uint64(startup_time) / 60 / 60 % 24 << "h " << t_uint64(startup_time) / 60 % 60 << "m " << t_uint64(startup_time) % 60 << "s";
			console::formatter() << "session playback time: " << t_uint64(total_playback_time) / 24 / 60 / 60 << "d " <<  t_uint64(total_playback_time) / 60 / 60 % 24 << "h " << t_uint64(total_playback_time) / 60 % 60 << "m " << t_uint64(total_playback_time) % 60 << "s (" << total_playback_time / startup_time * 100 << "% of total time)";
			idle_time = startup_time - total_playback_time;
			console::formatter() << "session idle time: " << t_uint64(idle_time) / 24 / 60 / 60 << "d " << t_uint64(idle_time) / 60 / 60 % 24 << "h " << t_uint64(idle_time) / 60 % 60 << "m " << t_uint64(idle_time) % 60 << "s";
			console::info("-----------------");
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			console::info("======== total times ========");
			console::formatter() << "total time: " << cfg_startup_time / 24 / 60 / 60 << "d " << cfg_startup_time / 60 / 60 % 24 << "h " << cfg_startup_time / 60 % 60 << "m " << cfg_startup_time % 60 << "s";
			console::formatter() << "total playback time: " <<  cfg_total_playback_time / 24 / 60 / 60 << "d " << cfg_total_playback_time / 60 / 60 % 24 << "h " << cfg_total_playback_time / 60 % 60 << "m " << cfg_total_playback_time % 60 << "s (" << double(cfg_total_playback_time) / double(cfg_startup_time) * 100 << "% of total time)";
			cfg_idle_time = cfg_startup_time - cfg_total_playback_time;
			console::formatter() << "total idle time: " <<  cfg_idle_time / 24 / 60 / 60 << "d " << cfg_idle_time / 60 / 60 % 24 << "h " << cfg_idle_time / 60 % 60 << "m " << cfg_idle_time % 60 << "s";
			console::formatter() << "on_init: " << cfg_init;
			console::formatter() << "average session time: " << (cfg_startup_time / cfg_init) / 24 / 60 / 60 << "d " << (cfg_startup_time / cfg_init) / 60 / 60 % 24 << "h " << (cfg_startup_time / cfg_init) / 60 % 60 << "m " << (cfg_startup_time / cfg_init) % 60 << "s";
			console::formatter() << "average session playback time: " << (cfg_total_playback_time / cfg_init) / 24 / 60 / 60 << "d " << (cfg_total_playback_time / cfg_init) / 60 / 60 % 24 << "h " << (cfg_total_playback_time / cfg_init) / 60 % 60 << "m " << (cfg_total_playback_time / cfg_init) % 60 << "s";
			console::info("======== system ========");
			if (cfg_version_history != "")
			{
				console::formatter() << "version history: foobar2000 " << cfg_version_history;
				console::formatter() << "installed versions: " << cfg_version_count;
			}
			if (core_api::is_portable_mode_enabled())
			{
				console::formatter() << "portable mode = true";
			}
			else
			{
				console::formatter() << "portable mode = false";
			}
			console::formatter() << "profile path: " << core_api::get_profile_path();
			OSVERSIONINFOEX osvi;
			ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
			osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
			GetVersionEx((OSVERSIONINFO*)&osvi);
			int build_number = osvi.dwBuildNumber;
			int major_version = osvi.dwMajorVersion;
			int minor_version = osvi.dwMinorVersion;
			int platform_id = osvi.dwPlatformId;
			int service_pack_major = osvi.wServicePackMajor;
			int service_pack_minor = osvi.wServicePackMinor;
			int product_type = osvi.wProductType;
			console::formatter() << "OS: " << platform_id << "." << major_version << "." << minor_version << "."  << build_number << " (SP"  << service_pack_major << "." << service_pack_minor << ")";
			console::info("-----------------");
			if (cfg_timesyear > 0)
			{
				console::formatter() << "(last reset: " << cfg_timesyear << "-" << cfg_timesmonth << "-" << cfg_timesday << "  " << cfg_timeshour << "h " << cfg_timesminute << "m " << cfg_timessecond << "s)";
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			console::info("======== session events ========");
			console::info("-------- playback events --------");
			console::formatter() << "on_playback_new_track: " << playback_new_track;
			pfc::string8 playback_stop_reason;
			switch (stop_reason)
			{
			case 0:
				playback_stop_reason = "0 user";
				break;
			case 1:
				playback_stop_reason = "1 end of file";
				break;
			case 2:
				playback_stop_reason = "2 starting another";
				break;
			case 3:
				playback_stop_reason = "3 shuting down";
				break;

			default:
				playback_stop_reason = "undetermined";
			}
			console::formatter() << "on_playback_stop: " << playback_stop;
			console::formatter() << "----- last reason: " << playback_stop_reason;
			console::formatter() << "----------0 user: " << p_reason0;
			console::formatter() << "----------1 end of file: " << p_reason1;
			console::formatter() << "----------2 starting another: " << p_reason2;
			console::formatter() << "----------3 shuting down: " << p_reason3;
			console::formatter() << "on_playback_seek: " << playback_seek;
			console::formatter() << "----- last seek time: " << seek_time;
			console::formatter() << "on_playback_pause: " << playback_pause;
			pfc::string8 starting_command;
			switch (playback_command)
			{
			case 0:
				starting_command = "0 default";
				break;
			case 1:
				starting_command = "1 play";
				break;
			case 2:
				starting_command = "2 next";
				break;
			case 3:
				starting_command = "3 previous";
				break;
			case 4:
				starting_command = "4 settrack";
				break;
			case 5:
				starting_command = "5 random";
				break;
			case 6:
				starting_command = "6 resume";
				break;

			default:
				starting_command = "undetermined";
			}
			console::formatter() << "on_playback_starting: " << playback_starting;
			console::formatter() << "----- last command: " << starting_command;
			//console::formatter() << "-----------0 default: " << playback_command0;
			console::formatter() << "-----------1 play: " << playback_command1;
			console::formatter() << "-----------2 next: " << playback_command2;
			console::formatter() << "-----------3 previous: " << playback_command3;
			console::formatter() << "-----------4 settrack: " << playback_command4;
			console::formatter() << "-----------5 random: " << playback_command5;
			console::formatter() << "-----------6 resume: " << playback_command6;
			console::formatter() << "on_playback_edited: " << playback_edited;
			console::formatter() << "on_playback_dynamic_info: " << playback_dynamic_info;
			console::formatter() << "on_playback_dynamic_info_track: " << playback_dynamic_info_track;
			console::formatter() << "on_playback_time: " << playback_time;
			console::formatter() << "on_volume_change: " << volume_change;
			console::formatter() << "----- volume: " << volume_new_value;
			console::info("-------- playlist events ---------");
			console::formatter() << "on_items_selection_change: " << items_selection_change;
			console::formatter() << "on_playlist_activate: " << playlist_activate;
			console::formatter() << "on_playlist_created: " << playlist_created;
			console::formatter() << "on_playlist_renamed: " << playlist_renamed;
			console::formatter() << "on_playlists_removed: " << playlists_removed;
			console::formatter() << "on_playlists_reorder: " << playlists_reorder;
			console::info("-------- library events ---------");
			console::formatter() << "on_items_added: " << library_items_added;
			console::formatter() << "(items added: " << library_items_added_count << ")";
			console::formatter() << "on_items_removed: " << library_items_removed;
			console::formatter() << "(items removed: " << library_items_removed_count << ")";
			console::formatter() << "on_items_modified: " << library_items_modified;
			console::formatter() << "(items modified: " << library_items_modified_count << ")";
			console::info("-------- other events ---------");
			console::formatter() << "on_item_played: " << item_played;
			console::formatter() << "on_playback_order_changed: " << playback_order_changed;
			sum = playback_new_track + playback_stop + playback_seek + playback_pause + playback_starting + playback_edited + playback_dynamic_info + playback_dynamic_info_track + volume_change + items_selection_change + playlist_activate + playback_order_changed + playlist_created + playlist_renamed + playlists_removed + playlists_reorder + item_played + library_items_removed + library_items_added + library_items_modified;
			console::formatter() << "--------- [session events sum: " << sum << "] --------";
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			console::info("======== total events ========");
			console::info("--------- playback events ---------");
			console::formatter() << "on_init: " << cfg_init2;
			if (cfg_init == 0)
			{
				cfg_init = 1;
			}
			console::formatter() << "on_playback_new_track: " << cfg_playback_new_track;
			pfc::string8 playback_stop_reason;
			switch (stop_reason)
			{
			case 0:
				playback_stop_reason = "0 user";
				break;
			case 1:
				playback_stop_reason = "1 end of file";
				break;
			case 2:
				playback_stop_reason = "2 starting another";
				break;
			case 3:
				playback_stop_reason = "3 shuting down";
				break;

			default:
				playback_stop_reason = "undetermined";
			}
			console::formatter() << "on_playback_stop: " << cfg_playback_stop;
			console::formatter() << "----- last reason: " << playback_stop_reason;
			console::formatter() << "----------0 user: " << cfg_p_reason0;
			console::formatter() << "----------1 end of file: " << cfg_p_reason1;
			console::formatter() << "----------2 starting another: " << cfg_p_reason2;
			console::formatter() << "----------3 shuting down: " << cfg_p_reason3;
			console::formatter() << "on_playback_seek: " << cfg_playback_seek;
			console::formatter() << "----- last seek time: " << seek_time;
			console::formatter() << "on_playback_pause: " << cfg_playback_pause;
			pfc::string8 starting_command;
			switch (playback_command)
			{
			case 0:
				starting_command = "0 default";
				break;
			case 1:
				starting_command = "1 play";
				break;
			case 2:
				starting_command = "2 next";
				break;
			case 3:
				starting_command = "3 previous";
				break;
			case 4:
				starting_command = "4 settrack";
				break;
			case 5:
				starting_command = "5 random";
				break;
			case 6:
				starting_command = "6 resume";
				break;

			default:
				starting_command = "undetermined";
			}
			console::formatter() << "on_playback_starting: " << cfg_playback_starting;
			console::formatter() << "----- last command: " << starting_command;
			//console::formatter() << "-----------0 default: " << cfg_playback_command0;
			console::formatter() << "-----------1 play: " << cfg_playback_command1;
			console::formatter() << "-----------2 next: " << cfg_playback_command2;
			console::formatter() << "-----------3 previous: " << cfg_playback_command3;
			console::formatter() << "-----------4 settrack: " << cfg_playback_command4;
			console::formatter() << "-----------5 random: " << cfg_playback_command5;
			console::formatter() << "-----------6 resume: " << cfg_playback_command6;
			console::formatter() << "on_playback_edited: " << cfg_playback_edited;
			console::formatter() << "on_playback_dynamic_info: " << cfg_playback_dynamic_info;
			console::formatter() << "on_playback_dynamic_info_track: " << cfg_playback_dynamic_info_track;
			console::formatter() << "on_playback_time: " << playback_time;
			console::formatter() << "on_volume_change: " << cfg_volume_change;
			console::formatter() << "----- volume: " << volume_new_value;
			console::info("--------- playlist events ---------");
			console::formatter() << "on_items_selection_change: " << cfg_items_selection_change;
			console::formatter() << "on_playlist_activate: " << cfg_playlist_activate;
			console::formatter() << "on_playlist_created: " << cfg_playlist_created;
			console::formatter() << "on_playlist_renamed: " << cfg_playlist_renamed;
			console::formatter() << "on_playlists_removed: " << cfg_playlists_removed;
			console::formatter() << "on_playlists_reorder: " << cfg_playlists_reorder;
			console::info("-------- library events ---------");
			console::formatter() << "on_items_added: " << cfg_library_items_added;
			console::formatter() << "(items added: " << cfg_library_items_added_count << ")";
			console::formatter() << "on_items_removed: " << cfg_library_items_removed;
			console::formatter() << "(items removed: " << cfg_library_items_removed_count << ")";
			console::formatter() << "on_items_modified: " << cfg_library_items_modified;
			console::formatter() << "(items modified: " << cfg_library_items_modified_count << ")";
			console::info("--------- other events ---------");
			console::formatter() << "on_item_played: " << cfg_item_played;
			console::formatter() << "on_playback_order_changed: " << cfg_playback_order_changed;
			cfg_sum = cfg_playback_new_track + cfg_playback_stop + cfg_playback_seek + cfg_playback_pause + cfg_playback_starting + cfg_playback_edited + cfg_playback_dynamic_info + cfg_playback_dynamic_info_track + cfg_volume_change + cfg_init + cfg_items_selection_change + cfg_playlist_activate + cfg_playback_order_changed + cfg_playlist_created + cfg_playlist_renamed + cfg_playlists_removed + cfg_playlists_reorder + cfg_item_played + cfg_library_items_removed + cfg_library_items_added + cfg_library_items_modified;
			console::formatter() << "--------- [total events sum: " << cfg_sum << "] ---------";
			if (cfg_eventsyear > 0)
			{
				console::formatter() << "(last reset: " << cfg_eventsyear << "-" << cfg_eventsmonth << "-" << cfg_eventsday << "  " << cfg_eventshour << "h " << cfg_eventsminute << "m " << cfg_eventssecond << "s)";
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			console::info("======== session averages ========");
			console::formatter() << "tracks started: " << playback_new_track;
			console::info("-----------------");
			console::formatter() << "track playback time: " << t_uint64(average_trackplaybacktime) / 60 << "m " << t_uint64(average_trackplaybacktime) % 60 << "s (" << playbacktime_percent << " % of tracklength)";
			console::formatter() << "tracklength: " << t_uint64(average_tracklength) / 60 << "m " << t_uint64(average_tracklength) % 60 << "s";
			console::formatter() << "rating: " << average_rating;
			console::formatter() << "playcount: " << average_playcount;
			console::formatter() << "bitrate: " << average_bitrate << " kbps";
			console::formatter() << "filesize: " << average_filesize << " MB";

			console::formatter() << "date: " << t_uint64(average_date);
			console::formatter() << "compression: " << average_compression << " %";
			console::info("-----------------");
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			console::info("======== total averages ========");
			console::formatter() << "tracks started: " << cfg_playback_new_track_average;
			console::info("-----------------");
			console::formatter() << "track playback time: " << t_uint64(total_average_trackplaybacktime) / 60 << "m " << t_uint64(total_average_trackplaybacktime) % 60 << "s (" << total_playbacktime_percent << " % of tracklength)";
			console::formatter() << "tracklength: " << t_uint64(total_average_tracklength) / 60 << "m " << t_uint64(total_average_tracklength) % 60 << "s";
			console::formatter() << "rating: " << total_average_rating;
			console::formatter() << "playcount: " << total_average_playcount;
			console::formatter() << "bitrate: " << total_average_bitrate << " kbps";
			console::formatter() << "filesize: " << total_average_filesize << " MB";

			console::formatter() << "date: " << t_uint64(total_average_date);
			console::formatter() << "compression: " << total_average_compression << " %";
			console::info("-----------------");
			if (cfg_averagesyear > 0)
			{
				console::formatter() << "(last reset: " << cfg_averagesyear << "-" << cfg_averagesmonth << "-" << cfg_averagesday << "  " << cfg_averageshour << "h " << cfg_averagesminute << "m " << cfg_averagessecond << "s)";
			}
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			console::info("======== session codecs ========");
			if (cdda > 0)
			{
				console::formatter() << "CDDA: " << cdda;
			}
			if (flac > 0)
			{
				console::formatter() << "FLAC: " << flac;
			}
			if (mp3 > 0)
			{
				console::formatter() << "MP3: " << mp3;
			}
			if (mp2 > 0)
			{
				console::formatter() << "MP2: " << mp2;
			}
			if (pcm > 0)
			{
				console::formatter() << "PCM: " << pcm;
			}
			if (monkeys > 0)
			{
				console::formatter() << "Monkey's Audio: " << monkeys;
			}
			if (tak > 0)
			{
				console::formatter() << "TAK: " << tak;
			}
			if (alac > 0)
			{
				console::formatter() << "ALAC: " << alac;
			}
			if (musepack > 0)
			{
				console::formatter() << "Musepack: " << musepack;
			}
			if (optimfrog > 0)
			{
				console::formatter() << "OptimFROG: " << optimfrog;
			}
			if (dualstream > 0)
			{
				console::formatter() << "DualStream: " << dualstream;
			}
			if (vorbis > 0)
			{
				console::formatter() << "Vorbis: " << vorbis;
			}
			if (speex > 0)
			{
				console::formatter() << "Speex: " << speex;
			}
			if (trueaudio > 0)
			{
				console::formatter() << "True Audio: " << trueaudio;
			}
			if (wavpack > 0)
			{
				console::formatter() << "Wavpack: " << wavpack;
			}
			if (wma > 0)
			{
				console::formatter() << "WMA: " << wma;
			}
			if (aac > 0)
			{
				console::formatter() << "AAC: " << aac;
			}
			if (shorten > 0)
			{
				console::formatter() << "Shorten: " << shorten;
			}
			if (othercodec > 0)
			{
				console::formatter() << "other: " << othercodec;
			}
			console::info("-------- encoding --------");
			console::formatter() << "lossless: " << lossless;
			console::formatter() << "lossy: " << lossy;
			if (lossless > 0 || lossy > 0)
			{
				console::info("-----------------");
				lossless_percent = double(lossless) * 100 / double(lossy + lossless);
				lossy_percent = double(lossy) * 100 / double(lossy + lossless);
				console::formatter() << "lossless/lossy: " << lossless_percent << "% / " << lossy_percent << "%";
			}
			console::info("-------- channels --------");
			console::formatter() << "stereo: " << stereo;
			console::formatter() << "mono: " << mono;
			console::formatter() << "other: " << other;
			if (mono > 0 || stereo > 0 || other > 0)
			{
				console::info("-----------------");
				stereo_percent = double(stereo) * 100 / double(mono + stereo + other);
				mono_percent = double(mono) * 100 / double(mono + stereo + other);
				console::formatter() << "stereo/mono: " << stereo_percent << "% / " << mono_percent << "%";
			}
			console::info("-------- sample rate --------");
			console::formatter() << "11025Hz: " << sample11025;
			console::formatter() << "22050Hz: " << sample22050;
			console::formatter() << "44100Hz: " << sample44100;
			console::formatter() << "48000Hz: " << sample48000;
			console::formatter() << "88200Hz: " << sample88200;
			console::formatter() << "96000Hz: " << sample96000;
			console::formatter() << "192000Hz: " << sample192000;
			console::formatter() << "other: " << sampleother;
			if (sample11025 > 0 || sample22050 > 0 || sample44100 > 0 || sample48000 > 0 || sample88200 > 0 || sample96000 > 0 || sample192000 > 0 || sampleother > 0)
			{
				console::info("-----------------");
				sample44100_percent = double(sample44100) * 100 / double(sample11025 + sample22050 + sample44100 + sample48000 + sample88200 + sample96000 + sample192000 + sampleother);
				sample48000_percent = double(sample48000) * 100 / double(sample11025 + sample22050 + sample44100 + sample48000 + sample88200 + sample96000 + sample192000 + sampleother);
				console::formatter() << "44.1kHz(CD)/48kHz(DVD): " << sample44100_percent << "% / " << sample48000_percent << "%";
			}
			console::info("-------- bits per sample --------");
			console::formatter() << "8bits: " << bits8;
			console::formatter() << "12bits: " << bits12;
			console::formatter() << "16bits: " << bits16;
			console::formatter() << "24bits: " << bits24;
			console::formatter() << "32bits: " << bits32;
			console::formatter() << "other: " << bitsother;
			if (bits8 > 0 || bits12 > 0 || bits16 > 0 || bits24 > 0 || bits32 > 0 || bitsother > 0)
			{
				console::info("-----------------");
				bits16_percent = double(bits16) * 100 / double(bits8 + bits12 + bits16 + bits24 + bits32 + bitsother);
				bits24_percent = double(bits24) * 100 / double(bits8 + bits12 + bits16 + bits24 + bits32 + bitsother);
				console::formatter() << "16bits/24bits: " << bits16_percent << "% / " << bits24_percent << "%";
			}
			console::info("-----------------");
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			console::info("======== total codecs ========");
			if (cfg_cdda > 0)
			{
				console::formatter() << "CDDA: " << cfg_cdda;
			}
			if (cfg_flac > 0)
			{
				console::formatter() << "FLAC: " << cfg_flac;
			}
			if (cfg_mp3 > 0)
			{
				console::formatter() << "MP3: " << cfg_mp3;
			}
			if (cfg_mp2 > 0)
			{
				console::formatter() << "MP2: " << cfg_mp2;
			}
			if (cfg_pcm > 0)
			{
				console::formatter() << "PCM: " << cfg_pcm;
			}
			if (cfg_monkeys > 0)
			{
				console::formatter() << "Monkey's Audio: " << cfg_monkeys;
			}
			if (cfg_tak > 0)
			{
				console::formatter() << "TAK: " << cfg_tak;
			}
			if (cfg_alac > 0)
			{
				console::formatter() << "ALAC: " << cfg_alac;
			}
			if (cfg_musepack > 0)
			{
				console::formatter() << "Musepack: " << cfg_musepack;
			}
			if (cfg_optimfrog > 0)
			{
				console::formatter() << "OptimFROG: " << cfg_optimfrog;
			}
			if (cfg_dualstream > 0)
			{
				console::formatter() << "DualStream: " << cfg_dualstream;
			}
			if (cfg_vorbis > 0)
			{
				console::formatter() << "Vorbis: " << cfg_vorbis;
			}
			if (cfg_speex > 0)
			{
				console::formatter() << "Speex: " << cfg_speex;
			}
			if (cfg_trueaudio > 0)
			{
				console::formatter() << "True Audio: " << cfg_trueaudio;
			}
			if (cfg_wavpack > 0)
			{
				console::formatter() << "Wavpack: " << cfg_wavpack;
			}
			if (cfg_wma > 0)
			{
				console::formatter() << "WMA: " << cfg_wma;
			}
			if (cfg_aac > 0)
			{
				console::formatter() << "AAC: " << cfg_aac;
			}
			if (cfg_shorten > 0)
			{
				console::formatter() << "Shorten: " << cfg_shorten;
			}
			if (cfg_othercodec > 0)
			{
				console::formatter() << "other: " << cfg_othercodec;
			}
			console::info("-------- encoding --------");
			console::formatter() << "lossless: " << cfg_lossless;
			console::formatter() << "lossy: " << cfg_lossy;
			if (cfg_lossless > 0 || cfg_lossy > 0)
			{
				console::info("-----------------");
				total_lossless_percent = double(cfg_lossless) * 100 / double(cfg_lossy + cfg_lossless);
				total_lossy_percent = double(cfg_lossy) * 100 / double(cfg_lossy + cfg_lossless);
				console::formatter() << "lossless/lossy: " << total_lossless_percent << "% / " << total_lossy_percent << "%";
			}
			console::info("-------- channels --------");
			console::formatter() << "stereo: " << cfg_stereo;
			console::formatter() << "mono: " << cfg_mono;
			console::formatter() << "other: " << cfg_other;
			if (cfg_mono > 0 || cfg_stereo > 0 || cfg_other > 0)
			{
				console::info("-----------------");
				total_stereo_percent = double(cfg_stereo) * 100 / double(cfg_mono + cfg_stereo + cfg_other);
				total_mono_percent = double(cfg_mono) * 100 / double(cfg_mono + cfg_stereo + cfg_other);
				console::formatter() << "stereo/mono: " << total_stereo_percent << "% / " << total_mono_percent << "%";
			}
			console::info("-------- sample rate --------");
			console::formatter() << "11025Hz: " << cfg_sample11025;
			console::formatter() << "22050Hz: " << cfg_sample22050;
			console::formatter() << "44100Hz: " << cfg_sample44100;
			console::formatter() << "48000Hz: " << cfg_sample48000;
			console::formatter() << "88200Hz: " << cfg_sample88200;
			console::formatter() << "96000Hz: " << cfg_sample96000;
			console::formatter() << "192000Hz: " << cfg_sample192000;
			console::formatter() << "other: " << cfg_sampleother;
			if (cfg_sample11025 > 0 || cfg_sample22050 > 0 || cfg_sample44100 > 0 || cfg_sample48000 > 0 || cfg_sample88200 > 0 || cfg_sample96000 > 0 || cfg_sample192000 > 0 || cfg_sampleother > 0)
			{
				console::info("-----------------");
				total_sample44100_percent = double(cfg_sample44100) * 100 / double(cfg_sample11025 + cfg_sample22050 + cfg_sample44100 + cfg_sample48000 + cfg_sample88200 + cfg_sample96000 + cfg_sample192000 + cfg_sampleother);
				total_sample48000_percent = double(cfg_sample48000) * 100 / double(cfg_sample11025 + cfg_sample22050 + cfg_sample44100 + cfg_sample48000 + cfg_sample88200 + cfg_sample96000 + cfg_sample192000 + cfg_sampleother);
				console::formatter() << "44.1kHz(CD)/48kHz(DVD): " << total_sample44100_percent << "% / " << total_sample48000_percent << "%";
			}
			console::info("-------- bits per sample --------");
			console::formatter() << "8bits: " << cfg_bits8;
			console::formatter() << "12bits: " << cfg_bits12;
			console::formatter() << "16bits: " << cfg_bits16;
			console::formatter() << "24bits: " << cfg_bits24;
			console::formatter() << "32bits: " << cfg_bits32;
			console::formatter() << "other: " << cfg_bitsother;
			if (cfg_bits8 > 0 || cfg_bits12 > 0 || cfg_bits16 > 0 || cfg_bits24 > 0 || cfg_bits32 > 0 || cfg_bitsother > 0)
			{
				console::info("-----------------");
				total_bits16_percent = double(cfg_bits16) * 100 / double(cfg_bits8 + cfg_bits12 + cfg_bits16 + cfg_bits24 + cfg_bits32 + cfg_bitsother);
				total_bits24_percent = double(cfg_bits24) * 100 / double(cfg_bits8 + cfg_bits12 + cfg_bits16 + cfg_bits24 + cfg_bits32 + cfg_bitsother);
				console::formatter() << "16bits/24bits: " << total_bits16_percent << "% / " << total_bits24_percent << "%";
			}
			console::info("-----------------");
			if (cfg_codecsyear > 0)
			{
				console::formatter() << "(last reset: " << cfg_codecsyear << "-" << cfg_codecsmonth << "-" << cfg_codecsday << "  " << cfg_codecshour << "h " << cfg_codecsminute << "m " << cfg_codecssecond << "s)";
			}
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			console::info("======== status ========");
			pfc::string8 playbackorder;
			switch (static_api_ptr_t<playlist_manager>()->playback_order_get_active())
			{
			case 0:
				playbackorder = "0 default";
				break;
			case 1:
				playbackorder = "1 repeat (playlist)";
				break;
			case 2:
				playbackorder = "2 repeat (track)";
				break;
			case 3:
				playbackorder = "3 random";
				break;
			case 4:
				playbackorder = "4 shuffle (tracks)";
				break;
			case 5:
				playbackorder = "5 shuffle (albums)";
				break;
			case 6:
				playbackorder = "6 shuffle (folders)";
				break;

			default:
				playbackorder = "undetermined";
			}
			if (config_object::g_get_data_bool_simple(standard_config_objects::bool_cursor_follows_playback, false))
			{
				console::formatter() << "cursor follows playback = true";
			}
			else
			{
				console::formatter() << "cursor follows playback = false";
			}
			if (config_object::g_get_data_bool_simple(standard_config_objects::bool_playback_follows_cursor, false))
			{
				console::formatter() << "playback follows cursor = true";
			}
			else
			{
				console::formatter() << "playback follows cursor = false";
			}
			if (static_api_ptr_t<playback_control>()->get_stop_after_current())
			{
				console::formatter() << "stop after current = true";
			}
			else
			{
				console::formatter() << "stop after current = false";
			}
			if (static_api_ptr_t<playback_control>()->is_playing())
			{
				console::formatter() << "playing = true";
			}
			else
			{
				console::formatter() << "playing = false";
			}
			if (static_api_ptr_t<playback_control>()->is_paused())
			{
				console::formatter() << "paused = true";
			}
			else
			{
				console::formatter() << "paused = false";
			}
			if (!(static_api_ptr_t<playback_control>()->is_playing() || static_api_ptr_t<playback_control>()->is_paused()))
			{
				console::formatter() << "stopped = true";
			}
			else
			{
				console::formatter() << "stopped = false";
			}
			if (config_object::g_get_data_bool_simple(standard_config_objects::bool_ui_always_on_top, false))
			{
				console::formatter() << "always on top = true";
			}
			else
			{
				console::formatter() << "always on top = false";
			}
			console::formatter() << "playback order = " << playbackorder;
			console::info("-----------------");
		}
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_statistics> g_mainmenu_commands_statistics;


static mainmenu_group_popup_factory mainmenu_group1(guid_cfg_menu_statistics,
        mainmenu_groups::help, mainmenu_commands::sort_priority_dontcare,
        "Statistics to console");


// {D2094CAD-BB6E-4349-B89C-5DEBF8D86612}
static const GUID guid_cfg_menu_reset = { 0xd2094cad, 0xbb6e, 0x4349, { 0xb8, 0x9c, 0x5d, 0xeb, 0xf8, 0xd8, 0x66, 0x12 } };

class mainmenu_commands_reset : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 5;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {2928A5D3-7C81-4B98-8ED4-8B44698F26E5}
		static const GUID guid_main_times_reset_total_toggle = { 0x2928a5d3, 0x7c81, 0x4b98, { 0x8e, 0xd4, 0x8b, 0x44, 0x69, 0x8f, 0x26, 0xe5 } };
		// {8430658D-54A7-40A9-9A2C-4EB51D6E298D}
		static const GUID guid_main_events_reset_total_toggle = { 0x8430658d, 0x54a7, 0x40a9, { 0x9a, 0x2c, 0x4e, 0xb5, 0x1d, 0x6e, 0x29, 0x8d } };
		// {BEC7E397-05C5-4A6B-8923-430B5695526A}
		static const GUID guid_main_average_reset_total_toggle = { 0xbec7e397, 0x5c5, 0x4a6b, { 0x89, 0x23, 0x43, 0xb, 0x56, 0x95, 0x52, 0x6a } };
		// {1D6AF6F1-7EA8-4D89-AB10-50BA9A7448FD}
		static const GUID guid_main_codecs_reset_total_toggle = { 0x1d6af6f1, 0x7ea8, 0x4d89, { 0xab, 0x10, 0x50, 0xba, 0x9a, 0x74, 0x48, 0xfd } };
		// {8730ADA0-16C3-4603-B882-0D1E44C1E51C}
		static const GUID guid_main_complete_reset_total_toggle = { 0x8730ada0, 0x16c3, 0x4603, { 0xb8, 0x82, 0xd, 0x1e, 0x44, 0xc1, 0xe5, 0x1c } };


		if (p_index == 0)
			return guid_main_times_reset_total_toggle;
		if (p_index == 1)
			return guid_main_events_reset_total_toggle;
		if (p_index == 2)
			return guid_main_average_reset_total_toggle;
		if (p_index == 3)
			return guid_main_codecs_reset_total_toggle;
		if (p_index == 4)
			return guid_main_complete_reset_total_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Reset total times";
		if (p_index == 1)
			p_out = "Reset total events";
		if (p_index == 2)
			p_out = "Reset total averages";
		if (p_index == 3)
			p_out = "Reset total codecs";
		if (p_index == 4)
			p_out = "Complete reset";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Reset only total times items";
		else if (p_index == 1)
			p_out = "Reset only total events items";
		else if (p_index == 2)
			p_out = "Reset only total averages items";
		else if (p_index == 3)
			p_out = "Reset only total codecs items";
		else if (p_index == 4)
			p_out = "Reset all items completely";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it bet_uint64 s to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_reset;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			int Response = MessageBox(NULL, L"Are you sure to reset total times?", L"Reset total times", MB_YESNO);
			if (Response == IDYES)
			{
				cfg_init = 1;
				cfg_total_playback_time = 0;
				cfg_startup_time = 0;
				cfg_idle_time = 0;
				cfg_version_history = "";
				cfg_old_version = "";
				cfg_version_count = 1;
				GetSystemTime(&systime);
				cfg_timesyear = systime.wYear;
				cfg_timesmonth = systime.wMonth;
				cfg_timesday = systime.wDay;
				cfg_timeshour = systime.wHour;
				cfg_timesminute = systime.wMinute;
				cfg_timessecond = systime.wSecond;
				console::info("Total times resetted");
			}
			else
			{
				console::info("Aborted!");
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			int Response = MessageBox(NULL, L"Are you sure to reset total events?", L"Reset total events", MB_YESNO);
			if (Response == IDYES)
			{
				cfg_playback_new_track = 0;
				cfg_playback_stop = 0;
				cfg_playback_seek = 0;
				cfg_playback_pause = 0;
				cfg_playback_starting = 0;
				cfg_playback_command0 = 0;
				cfg_playback_command1 = 0;
				cfg_playback_command2 = 0;
				cfg_playback_command3 = 0;
				cfg_playback_command4 = 0;
				cfg_playback_command5 = 0;
				cfg_playback_command6 = 0;
				cfg_playback_edited = 0;
				cfg_playback_dynamic_info = 0;
				cfg_playback_dynamic_info_track = 0;
				cfg_volume_change = 0;
				cfg_p_reason0 = 0;
				cfg_p_reason1 = 0;
				cfg_p_reason2 = 0;
				cfg_p_reason3 = 0;
				cfg_init2 = 1;
				cfg_items_selection_change = 0;
				cfg_playlist_activate = 0;
				cfg_library_items_added_count = 0;
				cfg_library_items_added = 0;
				cfg_library_items_removed_count = 0;
				cfg_library_items_removed = 0;
				cfg_library_items_modified_count = 0;
				cfg_library_items_modified = 0;
				cfg_playback_order_changed = 0;
				cfg_item_played = 0;
				cfg_sum = 0;
				cfg_eventsyear;
				cfg_eventsmonth;
				cfg_eventsday;
				cfg_eventshour;
				cfg_eventsminute;
				cfg_eventssecond;
				cfg_eventssecond;
				GetSystemTime(&systime);
				cfg_eventsyear = systime.wYear;
				cfg_eventsmonth = systime.wMonth;
				cfg_eventsday = systime.wDay;
				cfg_eventshour = systime.wHour;
				cfg_eventsminute = systime.wMinute;
				cfg_eventssecond = systime.wSecond;
				console::info("Total events resetted");
			}
			else
			{
				console::info("Aborted!");
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			int Response = MessageBox(NULL, L"Are you sure to reset total averages?", L"Reset total averages", MB_YESNO);
			if (Response == IDYES)
			{
				cfg_total_playback_time_average = 0;
				cfg_playback_new_track_average = 0;
				cfg_sum_rating = 0;
				cfg_sum_playcount = 0;
				cfg_sum_bitrate = 0;
				cfg_sum_filesize = 0;
				cfg_sum_tracklength = 0;
				cfg_sum_date = 0;
				cfg_sum_compression = 0;
				total_average_trackplaybacktime = 0;
				total_average_rating = 0;
				total_average_playcount = 0;
				total_average_bitrate = 0;
				total_average_filesize = 0;
				total_average_tracklength = 0;
				total_average_date = 0;
				total_average_compression = 0;
				total_playbacktime_percent = 0;
				GetSystemTime(&systime);
				cfg_averagesyear = systime.wYear;
				cfg_averagesmonth = systime.wMonth;
				cfg_averagesday = systime.wDay;
				cfg_averageshour = systime.wHour;
				cfg_averagesminute = systime.wMinute;
				cfg_averagessecond = systime.wSecond;
				console::info("Total averages resetted");
			}
			else
			{
				console::info("Aborted!");
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			int Response = MessageBox(NULL, L"Are you sure to reset total codecs?", L"Reset total codecs", MB_YESNO);
			if (Response == IDYES)
			{
				cfg_lossless = 0;
				cfg_lossy = 0;
				cfg_mono = 0;
				cfg_stereo = 0;
				cfg_other = 0;
				cfg_sample11025 = 0;
				cfg_sample22050 = 0;
				cfg_sample44100 = 0;
				cfg_sample48000 = 0;
				cfg_sample88200 = 0;
				cfg_sample96000 = 0;
				cfg_sample192000 = 0;
				cfg_sampleother = 0;
				cfg_bits8 = 0;
				cfg_bits12 = 0;
				cfg_bits16 = 0;
				cfg_bits24 = 0;
				cfg_bits32 = 0;
				cfg_bitsother = 0;
				cfg_cdda = 0;
				cfg_shorten = 0;
				cfg_mp3 = 0;
				cfg_mp2 = 0;
				cfg_flac = 0;
				cfg_pcm = 0;
				cfg_monkeys = 0;
				cfg_tak = 0;
				cfg_alac = 0;
				cfg_musepack = 0;
				cfg_optimfrog = 0;
				cfg_dualstream = 0;
				cfg_vorbis = 0;
				cfg_speex = 0;
				cfg_trueaudio = 0;
				cfg_wavpack = 0;
				cfg_wma = 0;
				cfg_aac = 0;
				cfg_othercodec = 0;
				GetSystemTime(&systime);
				cfg_codecsyear = systime.wYear;
				cfg_codecsmonth = systime.wMonth;
				cfg_codecsday = systime.wDay;
				cfg_codecshour = systime.wHour;
				cfg_codecsminute = systime.wMinute;
				cfg_codecssecond = systime.wSecond;
				console::info("Total codecs resetted");
			}
			else
			{
				console::info("Aborted!");
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			int Response = MessageBox(NULL, L"Are you sure to reset completely?", L"Complete Reset", MB_YESNO);
			if (Response == IDYES)
			{
				cfg_total_playback_time = 0;
				cfg_startup_time = 0;
				cfg_idle_time = 0;

				cfg_playback_new_track = 0;
				cfg_playback_stop = 0;
				cfg_playback_seek = 0;
				cfg_playback_pause = 0;
				cfg_playback_starting = 0;
				cfg_playback_command0 = 0;
				cfg_playback_command1 = 0;
				cfg_playback_command2 = 0;
				cfg_playback_command3 = 0;
				cfg_playback_command4 = 0;
				cfg_playback_command5 = 0;
				cfg_playback_command6 = 0;
				cfg_playback_edited = 0;
				cfg_playback_dynamic_info = 0;
				cfg_playback_dynamic_info_track = 0;
				cfg_volume_change = 0;
				cfg_p_reason0 = 0;
				cfg_p_reason1 = 0;
				cfg_p_reason2 = 0;
				cfg_p_reason3 = 0;
				cfg_init = 1;
				cfg_init2 = 1;
				cfg_items_selection_change = 0;
				cfg_playlist_activate = 0;
				cfg_library_items_added_count = 0;
				cfg_library_items_added = 0;
				cfg_library_items_removed_count = 0;
				cfg_library_items_removed = 0;
				cfg_library_items_modified_count = 0;
				cfg_library_items_modified = 0;
				cfg_playback_order_changed = 0;
				cfg_item_played = 0;
				cfg_sum = 0;

				cfg_total_playback_time_average = 0;
				cfg_playback_new_track_average = 0;
				cfg_sum_rating = 0;
				cfg_sum_playcount = 0;
				cfg_sum_bitrate = 0;
				cfg_sum_filesize = 0;
				cfg_sum_tracklength = 0;
				cfg_sum_date = 0;
				cfg_sum_compression = 0;
				total_average_trackplaybacktime = 0;
				total_average_rating = 0;
				total_average_playcount = 0;
				total_average_bitrate = 0;
				total_average_filesize = 0;
				total_average_tracklength = 0;
				total_average_date = 0;
				total_average_compression = 0;
				total_playbacktime_percent = 0;

				cfg_lossless = 0;
				cfg_lossy = 0;
				cfg_mono = 0;
				cfg_stereo = 0;
				cfg_other = 0;
				cfg_sample11025 = 0;
				cfg_sample22050 = 0;
				cfg_sample44100 = 0;
				cfg_sample48000 = 0;
				cfg_sample88200 = 0;
				cfg_sample96000 = 0;
				cfg_sample192000 = 0;
				cfg_sampleother = 0;
				cfg_bits8 = 0;
				cfg_bits12 = 0;
				cfg_bits16 = 0;
				cfg_bits24 = 0;
				cfg_bits32 = 0;
				cfg_bitsother = 0;
				cfg_cdda = 0;
				cfg_shorten = 0;
				cfg_mp3 = 0;
				cfg_mp2 = 0;
				cfg_flac = 0;
				cfg_pcm = 0;
				cfg_monkeys = 0;
				cfg_tak = 0;
				cfg_alac = 0;
				cfg_musepack = 0;
				cfg_optimfrog = 0;
				cfg_dualstream = 0;
				cfg_vorbis = 0;
				cfg_speex = 0;
				cfg_trueaudio = 0;
				cfg_wavpack = 0;
				cfg_wma = 0;
				cfg_aac = 0;
				cfg_othercodec = 0;
				GetSystemTime(&systime);
				cfg_timesyear = systime.wYear;
				cfg_timesmonth = systime.wMonth;
				cfg_timesday = systime.wDay;
				cfg_timeshour = systime.wHour;
				cfg_timesminute = systime.wMinute;
				cfg_timessecond = systime.wSecond;
				cfg_eventsyear = systime.wYear;
				cfg_eventsmonth = systime.wMonth;
				cfg_eventsday = systime.wDay;
				cfg_eventshour = systime.wHour;
				cfg_eventsminute = systime.wMinute;
				cfg_eventssecond = systime.wSecond;
				cfg_averagesyear = systime.wYear;
				cfg_averagesmonth = systime.wMonth;
				cfg_averagesday = systime.wDay;
				cfg_averageshour = systime.wHour;
				cfg_averagesminute = systime.wMinute;
				cfg_averagessecond = systime.wSecond;
				cfg_codecsyear = systime.wYear;
				cfg_codecsmonth = systime.wMonth;
				cfg_codecsday = systime.wDay;
				cfg_codecshour = systime.wHour;
				cfg_codecsminute = systime.wMinute;
				cfg_codecssecond = systime.wSecond;
				console::info("Completely resetted");
			}
			else
			{
				console::info("Aborted!");
			}
		}
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_reset> g_mainmenu_commands_reset;

static mainmenu_group_popup_factory mainmenu_group2(guid_cfg_menu_reset,
        guid_cfg_menu_statistics, mainmenu_commands::sort_priority_last,
        "Reset");

class mainmenu_commands_monitor_events : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 1;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {F5DD98F8-4237-4AE0-B2A0-79DAD011DD05}
		static const GUID guid_main_monitor_events_toggle = { 0xf5dd98f8, 0x4237, 0x4ae0, { 0xb2, 0xa0, 0x79, 0xda, 0xd0, 0x11, 0xdd, 0x5 } };

		if (p_index == 0)
			return guid_main_monitor_events_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Monitor events";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Permanent monitoring of callbacks.";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_statistics;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_main_monitor_events_enabled = !cfg_main_monitor_events_enabled;
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_last;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_main_monitor_events_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_monitor_events> g_mainmenu_commands_monitor_events;



class play_callback_statistics : public play_callback_static
{

public:

	virtual unsigned get_flags(void)
	{
		return(flag_on_playback_new_track | flag_on_playback_stop | flag_on_playback_seek | flag_on_playback_pause | flag_on_playback_starting | flag_on_playback_edited | flag_on_playback_dynamic_info | flag_on_playback_dynamic_info_track | flag_on_playback_time | flag_on_volume_change);
	}

	virtual void on_playback_new_track(metadb_handle_ptr p_track)
	{
		playback_new_track++;
		cfg_playback_new_track = cfg_playback_new_track + 1;
		cfg_playback_new_track_average = cfg_playback_new_track_average + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_playback_new_track");
		}

		p_track->metadb_lock();

		service_ptr_t<titleformat_object> tagobj1;
		service_ptr_t<titleformat_object> tagobj2;
		service_ptr_t<titleformat_object> tagobj3;
		service_ptr_t<titleformat_object> tagobj4;
		service_ptr_t<titleformat_object> tagobj5;
		service_ptr_t<titleformat_object> tagobj6;
		service_ptr_t<titleformat_object> tagobj7;
		service_ptr_t<titleformat_object> tagobj8;
		service_ptr_t<titleformat_object> tagobj9;
		service_ptr_t<titleformat_object> tagobj10;
		service_ptr_t<titleformat_object> tagobj11;

		static_api_ptr_t<titleformat_compiler> compiler;

		tag1 = "%rating%";
		compiler->compile_safe(tagobj1, tag1);
		tag2 = "%play_count%";
		compiler->compile_safe(tagobj2, tag2);
		tag3 = "%date%";
		compiler->compile_safe(tagobj3, tag3);
		tag4 = "%bitrate%";
		compiler->compile_safe(tagobj4, tag4);
		tag5 = "%filesize%";
		compiler->compile_safe(tagobj5, tag5);
		tag6 = "%length_seconds%";
		compiler->compile_safe(tagobj6, tag6);
		tag7 = "%samplerate%";
		compiler->compile_safe(tagobj7, tag7);
		tag8 = "%__bitspersample%";
		compiler->compile_safe(tagobj8, tag8);
		tag9 = "%__channels%";
		compiler->compile_safe(tagobj9, tag9);
		tag10 = "$info(encoding)";
		compiler->compile_safe(tagobj10, tag10);
		tag11 = "$info(codec)";
		compiler->compile_safe(tagobj11, tag11);

		p_track->format_title(NULL, a_rating, tagobj1, NULL);
		p_track->format_title(NULL, a_playcount, tagobj2, NULL);
		p_track->format_title(NULL, a_date, tagobj3, NULL);
		p_track->format_title(NULL, a_bitrate, tagobj4, NULL);
		p_track->format_title(NULL, a_filesize, tagobj5, NULL);
		p_track->format_title(NULL, a_tracklength, tagobj6, NULL);
		p_track->format_title(NULL, a_samplerate, tagobj7, NULL);
		p_track->format_title(NULL, a_bitspersample, tagobj8, NULL);
		p_track->format_title(NULL, a_channels, tagobj9, NULL);
		p_track->format_title(NULL, a_encoding, tagobj10, NULL);
		p_track->format_title(NULL, a_codec, tagobj11, NULL);

		p_track->metadb_unlock();

		tagobj1.release();
		tagobj2.release();
		tagobj3.release();
		tagobj4.release();
		tagobj5.release();
		tagobj6.release();
		tagobj7.release();
		tagobj8.release();
		tagobj9.release();
		tagobj10.release();
		tagobj11.release();

		pfc::string8 a_codeccdda = "CDDA";
		pfc::string8 a_codecshorten = "Shorten";
		pfc::string8 a_codecflac = "FLAC";
		pfc::string8 a_codecmp3 = "MP3";
		pfc::string8 a_codecmp2 = "MP2";
		pfc::string8 a_codecpcm = "PCM";
		pfc::string8 a_codecmonkeys = "Monkey's Audio";
		pfc::string8 a_codectak = "TAK";
		pfc::string8 a_codecalac = "ALAC";
		pfc::string8 a_codecmusepack = "Musepack";
		pfc::string8 a_codecoptimfrog = "OptimFROG";
		pfc::string8 a_codecdualstream = "DualStream";
		pfc::string8 a_codecvorbis = "Vorbis";
		pfc::string8 a_codecspeex = "Speex";
		pfc::string8 a_codectrueaudio = "True Audio";
		pfc::string8 a_codecwavpack = "WavPack";
		pfc::string8 a_codecwma = "WMA";
		pfc::string8 a_codecaac = "AAC";
		if (a_codec == a_codeccdda)
		{
			cfg_cdda = cfg_cdda + 1;
			cdda = cdda + 1;
		}
		else if (a_codec == a_codecshorten)
		{
			cfg_shorten = cfg_shorten + 1;
			shorten = shorten + 1;
		}
		else if (a_codec == a_codecflac)
		{
			cfg_flac = cfg_flac + 1;
			flac = flac + 1;
		}
		else if (a_codec == a_codecmp3)
		{
			cfg_mp3 = cfg_mp3 + 1;
			mp3 = mp3 + 1;
		}
		else if (a_codec == a_codecmp2)
		{
			cfg_mp2 = cfg_mp2 + 1;
			mp2 = mp2 + 1;
		}
		else if (a_codec == a_codecpcm)
		{
			cfg_pcm = cfg_pcm + 1;
			pcm = pcm + 1;
		}
		else if (a_codec == a_codecmonkeys)
		{
			cfg_monkeys = cfg_monkeys + 1;
			monkeys = monkeys + 1;
		}
		else if (a_codec == a_codectak)
		{
			cfg_tak = cfg_tak + 1;
			tak = tak + 1;
		}
		else if (a_codec == a_codecalac)
		{
			cfg_alac = cfg_alac + 1;
			alac = alac + 1;
		}
		else if (a_codec == a_codecmusepack)
		{
			cfg_musepack = cfg_musepack + 1;
			musepack = musepack + 1;
		}
		else if (a_codec == a_codecoptimfrog)
		{
			cfg_optimfrog = cfg_optimfrog + 1;
			optimfrog = optimfrog + 1;
		}
		else if (a_codec == a_codecdualstream)
		{
			cfg_dualstream = cfg_dualstream + 1;
			dualstream = dualstream + 1;
		}
		else if (a_codec == a_codecvorbis)
		{
			cfg_vorbis = cfg_vorbis + 1;
			vorbis = vorbis + 1;
		}
		else if (a_codec == a_codecspeex)
		{
			cfg_speex = cfg_speex + 1;
			speex = speex + 1;
		}
		else if (a_codec == a_codectrueaudio)
		{
			cfg_trueaudio = cfg_trueaudio + 1;
			trueaudio = trueaudio + 1;
		}
		else if (a_codec == a_codecwavpack)
		{
			cfg_wavpack = cfg_wavpack + 1;
			wavpack = wavpack + 1;
		}
		else if (a_codec == a_codecaac)
		{
			cfg_aac = cfg_aac + 1;
			aac = aac + 1;
		}
		else if (a_codec == a_codecwma)
		{
			cfg_wma = cfg_wma + 1;
			wma = wma + 1;
		}
		else
		{
			cfg_othercodec = cfg_othercodec + 1;
			othercodec = othercodec + 1;
		}
		pfc::string8 a_encoding2 = "lossless";
		pfc::string8 a_encoding3 = "lossy";
		if (a_encoding == a_encoding2)
		{
			cfg_lossless = cfg_lossless + 1;
			lossless = lossless + 1;
		}
		if (a_encoding == a_encoding3)
		{
			cfg_lossy = cfg_lossy + 1;
			lossy = lossy + 1;
		}
		channels = atoi(a_channels);
		sum_rating += atoi(a_rating);
		cfg_sum_rating = cfg_sum_rating + atoi(a_rating);
		sum_playcount += atoi(a_playcount);
		cfg_sum_playcount = cfg_sum_playcount + atoi(a_playcount);
		bitrate = atoi(a_bitrate);
		sum_bitrate += atoi(a_bitrate);
		cfg_sum_bitrate = cfg_sum_bitrate + atoi(a_bitrate);
		sum_filesize += atoi(a_filesize) / 1024 / 1024;
		cfg_sum_filesize = cfg_sum_filesize + atoi(a_filesize) / 1024 / 1024;
		sum_tracklength += atoi(a_tracklength);
		cfg_sum_tracklength = cfg_sum_tracklength + atoi(a_tracklength);
		date = atoi(a_date);
		if (date < 1900 || date > 2100)
		{
			if (average_date < 1900 || average_date > 2100)
			{
				average_date = 2000;
			}
			if (total_average_date < 1900 || total_average_date > 2100)
			{
				total_average_date = 2000;
			}
			date = average_date;
		}
		sum_date += date;
		cfg_sum_date = cfg_sum_date + t_uint32(date);
		samplerate = atoi(a_samplerate);
		if (samplerate == 11025)
		{
			sample11025 = sample11025 + 1;
			cfg_sample11025 = cfg_sample11025 + 1;
		}
		else if (samplerate == 22050)
		{
			sample22050 = sample22050 + 1;
			cfg_sample22050 = cfg_sample22050 + 1;
		}
		else if (samplerate == 44100)
		{
			sample44100 = sample44100 + 1;
			cfg_sample44100 = cfg_sample44100 + 1;
		}
		else if (samplerate == 48000)
		{
			sample48000 = sample48000 + 1;
			cfg_sample48000 = cfg_sample48000 + 1;
		}
		else if (samplerate == 88200)
		{
			sample88200 = sample88200 + 1;
			cfg_sample88200 = cfg_sample88200 + 1;
		}
		else if (samplerate == 96000)
		{
			sample96000 = sample96000 + 1;
			cfg_sample96000 = cfg_sample96000 + 1;
		}
		else if (samplerate == 192000)
		{
			sample192000 = sample192000 + 1;
			cfg_sample192000 = cfg_sample192000 + 1;
		}
		else
		{
			sampleother = sampleother + 1;
			cfg_sampleother = cfg_sampleother + 1;
		}
		bitspersample = atoi(a_bitspersample);
		if (a_encoding == a_encoding2)
		{
			if (bitspersample == 8)
			{
				bits8 = bits8 + 1;
				cfg_bits8 = cfg_bits8 + 1;
			}
			else if (bitspersample == 12)
			{
				bits12 = bits12 + 1;
				cfg_bits12 = cfg_bits12 + 1;
			}
			else if (bitspersample == 16)
			{
				bits16 = bits16 + 1;
				cfg_bits16 = cfg_bits16 + 1;
			}
			else if (bitspersample == 24)
			{
				bits24 = bits24 + 1;
				cfg_bits24 = cfg_bits24 + 1;
			}
			else if (bitspersample == 32)
			{
				bits32 = bits32 + 1;
				cfg_bits32 = cfg_bits32 + 1;
			}
			else
			{
				bitsother = bitsother + 1;
				cfg_bitsother = cfg_bitsother + 1;
			}
		}
		channels = atoi(a_channels);
		if (!(samplerate > 0))
		{
			samplerate = 44100;
		}
		if (!(bitspersample > 0))
		{
			bitspersample = 16;
		}
		if (!(channels > 0))
		{
			channels = 2;
		}
		if (channels == 1)
		{
			cfg_mono = cfg_mono + 1;
			mono = mono + 1;
		}
		else if (channels == 2)
		{
			cfg_stereo = cfg_stereo + 1;
			stereo = stereo + 1;
		}
		else
		{
			cfg_other = cfg_other + 1;
			other = other + 1;
		}
		average_trackplaybacktime = total_playback_time / playback_new_track;
		average_rating = double(sum_rating) / double(playback_new_track);
		average_playcount = double(sum_playcount) / double(playback_new_track);
		average_bitrate = double(sum_bitrate) / double(playback_new_track);
		average_filesize = sum_filesize / playback_new_track;
		average_tracklength = double(sum_tracklength) / double(playback_new_track);
		average_date = sum_date / playback_new_track;
		compression = bitrate * 100000 / samplerate * channels * bitspersample;
		compression = compression / 1000;
		sum_compression += compression;
		average_compression = sum_compression / playback_new_track;
		playbacktime_percent = average_trackplaybacktime * 100 / average_tracklength;
		cfg_sum_compression = cfg_sum_compression + compression;
		if (!cfg_playback_new_track_average == 0)
		{
			total_average_trackplaybacktime = double(cfg_total_playback_time_average) / double(cfg_playback_new_track_average);
			total_average_rating = double(cfg_sum_rating) / double(cfg_playback_new_track_average);
			total_average_playcount = double(cfg_sum_playcount) / double(cfg_playback_new_track_average);
			total_average_bitrate = double(cfg_sum_bitrate) / double(cfg_playback_new_track_average);
			total_average_filesize = cfg_sum_filesize / cfg_playback_new_track_average;
			total_average_tracklength = double(cfg_sum_tracklength) / double(cfg_playback_new_track_average);
			total_average_date = double(cfg_sum_date) / double(cfg_playback_new_track_average);
			total_average_compression = cfg_sum_compression / cfg_playback_new_track_average;
			total_playbacktime_percent = double(total_average_trackplaybacktime) * 100 / double(total_average_tracklength);
		}
	}
	virtual void on_playback_stop(play_control::t_stop_reason p_reason)
	{
		playback_stop++;
		cfg_playback_stop = cfg_playback_stop + 1;
		stop_reason = p_reason;
		switch (p_reason)
		{
		case 0:
			p_reason0++;
			cfg_p_reason0 = cfg_p_reason0 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_stop (user)");
			}
			break;
		case 1:
			p_reason1++;
			cfg_p_reason1 = cfg_p_reason1 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_stop (end of file)");
			}
			break;
		case 2:
			p_reason2++;
			cfg_p_reason2 = cfg_p_reason2 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_stop (starting another)");
			}
			break;
		case 3:
			p_reason3++;
			cfg_p_reason3 = cfg_p_reason3 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_stop (shuting down)");
			}
			break;

		default:
			console::info("error");
		}
	}
	virtual void on_playback_seek(double p_time)
	{
		playback_seek++;
		cfg_playback_seek = cfg_playback_seek + 1;
		seek_time = p_time;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_playback_seek");
		}
	}
	virtual void on_playback_pause(bool p_state)
	{
		playback_pause++;
		cfg_playback_pause = cfg_playback_pause + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_playback_pause");
		}
	}
	virtual void on_playback_starting(play_control::t_track_command p_command, bool p_paused)
	{
		playback_starting++;
		cfg_playback_starting = cfg_playback_starting + 1;
		playback_command = p_command;
		switch (p_command)
		{
		case 0:
			playback_command0++;
			cfg_playback_command0 = cfg_playback_command0 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (default)");
			}
			break;
		case 1:
			playback_command1++;
			cfg_playback_command1 = cfg_playback_command1 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (play)");
			}
			break;
		case 2:
			playback_command2++;
			cfg_playback_command2 = cfg_playback_command2 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (next)");
			}
			break;
		case 3:
			playback_command3++;
			cfg_playback_command3 = cfg_playback_command3 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (previous)");
			}
			break;
		case 4:
			playback_command4++;
			cfg_playback_command4 = cfg_playback_command4 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (settrack)");
			}
			break;
		case 5:
			playback_command5++;
			cfg_playback_command5 = cfg_playback_command5 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (random)");
			}
			break;
		case 6:
			playback_command6++;
			cfg_playback_command6 = cfg_playback_command6 + 1;
			if (cfg_main_monitor_events_enabled)
			{
				console::info("playback: on_playback_starting (resume)");
			}
			break;

		default:
			console::info("error");
		}
	}
	virtual void on_playback_edited(metadb_handle_ptr p_track)
	{
		playback_edited++;
		cfg_playback_edited = cfg_playback_edited + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_playback_edited");
		}
	}
	virtual void on_playback_dynamic_info(const file_info & info)
	{
		playback_dynamic_info++;
		cfg_playback_dynamic_info = cfg_playback_dynamic_info + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_playback_dynamic_info");
		}
	}
	virtual void on_playback_dynamic_info_track(const file_info & info)
	{
		playback_dynamic_info_track++;
		cfg_playback_dynamic_info_track = cfg_playback_dynamic_info_track + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_playback_dynamic_info_track");
		}
	}
	virtual void on_playback_time(double p_time)
	{
		total_playback_time++;
		cfg_total_playback_time = cfg_total_playback_time + 1;
		cfg_total_playback_time_average = cfg_total_playback_time_average + 1;
		playback_time = p_time;
	}
	virtual void on_volume_change(float p_new_val)
	{
		volume_new_value = p_new_val;
		volume_change++;
		cfg_volume_change = cfg_volume_change + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playback: on_volume_change");
		}
	}
};

static play_callback_static_factory_t<play_callback_statistics> g_play_callback_statistics;


class playlist_callback_statistics : public playlist_callback_static
{

public:

	virtual unsigned get_flags(void)
	{
		return (flag_on_items_selection_change | flag_on_item_focus_change | flag_on_playlist_activate);
	}
	virtual void on_items_added(t_size p_playlist, t_size p_start, const pfc::list_base_const_t<metadb_handle_ptr> & p_data, const bit_array & p_selection) {}
	virtual void on_items_reordered(t_size p_playlist, const t_size * p_order, t_size p_count) {}
	virtual void on_items_removing(t_size p_playlist, const bit_array & p_mask, t_size p_old_count, t_size p_new_count) {}
	virtual void on_items_removed(t_size p_playlist, const bit_array & p_mask, t_size p_old_count, t_size p_new_count) {}
	virtual void on_items_selection_change(t_size p_playlist, const bit_array & p_affected, const bit_array & p_state)
	{
		items_selection_change++;
		cfg_items_selection_change = cfg_items_selection_change + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_items_selection_change");
		}
	}
	virtual void on_item_focus_change(t_size p_playlist, t_size p_from, t_size p_to) {}
	virtual void on_items_modified(t_size p_playlist, const bit_array & p_mask) {}
	virtual void on_items_modified_fromplayback(t_size p_playlist, const bit_array & p_mask, play_control::t_display_level p_level) {};
	virtual void on_items_replaced(t_size p_playlist, const bit_array & p_mask, const pfc::list_base_const_t<t_on_items_replaced_entry> & p_data) {}
	virtual void on_item_ensure_visible(t_size p_playlist, t_size p_idx) {}
	virtual void on_playlist_activate(t_size p_old, t_size p_new)
	{
		playlist_activate++;
		cfg_playlist_activate = cfg_playlist_activate + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_playlist_activate");
		}
	}
	virtual void on_playlist_created(t_size p_index, const char * p_name, t_size p_name_len)
	{
		playlist_created++;
		cfg_playlist_created = cfg_playlist_created + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_playlist_created");
		}
	}
	virtual void on_playlists_reorder(const t_size * p_order, t_size p_count)
	{
		playlists_reorder++;
		cfg_playlists_reorder = cfg_playlists_reorder + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_playlists_reorder");
		}
	}
	virtual void on_playlists_removing(const bit_array & p_mask, t_size p_old_count, t_size p_new_count) {}
	virtual void on_playlists_removed(const bit_array & p_mask, t_size p_old_count, t_size p_new_count)
	{
		playlists_removed++;
		cfg_playlists_removed = cfg_playlists_removed + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_playlists_removed");
		}
	}
	virtual void on_playlist_renamed(t_size p_index, const char * p_new_name, t_size p_new_name_len)
	{
		playlist_renamed++;
		cfg_playlist_renamed = cfg_playlist_renamed + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_playlist_renamed");
		}
	}
	virtual void on_default_format_changed() {}
	virtual void on_playback_order_changed(t_size p_new_index)
	{
		playback_order_changed++;
		cfg_playback_order_changed = playback_order_changed + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("playlist: on_playback_order_changed");
		}
	}
	virtual void on_playlist_locked(t_size p_playlist, bool p_locked) {}

};

static service_factory_single_t<playlist_callback_statistics> g_playlist_callback_statistics;


class playback_statistics_collector_statistics : public playback_statistics_collector
{

public:

	void on_item_played(metadb_handle_ptr p_item)
	{
		item_played++;
		cfg_item_played = cfg_item_played + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("other: on_item_played");
		}
	}
};

static playback_statistics_collector_factory_t<playback_statistics_collector_statistics> g_playback_statistics_collector_statistics;


class library_callback_statistics : public library_callback
{
	virtual void on_items_added(const pfc::list_base_const_t<metadb_handle_ptr> & p_data)
	{
		library_items_added_count = library_items_added_count + p_data.get_count();
		library_items_added = library_items_added + 1;
		cfg_library_items_added_count = cfg_library_items_added_count + p_data.get_count();
		cfg_library_items_added = cfg_library_items_added + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("library: on_items_added");
		}
	}
	virtual void on_items_removed(const pfc::list_base_const_t<metadb_handle_ptr> & p_data)
	{
		library_items_removed_count = library_items_removed_count + p_data.get_count();
		library_items_removed = library_items_removed + 1;
		cfg_library_items_removed_count = cfg_library_items_removed_count + p_data.get_count();
		cfg_library_items_removed = cfg_library_items_removed + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("library: on_items_removed");
		}
	}
	virtual void on_items_modified(const pfc::list_base_const_t<metadb_handle_ptr> & p_data)
	{
		library_items_modified_count = library_items_modified_count + p_data.get_count();
		library_items_modified = library_items_modified + 1;
		cfg_library_items_modified_count = cfg_library_items_modified_count + p_data.get_count();
		cfg_library_items_modified = cfg_library_items_modified + 1;
		if (cfg_main_monitor_events_enabled)
		{
			console::info("library: on_items_modified");
		}
	}
};

static library_callback_factory_t<library_callback_statistics> library_statistics;

//EOF