#include "stdafx.h"
#include "config.h"

/**************************
Storing settings.

Here settings refer to any information that needs to be
remembered across sessions, like window positions and such.
foobar2000 provides configuration variables to do this,
which come in two different flavors: private and public.
Private configuration variables are derived from cfg_var in
the pfc library; they can only be accessed in the component
that declares them. Public configuration variables are
dervided from config_object; they can be accessed
from any component. Public configuration variables can be
used from any thread, since they have builtin synchronization,
whereas access to private configuration variables has to be
synchronized by the component where necessary.

We won't use threads in this component, and we don't want
our settings to be publicly available, so we will use the
cfg_var subclasses from the SDK.

Note: Variables are internally identified by a GUID you
pass as the first parameter to the constructor. The second
parameter of the contructor is the default value. Some types
of configuration variables have an implicit default value,
so their constructor takes only one parameter.
**************************/

// boolean variable
// Stores whether playback menu command are enabled.

// {DD8A6BF4-4A7E-4936-A159-E14C0416D295}
static const GUID guid_cfg_menu_stopalbum_enabled = { 0xdd8a6bf4, 0x4a7e, 0x4936, { 0xa1, 0x59, 0xe1, 0x4c, 0x4, 0x16, 0xd2, 0x95 } };
cfg_bool cfg_menu_stopalbum_enabled(guid_cfg_menu_stopalbum_enabled, false);

// {F96895D5-0F51-471E-80AD-6C7AAF60D524}
static const GUID guid_cfg_menu_stoplasttrack_enabled = { 0xf96895d5, 0xf51, 0x471e, { 0x80, 0xad, 0x6c, 0x7a, 0xaf, 0x60, 0xd5, 0x24 } };
cfg_bool cfg_menu_stoplasttrack_enabled(guid_cfg_menu_stoplasttrack_enabled, false);

// {47FD64D0-9BEC-43D1-A9EE-0E7116CCCD1A}
static const GUID guid_cfg_menu_stopalbumlasttrack_enabled = { 0x47fd64d0, 0x9bec, 0x43d1, { 0xa9, 0xee, 0xe, 0x71, 0x16, 0xcc, 0xcd, 0x1a } };
cfg_bool cfg_menu_stopalbumlasttrack_enabled(guid_cfg_menu_stopalbumlasttrack_enabled, false);

// {88E835FF-7A05-4B44-84D6-E20E99096F35}
static const GUID guid_cfg_menu_repeatalbum_enabled = { 0x88e835ff, 0x7a05, 0x4b44, { 0x84, 0xd6, 0xe2, 0xe, 0x99, 0x9, 0x6f, 0x35 } };
cfg_bool cfg_menu_repeatalbum_enabled(guid_cfg_menu_repeatalbum_enabled, false);

// {0A2D700F-D36C-445E-98C3-783FF9B19E9E}
static const GUID guid_cfg_menu_skipalbum_enabled = { 0xa2d700f, 0xd36c, 0x445e, { 0x98, 0xc3, 0x78, 0x3f, 0xf9, 0xb1, 0x9e, 0x9e } };
cfg_bool cfg_menu_skipalbum_enabled(guid_cfg_menu_skipalbum_enabled, false);

// {09F256DD-2B5A-41CD-B484-FDA870102C71}
static const GUID guid_cfg_menu_repeattrack_enabled = { 0x9f256dd, 0x2b5a, 0x41cd, { 0xb4, 0x84, 0xfd, 0xa8, 0x70, 0x10, 0x2c, 0x71 } };
cfg_bool cfg_menu_repeattrack_enabled(guid_cfg_menu_repeattrack_enabled, false);

// {09901CF0-0E83-46C4-BD95-B55829591855}
static const GUID guid_cfg_menu_skiptrack_enabled = { 0x9901cf0, 0xe83, 0x46c4, { 0xbd, 0x95, 0xb5, 0x58, 0x29, 0x59, 0x18, 0x55 } };
cfg_bool cfg_menu_skiptrack_enabled(guid_cfg_menu_skiptrack_enabled, false);

// {11A871B8-9699-465B-8DAB-E03F93EFD8C4}
static const GUID guid_cfg_menu_randomalbum_enabled = { 0x11a871b8, 0x9699, 0x465b, { 0x8d, 0xab, 0xe0, 0x3f, 0x93, 0xef, 0xd8, 0xc4 } };
cfg_bool cfg_menu_randomalbum_enabled(guid_cfg_menu_randomalbum_enabled, false);

// {F4BA29CD-29C3-4AE6-9EA9-29DBB8C3DB5D}
static const GUID guid_cfg_menu_previousplaylistfirst_enabled = { 0xf4ba29cd, 0x29c3, 0x4ae6, { 0x9e, 0xa9, 0x29, 0xdb, 0xb8, 0xc3, 0xdb, 0x5d } };
cfg_bool cfg_menu_previousplaylistfirst_enabled(guid_cfg_menu_previousplaylistfirst_enabled, false);

// {E50D19EB-DCEB-4C6C-ADA2-596E9C333F72}
static const GUID guid_cfg_menu_repeatplaylist_enabled = { 0xe50d19eb, 0xdceb, 0x4c6c, { 0xad, 0xa2, 0x59, 0x6e, 0x9c, 0x33, 0x3f, 0x72 } };
cfg_bool cfg_menu_repeatplaylist_enabled(guid_cfg_menu_repeatplaylist_enabled, false);

// {D68553AE-69DB-4bb5-9C0C-2A754ED66FD7}
static const GUID guid_cfg_menu_postgap_enabled = { 0xd68553ae, 0x69db, 0x4bb5, { 0x9c, 0xc, 0x2a, 0x75, 0x4e, 0xd6, 0x6f, 0xd7 } };
cfg_bool cfg_menu_postgap_enabled(guid_cfg_menu_postgap_enabled, false);

// {FC09C961-07B5-4EE2-B068-9F914FBBF10F}
static const GUID guid_cfg_menu_nextplaylistfirst_enabled = { 0xfc09c961, 0x7b5, 0x4ee2, { 0xb0, 0x68, 0x9f, 0x91, 0x4f, 0xbb, 0xf1, 0xf } };
cfg_bool cfg_menu_nextplaylistfirst_enabled(guid_cfg_menu_nextplaylistfirst_enabled, false);

// {FF256F9B-251B-4C31-8381-718429A4C7E4}
static const GUID guid_cfg_menu_timebomb1_enabled = { 0xff256f9b, 0x251b, 0x4c31, { 0x83, 0x81, 0x71, 0x84, 0x29, 0xa4, 0xc7, 0xe4 } };
cfg_bool cfg_menu_timebomb1_enabled(guid_cfg_menu_timebomb1_enabled, false);

// {C042AA8F-AF76-4FA8-B616-849A0789DC78}
static const GUID guid_cfg_menu_timebomb2_enabled = { 0xc042aa8f, 0xaf76, 0x4fa8, { 0xb6, 0x16, 0x84, 0x9a, 0x7, 0x89, 0xdc, 0x78 } };
cfg_bool cfg_menu_timebomb2_enabled(guid_cfg_menu_timebomb2_enabled, false);

// {A6EB1B11-2886-4AF6-A86A-996D2F3A11A3}
static const GUID guid_cfg_menu_timebomb3_enabled = { 0xa6eb1b11, 0x2886, 0x4af6, { 0xa8, 0x6a, 0x99, 0x6d, 0x2f, 0x3a, 0x11, 0xa3 } };
cfg_bool cfg_menu_timebomb3_enabled(guid_cfg_menu_timebomb3_enabled, false);

// {FCEE1186-506C-4504-9F8E-7EEA12E236D1}
static const GUID guid_cfg_menu_timebomb4_enabled = { 0xfcee1186, 0x506c, 0x4504, { 0x9f, 0x8e, 0x7e, 0xea, 0x12, 0xe2, 0x36, 0xd1 } };
cfg_bool cfg_menu_timebomb4_enabled(guid_cfg_menu_timebomb4_enabled, false);

// {F78A71F5-BB74-44B4-A865-832218EACE61}
static const GUID guid_cfg_menu_timebomb5_enabled = { 0xf78a71f5, 0xbb74, 0x44b4, { 0xa8, 0x65, 0x83, 0x22, 0x18, 0xea, 0xce, 0x61 } };
cfg_bool cfg_menu_timebomb5_enabled(guid_cfg_menu_timebomb5_enabled, false);

// {9FB65CEB-6AA6-4937-A46B-66C2A3A00676}
static const GUID guid_cfg_menu_timebomb6_enabled = { 0x9fb65ceb, 0x6aa6, 0x4937, { 0xa4, 0x6b, 0x66, 0xc2, 0xa3, 0xa0, 0x6, 0x76 } };
cfg_bool cfg_menu_timebomb6_enabled(guid_cfg_menu_timebomb6_enabled, false);

// {7920076F-4601-4AC8-943E-75508CA41D44}
static const GUID guid_cfg_menu_timebomb7_enabled = { 0x7920076f, 0x4601, 0x4ac8, { 0x94, 0x3e, 0x75, 0x50, 0x8c, 0xa4, 0x1d, 0x44 } };
cfg_bool cfg_menu_timebomb7_enabled(guid_cfg_menu_timebomb7_enabled, false);

// {A5CAB296-D158-4020-AD8E-A921FA993B52}
static const GUID guid_cfg_menu_timebomb8_enabled = { 0xa5cab296, 0xd158, 0x4020, { 0xad, 0x8e, 0xa9, 0x21, 0xfa, 0x99, 0x3b, 0x52 } };
cfg_bool cfg_menu_timebomb8_enabled(guid_cfg_menu_timebomb8_enabled, false);

// {AD8897A7-6C89-4E28-946C-F1D76F6B858F}
static const GUID guid_cfg_menu_timebomb9_enabled = { 0xad8897a7, 0x6c89, 0x4e28, { 0x94, 0x6c, 0xf1, 0xd7, 0x6f, 0x6b, 0x85, 0x8f } };
cfg_bool cfg_menu_timebomb9_enabled(guid_cfg_menu_timebomb9_enabled, false);

// {B97B45A1-CA22-4F2F-8A32-0A6643E688F7}
static const GUID guid_cfg_menu_timebomb10_enabled = { 0xb97b45a1, 0xca22, 0x4f2f, { 0x8a, 0x32, 0xa, 0x66, 0x43, 0xe6, 0x88, 0xf7 } };
cfg_bool cfg_menu_timebomb10_enabled(guid_cfg_menu_timebomb10_enabled, false);

// {E3666D68-F375-4669-A0F7-447A632A31DE}
static const GUID guid_cfg_menu_timebomb11_enabled = { 0xe3666d68, 0xf375, 0x4669, { 0xa0, 0xf7, 0x44, 0x7a, 0x63, 0x2a, 0x31, 0xde } };
cfg_bool cfg_menu_timebomb11_enabled(guid_cfg_menu_timebomb11_enabled, false);

// {1094D78B-67D9-4D99-BE29-493F7CDA04B8}
static const GUID guid_cfg_menu_timebombabort_enabled = { 0x1094d78b, 0x67d9, 0x4d99, { 0xbe, 0x29, 0x49, 0x3f, 0x7c, 0xda, 0x4, 0xb8 } };
cfg_bool cfg_menu_timebombabort_enabled(guid_cfg_menu_timebombabort_enabled, false);

// {06836DC8-B06B-4306-B8A0-92887652F237}
static const GUID guid_cfg_menu_stopaftertracks1_enabled = { 0x6836dc8, 0xb06b, 0x4306, { 0xb8, 0xa0, 0x92, 0x88, 0x76, 0x52, 0xf2, 0x37 } };
cfg_bool cfg_menu_stopaftertracks1_enabled(guid_cfg_menu_stopaftertracks1_enabled, false);

// {0379B93A-E340-4F9B-8673-32EC5C3DAEC3}
static const GUID guid_cfg_menu_stopaftertracks2_enabled = { 0x379b93a, 0xe340, 0x4f9b, { 0x86, 0x73, 0x32, 0xec, 0x5c, 0x3d, 0xae, 0xc3 } };
cfg_bool cfg_menu_stopaftertracks2_enabled(guid_cfg_menu_stopaftertracks2_enabled, false);

// {36C09D94-F736-4673-9445-053402FDC751}
static const GUID guid_cfg_menu_stopaftertracks3_enabled = { 0x36c09d94, 0xf736, 0x4673, { 0x94, 0x45, 0x5, 0x34, 0x2, 0xfd, 0xc7, 0x51 } };
cfg_bool cfg_menu_stopaftertracks3_enabled(guid_cfg_menu_stopaftertracks3_enabled, false);

// {1C99B14B-89A2-4DFE-8C78-74D07BF32C5A}
static const GUID guid_cfg_menu_stopaftertracks4_enabled = { 0x1c99b14b, 0x89a2, 0x4dfe, { 0x8c, 0x78, 0x74, 0xd0, 0x7b, 0xf3, 0x2c, 0x5a } };
cfg_bool cfg_menu_stopaftertracks4_enabled(guid_cfg_menu_stopaftertracks4_enabled, false);

// {6994FDFD-FC07-4EAB-926B-A214E7760712}
static const GUID guid_cfg_menu_stopaftertracks5_enabled = { 0x6994fdfd, 0xfc07, 0x4eab, { 0x92, 0x6b, 0xa2, 0x14, 0xe7, 0x76, 0x7, 0x12 } };
cfg_bool cfg_menu_stopaftertracks5_enabled(guid_cfg_menu_stopaftertracks5_enabled, false);

// {DB57C4A9-DF18-47DD-80BA-9B1EA36A9DE8}
static const GUID guid_cfg_menu_stopaftertracks6_enabled = { 0xdb57c4a9, 0xdf18, 0x47dd, { 0x80, 0xba, 0x9b, 0x1e, 0xa3, 0x6a, 0x9d, 0xe8 } };
cfg_bool cfg_menu_stopaftertracks6_enabled(guid_cfg_menu_stopaftertracks6_enabled, false);

// {D8F50B40-D0C2-42AD-BB80-4AD3DC01D2AA}
static const GUID guid_cfg_menu_stopaftertracks7_enabled = { 0xd8f50b40, 0xd0c2, 0x42ad, { 0xbb, 0x80, 0x4a, 0xd3, 0xdc, 0x1, 0xd2, 0xaa } };
cfg_bool cfg_menu_stopaftertracks7_enabled(guid_cfg_menu_stopaftertracks7_enabled, false);

// {FC7A1E03-C656-4A1A-B822-506D2244D706}
static const GUID guid_cfg_menu_stopaftertracks8_enabled = { 0xfc7a1e03, 0xc656, 0x4a1a, { 0xb8, 0x22, 0x50, 0x6d, 0x22, 0x44, 0xd7, 0x6 } };
cfg_bool cfg_menu_stopaftertracks8_enabled(guid_cfg_menu_stopaftertracks8_enabled, false);

// {57545A69-2B11-4EE8-951A-61910CB7B521}
static const GUID guid_cfg_menu_stopaftertracks9_enabled = { 0x57545a69, 0x2b11, 0x4ee8, { 0x95, 0x1a, 0x61, 0x91, 0xc, 0xb7, 0xb5, 0x21 } };
cfg_bool cfg_menu_stopaftertracks9_enabled(guid_cfg_menu_stopaftertracks9_enabled, false);

// {FED9CEB7-C357-41B1-86EE-0905B6168C4A}
static const GUID guid_cfg_menu_stopaftertracks10_enabled = { 0xfed9ceb7, 0xc357, 0x41b1, { 0x86, 0xee, 0x9, 0x5, 0xb6, 0x16, 0x8c, 0x4a } };
cfg_bool cfg_menu_stopaftertracks10_enabled(guid_cfg_menu_stopaftertracks10_enabled, false);

// {2F1AAF06-F703-4C8D-8F9E-D188638FB091}
static const GUID guid_cfg_menu_stopaftertracks11_enabled = { 0x2f1aaf06, 0xf703, 0x4c8d, { 0x8f, 0x9e, 0xd1, 0x88, 0x63, 0x8f, 0xb0, 0x91 } };
cfg_bool cfg_menu_stopaftertracks11_enabled(guid_cfg_menu_stopaftertracks11_enabled, false);

// {5679CCF3-539E-454F-952B-DD925B0F932D}
static const GUID guid_cfg_menu_stopaftertracks12_enabled = { 0x5679ccf3, 0x539e, 0x454f, { 0x95, 0x2b, 0xdd, 0x92, 0x5b, 0xf, 0x93, 0x2d } };
cfg_bool cfg_menu_stopaftertracks12_enabled(guid_cfg_menu_stopaftertracks12_enabled, false);

// {69729BF4-27A5-4DBB-B6E6-91D05EFFC7E5}
static const GUID guid_cfg_menu_stopaftertracks13_enabled = { 0x69729bf4, 0x27a5, 0x4dbb, { 0xb6, 0xe6, 0x91, 0xd0, 0x5e, 0xff, 0xc7, 0xe5 } };
cfg_bool cfg_menu_stopaftertracks13_enabled(guid_cfg_menu_stopaftertracks13_enabled, false);

// {062DA9E3-30ED-436A-935B-259292E53C58}
static const GUID guid_cfg_menu_stopaftertracks14_enabled = { 0x62da9e3, 0x30ed, 0x436a, { 0x93, 0x5b, 0x25, 0x92, 0x92, 0xe5, 0x3c, 0x58 } };
cfg_bool cfg_menu_stopaftertracks14_enabled(guid_cfg_menu_stopaftertracks14_enabled, false);

// {37977AE7-FBEE-43BB-AD5B-EDC4CD41E38F}
static const GUID guid_cfg_menu_stopaftertracks15_enabled = { 0x37977ae7, 0xfbee, 0x43bb, { 0xad, 0x5b, 0xed, 0xc4, 0xcd, 0x41, 0xe3, 0x8f } };
cfg_bool cfg_menu_stopaftertracks15_enabled(guid_cfg_menu_stopaftertracks15_enabled, false);

// {329D6100-2B56-424C-B581-512B3673B434}
static const GUID guid_cfg_menu_stopaftertracks16_enabled = { 0x329d6100, 0x2b56, 0x424c, { 0xb5, 0x81, 0x51, 0x2b, 0x36, 0x73, 0xb4, 0x34 } };
cfg_bool cfg_menu_stopaftertracks16_enabled(guid_cfg_menu_stopaftertracks16_enabled, false);

// {6E371CC6-CE53-4BB0-A0FE-3323F9026BD1}
static const GUID guid_cfg_menu_stopaftertracks17_enabled = { 0x6e371cc6, 0xce53, 0x4bb0, { 0xa0, 0xfe, 0x33, 0x23, 0xf9, 0x2, 0x6b, 0xd1 } };
cfg_bool cfg_menu_stopaftertracks17_enabled(guid_cfg_menu_stopaftertracks17_enabled, false);

// {64438670-F2EC-4773-ABE0-207AF749EC9C}
static const GUID guid_cfg_menu_stopaftertracks18_enabled = { 0x64438670, 0xf2ec, 0x4773, { 0xab, 0xe0, 0x20, 0x7a, 0xf7, 0x49, 0xec, 0x9c } };
cfg_bool cfg_menu_stopaftertracks18_enabled(guid_cfg_menu_stopaftertracks18_enabled, false);

// {A5D4DC52-DCB0-45DC-A6EA-563DC53E38C5}
static const GUID guid_cfg_menu_stopaftertracks19_enabled = { 0xa5d4dc52, 0xdcb0, 0x45dc, { 0xa6, 0xea, 0x56, 0x3d, 0xc5, 0x3e, 0x38, 0xc5 } };
cfg_bool cfg_menu_stopaftertracks19_enabled(guid_cfg_menu_stopaftertracks19_enabled, false);

// {50514F1D-8BBD-4B51-9A57-A553F7230499}
static const GUID guid_cfg_menu_stopaftertracks20_enabled = { 0x50514f1d, 0x8bbd, 0x4b51, { 0x9a, 0x57, 0xa5, 0x53, 0xf7, 0x23, 0x4, 0x99 } };
cfg_bool cfg_menu_stopaftertracks20_enabled(guid_cfg_menu_stopaftertracks20_enabled, false);


// {9A8DECF0-2B6C-453B-8E40-5BEC56AA8287}
static const GUID guid_cfg_menu_gaptracks1_enabled = { 0x9a8decf0, 0x2b6c, 0x453b, { 0x8e, 0x40, 0x5b, 0xec, 0x56, 0xaa, 0x82, 0x87 } };
cfg_bool cfg_menu_gaptracks1_enabled(guid_cfg_menu_gaptracks1_enabled, false);

// {EBDF096D-9E54-4C5C-8CD3-E062D7624030}
static const GUID guid_cfg_menu_gaptracks2_enabled = { 0xebdf096d, 0x9e54, 0x4c5c, { 0x8c, 0xd3, 0xe0, 0x62, 0xd7, 0x62, 0x40, 0x30 } };
cfg_bool cfg_menu_gaptracks2_enabled(guid_cfg_menu_gaptracks2_enabled, false);

// {8A57D267-BD60-4021-BDC9-DE42E7BD9C4F}
static const GUID guid_cfg_menu_gaptracks3_enabled = { 0x8a57d267, 0xbd60, 0x4021, { 0xbd, 0xc9, 0xde, 0x42, 0xe7, 0xbd, 0x9c, 0x4f } };
cfg_bool cfg_menu_gaptracks3_enabled(guid_cfg_menu_gaptracks3_enabled, false);

// {C45AF51B-4785-4B3B-922A-0AB24BFAA2A2}
static const GUID guid_cfg_menu_gaptracks4_enabled = { 0xc45af51b, 0x4785, 0x4b3b, { 0x92, 0x2a, 0xa, 0xb2, 0x4b, 0xfa, 0xa2, 0xa2 } };
cfg_bool cfg_menu_gaptracks4_enabled(guid_cfg_menu_gaptracks4_enabled, false);

// {03847C97-15A0-4188-BE43-BE40BF2F8196}
static const GUID guid_cfg_menu_gaptracks5_enabled = { 0x3847c97, 0x15a0, 0x4188, { 0xbe, 0x43, 0xbe, 0x40, 0xbf, 0x2f, 0x81, 0x96 } };
cfg_bool cfg_menu_gaptracks5_enabled(guid_cfg_menu_gaptracks5_enabled, false);

// {5AF6C6AD-079B-4AAF-A65C-953740726A33}
static const GUID guid_cfg_menu_gaptracks6_enabled = { 0x5af6c6ad, 0x79b, 0x4aaf, { 0xa6, 0x5c, 0x95, 0x37, 0x40, 0x72, 0x6a, 0x33 } };
cfg_bool cfg_menu_gaptracks6_enabled(guid_cfg_menu_gaptracks6_enabled, false);

// {DCB9467C-2BE3-4501-B995-373A4BE619CA}
static const GUID guid_cfg_menu_gaptracks7_enabled = { 0xdcb9467c, 0x2be3, 0x4501, { 0xb9, 0x95, 0x37, 0x3a, 0x4b, 0xe6, 0x19, 0xca } };
cfg_bool cfg_menu_gaptracks7_enabled(guid_cfg_menu_gaptracks7_enabled, false);

// {BEF97147-E44E-4AE9-9C57-B88D1A94F301}
static const GUID guid_cfg_menu_gaptracks8_enabled = { 0xbef97147, 0xe44e, 0x4ae9, { 0x9c, 0x57, 0xb8, 0x8d, 0x1a, 0x94, 0xf3, 0x1 } };
cfg_bool cfg_menu_gaptracks8_enabled(guid_cfg_menu_gaptracks8_enabled, false);

// {02178538-BB2A-4C00-B68E-99A216CABA71}
static const GUID guid_cfg_menu_gaptracks9_enabled = { 0x2178538, 0xbb2a, 0x4c00, { 0xb6, 0x8e, 0x99, 0xa2, 0x16, 0xca, 0xba, 0x71 } };
cfg_bool cfg_menu_gaptracks9_enabled(guid_cfg_menu_gaptracks9_enabled, false);

// {61800E7F-283F-4394-B3FD-2314649FD255}
static const GUID guid_cfg_menu_gaptracks10_enabled = { 0x61800e7f, 0x283f, 0x4394, { 0xb3, 0xfd, 0x23, 0x14, 0x64, 0x9f, 0xd2, 0x55 } };
cfg_bool cfg_menu_gaptracks10_enabled(guid_cfg_menu_gaptracks10_enabled, false);

// {1A0E422B-FE83-4F6F-A53C-36D3939B0F38}
static const GUID guid_cfg_menu_gaptracks11_enabled = { 0x1a0e422b, 0xfe83, 0x4f6f, { 0xa5, 0x3c, 0x36, 0xd3, 0x93, 0x9b, 0xf, 0x38 } };
cfg_bool cfg_menu_gaptracks11_enabled(guid_cfg_menu_gaptracks11_enabled, false);

// {61EEBB1B-ECAF-486F-A55A-EF67443BFDE3}
static const GUID guid_cfg_menu_gaptracks12_enabled = { 0x61eebb1b, 0xecaf, 0x486f, { 0xa5, 0x5a, 0xef, 0x67, 0x44, 0x3b, 0xfd, 0xe3 } };
cfg_bool cfg_menu_gaptracks12_enabled(guid_cfg_menu_gaptracks12_enabled, false);

// {CC3CAC5D-88EE-4170-B321-498DC1917E5F}
static const GUID guid_cfg_menu_gaptracks13_enabled = { 0xcc3cac5d, 0x88ee, 0x4170, { 0xb3, 0x21, 0x49, 0x8d, 0xc1, 0x91, 0x7e, 0x5f } };
cfg_bool cfg_menu_gaptracks13_enabled(guid_cfg_menu_gaptracks13_enabled, false);

// {0450FBF7-2CDA-4E4A-8222-D515FBF2E448}
static const GUID guid_cfg_menu_gaptracks14_enabled = { 0x450fbf7, 0x2cda, 0x4e4a, { 0x82, 0x22, 0xd5, 0x15, 0xfb, 0xf2, 0xe4, 0x48 } };
cfg_bool cfg_menu_gaptracks14_enabled(guid_cfg_menu_gaptracks14_enabled, false);

// {F530E533-4D7A-4233-ABB8-C373C0D0AAE6}
static const GUID guid_cfg_menu_gaptracks15_enabled = { 0xf530e533, 0x4d7a, 0x4233, { 0xab, 0xb8, 0xc3, 0x73, 0xc0, 0xd0, 0xaa, 0xe6 } };
cfg_bool cfg_menu_gaptracks15_enabled(guid_cfg_menu_gaptracks15_enabled, false);

// {14A7D844-2448-4646-ADFA-4EC8A6064D62}
static const GUID guid_cfg_menu_gaptracks16_enabled = { 0x14a7d844, 0x2448, 0x4646, { 0xad, 0xfa, 0x4e, 0xc8, 0xa6, 0x6, 0x4d, 0x62 } };
cfg_bool cfg_menu_gaptracks16_enabled(guid_cfg_menu_gaptracks16_enabled, false);

// {98E8FFD2-BB66-476F-A528-026AE3512940}
static const GUID guid_cfg_menu_gaptracks17_enabled = { 0x98e8ffd2, 0xbb66, 0x476f, { 0xa5, 0x28, 0x2, 0x6a, 0xe3, 0x51, 0x29, 0x40 } };
cfg_bool cfg_menu_gaptracks17_enabled(guid_cfg_menu_gaptracks17_enabled, false);

// {0BA9ECB6-8F9D-41F9-9CDE-C439B2F9A93A}
static const GUID guid_cfg_menu_gaptracks18_enabled = { 0xba9ecb6, 0x8f9d, 0x41f9, { 0x9c, 0xde, 0xc4, 0x39, 0xb2, 0xf9, 0xa9, 0x3a } };
cfg_bool cfg_menu_gaptracks18_enabled(guid_cfg_menu_gaptracks18_enabled, false);

// {3EAEECD0-7DB2-4783-AB94-7FBBE7A55714}
static const GUID guid_cfg_menu_gaptracks19_enabled = { 0x3eaeecd0, 0x7db2, 0x4783, { 0xab, 0x94, 0x7f, 0xbb, 0xe7, 0xa5, 0x57, 0x14 } };
cfg_bool cfg_menu_gaptracks19_enabled(guid_cfg_menu_gaptracks19_enabled, false);

// {92C423A2-036E-4183-80A8-03A382D4EF13}
static const GUID guid_cfg_menu_gaptracks20_enabled = { 0x92c423a2, 0x36e, 0x4183, { 0x80, 0xa8, 0x3, 0xa3, 0x82, 0xd4, 0xef, 0x13 } };
cfg_bool cfg_menu_gaptracks20_enabled(guid_cfg_menu_gaptracks20_enabled, false);


// {81FA42AF-B3DB-419C-9B1A-3B2530F1DD96}
static const GUID guid_cfg_menu_gapalbums1_enabled = { 0x81fa42af, 0xb3db, 0x419c, { 0x9b, 0x1a, 0x3b, 0x25, 0x30, 0xf1, 0xdd, 0x96 } };
cfg_bool cfg_menu_gapalbums1_enabled(guid_cfg_menu_gapalbums1_enabled, false);

// {37C074AF-0CE3-43BC-95A3-6F7CA4290E92}
static const GUID guid_cfg_menu_gapalbums2_enabled = { 0x37c074af, 0xce3, 0x43bc, { 0x95, 0xa3, 0x6f, 0x7c, 0xa4, 0x29, 0xe, 0x92 } };
cfg_bool cfg_menu_gapalbums2_enabled(guid_cfg_menu_gapalbums2_enabled, false);

// {2A095C92-B886-49D2-8E4E-BBEF1ADF67E3}
static const GUID guid_cfg_menu_gapalbums3_enabled = { 0x2a095c92, 0xb886, 0x49d2, { 0x8e, 0x4e, 0xbb, 0xef, 0x1a, 0xdf, 0x67, 0xe3 } };
cfg_bool cfg_menu_gapalbums3_enabled(guid_cfg_menu_gapalbums3_enabled, false);

// {5948FB6A-AAC1-45BC-A328-F65A24CAC4F5}
static const GUID guid_cfg_menu_gapalbums4_enabled = { 0x5948fb6a, 0xaac1, 0x45bc, { 0xa3, 0x28, 0xf6, 0x5a, 0x24, 0xca, 0xc4, 0xf5 } };
cfg_bool cfg_menu_gapalbums4_enabled(guid_cfg_menu_gapalbums4_enabled, false);

// {2B01B317-29F0-4BF4-B795-5B6AD5402518}
static const GUID guid_cfg_menu_gapalbums5_enabled = { 0x2b01b317, 0x29f0, 0x4bf4, { 0xb7, 0x95, 0x5b, 0x6a, 0xd5, 0x40, 0x25, 0x18 } };
cfg_bool cfg_menu_gapalbums5_enabled(guid_cfg_menu_gapalbums5_enabled, false);

// {20727EE8-F8EF-4785-B0DC-097257892650}
static const GUID guid_cfg_menu_gapalbums6_enabled = { 0x20727ee8, 0xf8ef, 0x4785, { 0xb0, 0xdc, 0x9, 0x72, 0x57, 0x89, 0x26, 0x50 } };
cfg_bool cfg_menu_gapalbums6_enabled(guid_cfg_menu_gapalbums6_enabled, false);

// {5DE4542A-18E6-4562-860A-E57DF0108F90}
static const GUID guid_cfg_menu_gapalbums7_enabled = { 0x5de4542a, 0x18e6, 0x4562, { 0x86, 0xa, 0xe5, 0x7d, 0xf0, 0x10, 0x8f, 0x90 } };
cfg_bool cfg_menu_gapalbums7_enabled(guid_cfg_menu_gapalbums7_enabled, false);

// {618B996C-5642-4125-8031-60B07426F6A1}
static const GUID guid_cfg_menu_gapalbums8_enabled = { 0x618b996c, 0x5642, 0x4125, { 0x80, 0x31, 0x60, 0xb0, 0x74, 0x26, 0xf6, 0xa1 } };
cfg_bool cfg_menu_gapalbums8_enabled(guid_cfg_menu_gapalbums8_enabled, false);

// {B3149148-F08E-46FD-BE15-FADA8F1AB189}
static const GUID guid_cfg_menu_gapalbums9_enabled = { 0xb3149148, 0xf08e, 0x46fd, { 0xbe, 0x15, 0xfa, 0xda, 0x8f, 0x1a, 0xb1, 0x89 } };
cfg_bool cfg_menu_gapalbums9_enabled(guid_cfg_menu_gapalbums9_enabled, false);

// {E5176C33-0C14-4948-A1C5-C5FB8FFC4E62}
static const GUID guid_cfg_menu_gapalbums10_enabled = { 0xe5176c33, 0xc14, 0x4948, { 0xa1, 0xc5, 0xc5, 0xfb, 0x8f, 0xfc, 0x4e, 0x62 } };
cfg_bool cfg_menu_gapalbums10_enabled(guid_cfg_menu_gapalbums10_enabled, false);

// {9A30F152-D042-49BB-B3C1-712EE68A02D2}
static const GUID guid_cfg_menu_gapalbums11_enabled = { 0x9a30f152, 0xd042, 0x49bb, { 0xb3, 0xc1, 0x71, 0x2e, 0xe6, 0x8a, 0x2, 0xd2 } };
cfg_bool cfg_menu_gapalbums11_enabled(guid_cfg_menu_gapalbums11_enabled, false);

// {4BF71AA7-E224-415A-AB2D-E3BF4E3440E0}
static const GUID guid_cfg_menu_gapalbums12_enabled = { 0x4bf71aa7, 0xe224, 0x415a, { 0xab, 0x2d, 0xe3, 0xbf, 0x4e, 0x34, 0x40, 0xe0 } };
cfg_bool cfg_menu_gapalbums12_enabled(guid_cfg_menu_gapalbums12_enabled, false);

// {B9C342E1-4CD2-4397-AD94-BDB721E45F9C}
static const GUID guid_cfg_menu_gapalbums13_enabled = { 0xb9c342e1, 0x4cd2, 0x4397, { 0xad, 0x94, 0xbd, 0xb7, 0x21, 0xe4, 0x5f, 0x9c } };
cfg_bool cfg_menu_gapalbums13_enabled(guid_cfg_menu_gapalbums13_enabled, false);

// {F9544AFF-671A-44FB-A557-B131CE88DBBB}
static const GUID guid_cfg_menu_gapalbums14_enabled = { 0xf9544aff, 0x671a, 0x44fb, { 0xa5, 0x57, 0xb1, 0x31, 0xce, 0x88, 0xdb, 0xbb } };
cfg_bool cfg_menu_gapalbums14_enabled(guid_cfg_menu_gapalbums14_enabled, false);

// {19FA67F4-F0E6-478E-988A-8E7373D8F861}
static const GUID guid_cfg_menu_gapalbums15_enabled = { 0x19fa67f4, 0xf0e6, 0x478e, { 0x98, 0x8a, 0x8e, 0x73, 0x73, 0xd8, 0xf8, 0x61 } };
cfg_bool cfg_menu_gapalbums15_enabled(guid_cfg_menu_gapalbums15_enabled, false);

// {6C96C956-6628-4DED-B214-16E8921822B1}
static const GUID guid_cfg_menu_gapalbums16_enabled = { 0x6c96c956, 0x6628, 0x4ded, { 0xb2, 0x14, 0x16, 0xe8, 0x92, 0x18, 0x22, 0xb1 } };
cfg_bool cfg_menu_gapalbums16_enabled(guid_cfg_menu_gapalbums16_enabled, false);

// {7F2D1121-8B48-48E0-83C5-94B1C07A7AD7}
static const GUID guid_cfg_menu_gapalbums17_enabled = { 0x7f2d1121, 0x8b48, 0x48e0, { 0x83, 0xc5, 0x94, 0xb1, 0xc0, 0x7a, 0x7a, 0xd7 } };
cfg_bool cfg_menu_gapalbums17_enabled(guid_cfg_menu_gapalbums17_enabled, false);

// {094F2865-4205-42D1-B71B-09F695F6F170}
static const GUID guid_cfg_menu_gapalbums18_enabled = { 0x94f2865, 0x4205, 0x42d1, { 0xb7, 0x1b, 0x9, 0xf6, 0x95, 0xf6, 0xf1, 0x70 } };
cfg_bool cfg_menu_gapalbums18_enabled(guid_cfg_menu_gapalbums18_enabled, false);

// {4787CE5B-9B7D-4830-B045-CB837CAD7EA1}
static const GUID guid_cfg_menu_gapalbums19_enabled = { 0x4787ce5b, 0x9b7d, 0x4830, { 0xb0, 0x45, 0xcb, 0x83, 0x7c, 0xad, 0x7e, 0xa1 } };
cfg_bool cfg_menu_gapalbums19_enabled(guid_cfg_menu_gapalbums19_enabled, false);

// {1D393003-26DF-4216-AC12-EEF8F2A4EF1D}
static const GUID guid_cfg_menu_gapalbums20_enabled = { 0x1d393003, 0x26df, 0x4216, { 0xac, 0x12, 0xee, 0xf8, 0xf2, 0xa4, 0xef, 0x1d } };
cfg_bool cfg_menu_gapalbums20_enabled(guid_cfg_menu_gapalbums20_enabled, false);


// {41885517-F27E-44DA-80F5-4AA6776C4A20}
static const GUID guid_cfg_menu_stopafteralbums1_enabled = { 0x41885517, 0xf27e, 0x44da, { 0x80, 0xf5, 0x4a, 0xa6, 0x77, 0x6c, 0x4a, 0x20 } };
cfg_bool cfg_menu_stopafteralbums1_enabled(guid_cfg_menu_stopafteralbums1_enabled, false);

// {DFC783EB-32B8-478F-9688-93C9DFBFDF32}
static const GUID guid_cfg_menu_stopafteralbums2_enabled = { 0xdfc783eb, 0x32b8, 0x478f, { 0x96, 0x88, 0x93, 0xc9, 0xdf, 0xbf, 0xdf, 0x32 } };
cfg_bool cfg_menu_stopafteralbums2_enabled(guid_cfg_menu_stopafteralbums2_enabled, false);

// {FC864581-DF45-47A9-BB9D-3FCF5E50BA0A}
static const GUID guid_cfg_menu_stopafteralbums3_enabled = { 0xfc864581, 0xdf45, 0x47a9, { 0xbb, 0x9d, 0x3f, 0xcf, 0x5e, 0x50, 0xba, 0xa } };
cfg_bool cfg_menu_stopafteralbums3_enabled(guid_cfg_menu_stopafteralbums3_enabled, false);

// {68596BFB-F7F9-430A-BC66-ABCDE7139DBD}
static const GUID guid_cfg_menu_stopafteralbums4_enabled = { 0x68596bfb, 0xf7f9, 0x430a, { 0xbc, 0x66, 0xab, 0xcd, 0xe7, 0x13, 0x9d, 0xbd } };
cfg_bool cfg_menu_stopafteralbums4_enabled(guid_cfg_menu_stopafteralbums4_enabled, false);

// {92B8B8C4-A439-42F6-A919-81A9B2F0AD73}
static const GUID guid_cfg_menu_stopafteralbums5_enabled = { 0x92b8b8c4, 0xa439, 0x42f6, { 0xa9, 0x19, 0x81, 0xa9, 0xb2, 0xf0, 0xad, 0x73 } };
cfg_bool cfg_menu_stopafteralbums5_enabled(guid_cfg_menu_stopafteralbums5_enabled, false);

// {F2C9BA43-0A93-4E83-B381-C137184EB058}
static const GUID guid_cfg_menu_stopafteralbums6_enabled = { 0xf2c9ba43, 0xa93, 0x4e83, { 0xb3, 0x81, 0xc1, 0x37, 0x18, 0x4e, 0xb0, 0x58 } };
cfg_bool cfg_menu_stopafteralbums6_enabled(guid_cfg_menu_stopafteralbums6_enabled, false);

// {9CF5F30A-72B1-4597-A86A-E3ADD284D6AD}
static const GUID guid_cfg_menu_stopafteralbums7_enabled = { 0x9cf5f30a, 0x72b1, 0x4597, { 0xa8, 0x6a, 0xe3, 0xad, 0xd2, 0x84, 0xd6, 0xad } };
cfg_bool cfg_menu_stopafteralbums7_enabled(guid_cfg_menu_stopafteralbums7_enabled, false);

// {E89C9C74-CD1D-494C-97FC-7DACEB4AF47F}
static const GUID guid_cfg_menu_stopafteralbums8_enabled = { 0xe89c9c74, 0xcd1d, 0x494c, { 0x97, 0xfc, 0x7d, 0xac, 0xeb, 0x4a, 0xf4, 0x7f } };
cfg_bool cfg_menu_stopafteralbums8_enabled(guid_cfg_menu_stopafteralbums8_enabled, false);

// {DEF1EB9D-2C9E-4AB0-BA8A-43EEF2C30217}
static const GUID guid_cfg_menu_stopafteralbums9_enabled = { 0xdef1eb9d, 0x2c9e, 0x4ab0, { 0xba, 0x8a, 0x43, 0xee, 0xf2, 0xc3, 0x2, 0x17 } };
cfg_bool cfg_menu_stopafteralbums9_enabled(guid_cfg_menu_stopafteralbums9_enabled, false);

// {9DEB3462-E87D-493A-B872-4B2A98A91141}
static const GUID guid_cfg_menu_stopafteralbums10_enabled = { 0x9deb3462, 0xe87d, 0x493a, { 0xb8, 0x72, 0x4b, 0x2a, 0x98, 0xa9, 0x11, 0x41 } };
cfg_bool cfg_menu_stopafteralbums10_enabled(guid_cfg_menu_stopafteralbums10_enabled, false);

// {825402FC-B58A-4B2A-842F-5C95166C8D6E}
static const GUID guid_cfg_menu_alarm1_enabled = { 0x825402fc, 0xb58a, 0x4b2a, { 0x84, 0x2f, 0x5c, 0x95, 0x16, 0x6c, 0x8d, 0x6e } };
cfg_bool cfg_menu_alarm1_enabled(guid_cfg_menu_alarm1_enabled, false);

// {F15D5AA1-0816-49A3-BA36-0A7B97492C7D}
static const GUID guid_cfg_menu_alarm2_enabled = { 0xf15d5aa1, 0x816, 0x49a3, { 0xba, 0x36, 0xa, 0x7b, 0x97, 0x49, 0x2c, 0x7d } };
cfg_bool cfg_menu_alarm2_enabled(guid_cfg_menu_alarm2_enabled, false);

// {3B2CB811-71D4-4DB8-BE65-FC9F55E1452E}
static const GUID guid_cfg_menu_alarm3_enabled = { 0x3b2cb811, 0x71d4, 0x4db8, { 0xbe, 0x65, 0xfc, 0x9f, 0x55, 0xe1, 0x45, 0x2e } };
cfg_bool cfg_menu_alarm3_enabled(guid_cfg_menu_alarm3_enabled, false);

// {89EFCF70-9099-4D9B-BE1C-51191DBF7C1D}
static const GUID guid_cfg_menu_alarm4_enabled = { 0x89efcf70, 0x9099, 0x4d9b, { 0xbe, 0x1c, 0x51, 0x19, 0x1d, 0xbf, 0x7c, 0x1d } };
cfg_bool cfg_menu_alarm4_enabled(guid_cfg_menu_alarm4_enabled, false);

// {AF14050B-5102-4D7B-91FB-149A4B4ABEAD}
static const GUID guid_cfg_menu_alarm5_enabled = { 0xaf14050b, 0x5102, 0x4d7b, { 0x91, 0xfb, 0x14, 0x9a, 0x4b, 0x4a, 0xbe, 0xad } };
cfg_bool cfg_menu_alarm5_enabled(guid_cfg_menu_alarm5_enabled, false);

// {02C57C01-74F0-47DE-A454-EB567B07AACD}
static const GUID guid_cfg_menu_alarm6_enabled = { 0x2c57c01, 0x74f0, 0x47de, { 0xa4, 0x54, 0xeb, 0x56, 0x7b, 0x7, 0xaa, 0xcd } };
cfg_bool cfg_menu_alarm6_enabled(guid_cfg_menu_alarm6_enabled, false);

// {6A69B42E-2A2F-4640-BC6C-543D3D2948A4}
static const GUID guid_cfg_menu_alarm7_enabled = { 0x6a69b42e, 0x2a2f, 0x4640, { 0xbc, 0x6c, 0x54, 0x3d, 0x3d, 0x29, 0x48, 0xa4 } };
cfg_bool cfg_menu_alarm7_enabled(guid_cfg_menu_alarm7_enabled, false);

// {64474B89-5465-4A75-AB1C-EDBE921CD474}
static const GUID guid_cfg_menu_alarm8_enabled = { 0x64474b89, 0x5465, 0x4a75, { 0xab, 0x1c, 0xed, 0xbe, 0x92, 0x1c, 0xd4, 0x74 } };
cfg_bool cfg_menu_alarm8_enabled(guid_cfg_menu_alarm8_enabled, false);

// {2D4F8F12-88B3-4F5B-B227-0F0884EC5E52}
static const GUID guid_cfg_menu_alarm9_enabled = { 0x2d4f8f12, 0x88b3, 0x4f5b, { 0xb2, 0x27, 0xf, 0x8, 0x84, 0xec, 0x5e, 0x52 } };
cfg_bool cfg_menu_alarm9_enabled(guid_cfg_menu_alarm9_enabled, false);

// {53D34470-8FB3-4FE6-B4C9-A4008A394F3D}
static const GUID guid_cfg_menu_alarm10_enabled = { 0x53d34470, 0x8fb3, 0x4fe6, { 0xb4, 0xc9, 0xa4, 0x0, 0x8a, 0x39, 0x4f, 0x3d } };
cfg_bool cfg_menu_alarm10_enabled(guid_cfg_menu_alarm10_enabled, false);

// {132FC33D-BA68-46D4-99C0-99C8A7B10D12}
static const GUID guid_cfg_menu_alarm11_enabled = { 0x132fc33d, 0xba68, 0x46d4, { 0x99, 0xc0, 0x99, 0xc8, 0xa7, 0xb1, 0xd, 0x12 } };
cfg_bool cfg_menu_alarm11_enabled(guid_cfg_menu_alarm11_enabled, false);

// {B6A8A9E1-51B8-4BE1-8E85-DB285E84002C}
static const GUID guid_cfg_menu_alarm12_enabled = { 0xb6a8a9e1, 0x51b8, 0x4be1, { 0x8e, 0x85, 0xdb, 0x28, 0x5e, 0x84, 0x0, 0x2c } };
cfg_bool cfg_menu_alarm12_enabled(guid_cfg_menu_alarm12_enabled, false);

// {C3D9B0D3-3623-4B56-94CF-F8553FBA8092}
static const GUID guid_cfg_menu_alarm13_enabled = { 0xc3d9b0d3, 0x3623, 0x4b56, { 0x94, 0xcf, 0xf8, 0x55, 0x3f, 0xba, 0x80, 0x92 } };
cfg_bool cfg_menu_alarm13_enabled(guid_cfg_menu_alarm13_enabled, false);

// {F893A4A2-D32F-494B-A52A-F8D3F7604D72}
static const GUID guid_cfg_menu_alarm14_enabled = { 0xf893a4a2, 0xd32f, 0x494b, { 0xa5, 0x2a, 0xf8, 0xd3, 0xf7, 0x60, 0x4d, 0x72 } };
cfg_bool cfg_menu_alarm14_enabled(guid_cfg_menu_alarm14_enabled, false);

// {3B61FDB2-D682-4C51-A9B4-274BA2B1341B}
static const GUID guid_cfg_menu_alarm15_enabled = { 0x3b61fdb2, 0xd682, 0x4c51, { 0xa9, 0xb4, 0x27, 0x4b, 0xa2, 0xb1, 0x34, 0x1b } };
cfg_bool cfg_menu_alarm15_enabled(guid_cfg_menu_alarm15_enabled, false);

// {A6337FC2-A46D-4C6D-BA12-CF238208B8EB}
static const GUID guid_cfg_menu_alarm16_enabled = { 0xa6337fc2, 0xa46d, 0x4c6d, { 0xba, 0x12, 0xcf, 0x23, 0x82, 0x8, 0xb8, 0xeb } };
cfg_bool cfg_menu_alarm16_enabled(guid_cfg_menu_alarm16_enabled, false);

// {71F8D95E-9D0D-4868-B74F-E3F6FD784343}
static const GUID guid_cfg_menu_alarm17_enabled = { 0x71f8d95e, 0x9d0d, 0x4868, { 0xb7, 0x4f, 0xe3, 0xf6, 0xfd, 0x78, 0x43, 0x43 } };
cfg_bool cfg_menu_alarm17_enabled(guid_cfg_menu_alarm17_enabled, false);

// {F3BCD4DB-6385-4F70-B7D7-CA790690A694}
static const GUID guid_cfg_menu_alarm18_enabled = { 0xf3bcd4db, 0x6385, 0x4f70, { 0xb7, 0xd7, 0xca, 0x79, 0x6, 0x90, 0xa6, 0x94 } };
cfg_bool cfg_menu_alarm18_enabled(guid_cfg_menu_alarm18_enabled, false);

// {683F54EA-F203-40F6-A01E-68EB538394D9}
static const GUID guid_cfg_menu_alarm19_enabled = { 0x683f54ea, 0xf203, 0x40f6, { 0xa0, 0x1e, 0x68, 0xeb, 0x53, 0x83, 0x94, 0xd9 } };
cfg_bool cfg_menu_alarm19_enabled(guid_cfg_menu_alarm19_enabled, false);

// {A3F426DA-0174-4849-9D9F-91F515CD441A}
static const GUID guid_cfg_menu_alarm20_enabled = { 0xa3f426da, 0x174, 0x4849, { 0x9d, 0x9f, 0x91, 0xf5, 0x15, 0xcd, 0x44, 0x1a } };
cfg_bool cfg_menu_alarm20_enabled(guid_cfg_menu_alarm20_enabled, false);

// {5ED4A9C6-249B-4AB9-8958-6CDEFEE4CDF2}
static const GUID guid_cfg_menu_alarm21_enabled = { 0x5ed4a9c6, 0x249b, 0x4ab9, { 0x89, 0x58, 0x6c, 0xde, 0xfe, 0xe4, 0xcd, 0xf2 } };
cfg_bool cfg_menu_alarm21_enabled(guid_cfg_menu_alarm21_enabled, false);

// {167EC633-35C5-4105-8DD1-27CF11459847}
static const GUID guid_cfg_menu_alarmabort_enabled = { 0x167ec633, 0x35c5, 0x4105, { 0x8d, 0xd1, 0x27, 0xcf, 0x11, 0x45, 0x98, 0x47 } };
cfg_bool cfg_menu_alarmabort_enabled(guid_cfg_menu_alarmabort_enabled, false);

// {81D69A32-C8F5-421F-8A68-8546B6BA7D22}
static const GUID guid_album2 = { 0x81d69a32, 0xc8f5, 0x421f, { 0x8a, 0x68, 0x85, 0x46, 0xb6, 0xba, 0x7d, 0x22 } };
cfg_int album2(guid_album2, 10);

// {D78EB8B7-9992-4520-A97C-50CFC0F97197}
static const GUID guid_track2 = { 0xd78eb8b7, 0x9992, 0x4520, { 0xa9, 0x7c, 0x50, 0xcf, 0xc0, 0xf9, 0x71, 0x97 } };
cfg_int track2(guid_track2, 20);

// {A2A57942-F51C-4A92-AD17-24C6313515CD}
static const GUID guid_cfg_gap_msec = { 0xa2a57942, 0xf51c, 0x4a92, { 0xad, 0x17, 0x24, 0xc6, 0x31, 0x35, 0x15, 0xcd } };
cfg_int gap_msec(guid_cfg_gap_msec, 10000);

// {8447CAA4-0766-4EB8-B687-1DD80A289DCB}
static const GUID guid_cfg_menu_reverse_enabled = { 0x8447caa4, 0x766, 0x4eb8, { 0xb6, 0x87, 0x1d, 0xd8, 0xa, 0x28, 0x9d, 0xcb } };
cfg_bool cfg_menu_reverse_enabled(guid_cfg_menu_reverse_enabled, false);


//advanced preferences branch

// {4648FD94-495E-41f0-8431-FB28BF4C8218}
static const GUID guid_cfg_branch = { 0x4648fd94, 0x495e, 0x41f0, { 0x84, 0x31, 0xfb, 0x28, 0xbf, 0x4c, 0x82, 0x18 } };
static advconfig_branch_factory cfg_branch("Stop after album", guid_cfg_branch, advconfig_entry::guid_branch_playback, 0);


//advanced preferences >playback | Stop after album< items

// {F13061ED-E4D7-4501-8CCC-5A22FDB0D31D}
static const GUID guid_cfg_album_enabled = { 0xf13061ed, 0xe4d7, 0x4501, { 0x8c, 0xcc, 0x5a, 0x22, 0xfd, 0xb0, 0xd3, 0x1d } };
advconfig_checkbox_factory_t<false> cfg_album_enabled("Album", guid_cfg_album_enabled, guid_cfg_branch, 0, false);

// {897F1E88-9985-4EF6-AAA1-6070D47B2E0F}
static const GUID guid_cfg_album = { 0x897f1e88, 0x9985, 0x4ef6, { 0xaa, 0xa1, 0x60, 0x70, 0xd4, 0x7b, 0x2e, 0xf } };
advconfig_string_factory cfg_album( "Album#", guid_cfg_album, guid_cfg_branch, 0, "1" );

// {434BB721-08AF-4B89-B3E8-2631540A6758}
static const GUID guid_cfg_lasttrack_enabled = { 0x434bb721, 0x8af, 0x4b89, { 0xb3, 0xe8, 0x26, 0x31, 0x54, 0xa, 0x67, 0x58 } };
advconfig_checkbox_factory_t<false> cfg_lasttrack_enabled("Last track", guid_cfg_lasttrack_enabled, guid_cfg_branch, 0, false);

// {CC67ACFC-6CA0-4DDC-8633-8070161CC402}
static const GUID guid_cfg_track_enabled = { 0xcc67acfc, 0x6ca0, 0x4ddc, { 0x86, 0x33, 0x80, 0x70, 0x16, 0x1c, 0xc4, 0x2 } };
advconfig_checkbox_factory_t<false> cfg_track_enabled("Track", guid_cfg_track_enabled, guid_cfg_branch, 0, false);

// {2937D2AE-2C95-4C12-BFE1-39B4538B632C}
static const GUID guid_cfg_track = { 0x2937d2ae, 0x2c95, 0x4c12, { 0xbf, 0xe1, 0x39, 0xb4, 0x53, 0x8b, 0x63, 0x2c } };
advconfig_string_factory cfg_track( "Track#", guid_cfg_track, guid_cfg_branch, 0, "10" );


// {507F3295-C0FC-4E35-8F70-095042775A51}
static const GUID guid_cfg_time_enabled = { 0x507f3295, 0xc0fc, 0x4e35, { 0x8f, 0x70, 0x9, 0x50, 0x42, 0x77, 0x5a, 0x51 } };
advconfig_checkbox_factory_t<false> cfg_time_enabled("Time", guid_cfg_time_enabled, guid_cfg_branch, 0, false);

// {B247B015-C82D-4218-89E8-9F88B68D8781}
static const GUID guid_cfg_time = { 0xb247b015, 0xc82d, 0x4218, { 0x89, 0xe8, 0x9f, 0x88, 0xb6, 0x8d, 0x87, 0x81 } };
advconfig_string_factory cfg_time( "Time# min", guid_cfg_time, guid_cfg_branch, 0, "60" );


// {A7B2A7F6-8333-4E0E-BBE2-94F5FD340E63}
static const GUID guid_cfg_only_stop_once_album = { 0xa7b2a7f6, 0x8333, 0x4e0e, { 0xbb, 0xe2, 0x94, 0xf5, 0xfd, 0x34, 0xe, 0x63 } };
advconfig_checkbox_factory_t<false> cfg_only_stop_once_album("Album only stop once", guid_cfg_only_stop_once_album, guid_cfg_branch, 0, false);


// {7B6E06E2-48B6-48EA-A0E1-DA8F6E59667B}
static const GUID guid_cfg_only_stop_once_time = { 0x7b6e06e2, 0x48b6, 0x48ea, { 0xa0, 0xe1, 0xda, 0x8f, 0x6e, 0x59, 0x66, 0x7b } };
advconfig_checkbox_factory_t<false> cfg_only_stop_once_time("Time only stop once", guid_cfg_only_stop_once_time, guid_cfg_branch, 0, false);

// {EF350E26-F1CE-47C6-8185-FE82277F9385}
static const GUID guid_cfg_only_stop_once_track = { 0xef350e26, 0xf1ce, 0x47c6, { 0x81, 0x85, 0xfe, 0x82, 0x27, 0x7f, 0x93, 0x85 } };
advconfig_checkbox_factory_t<false> cfg_only_stop_once_track("Track only stop once", guid_cfg_only_stop_once_track, guid_cfg_branch, 0, false);


// {DC4E8ECB-7F4D-4A5C-BF0C-AE270B996F85}
static const GUID guid_cfg_timebomb_enabled = { 0xdc4e8ecb, 0x7f4d, 0x4a5c, { 0xbf, 0xc, 0xae, 0x27, 0xb, 0x99, 0x6f, 0x85 } };
advconfig_checkbox_factory_t<false> cfg_timebomb_enabled("Timebomb (once)", guid_cfg_timebomb_enabled, guid_cfg_branch, 0, false);

// {AD52F7A1-EE84-4DEF-B7D8-CE0822087F4B}
static const GUID guid_cfg_timebomb_suddendeath_enabled = { 0xad52f7a1, 0xee84, 0x4def, { 0xb7, 0xd8, 0xce, 0x8, 0x22, 0x8, 0x7f, 0x4b } };
advconfig_checkbox_factory_t<false> cfg_timebomb_suddendeath_enabled("Timebomb (once) sudden death", guid_cfg_timebomb_suddendeath_enabled, guid_cfg_branch, 0, false);

// {00C098EA-FABD-424B-AB08-2B8CFCF5B3FB}
static const GUID guid_cfg_timebomb = { 0xc098ea, 0xfabd, 0x424b, { 0xab, 0x8, 0x2b, 0x8c, 0xfc, 0xf5, 0xb3, 0xfb } };
advconfig_string_factory cfg_timebomb( "Timebomb# min", guid_cfg_timebomb, guid_cfg_branch, 0, "10" );

// {0A6728FE-F645-4C9F-8BAE-00E58B2C575C}
static const GUID guid_cfg_branch_timebomb = { 0xa6728fe, 0xf645, 0x4c9f, { 0x8b, 0xae, 0x0, 0xe5, 0x8b, 0x2c, 0x57, 0x5c } };
static advconfig_branch_factory cfg_branch_timebomb("Timebomb", guid_cfg_branch_timebomb, guid_cfg_branch, 0);

// {745C9C02-6A01-468E-84E6-9D0444B38CF4}
static const GUID guid_cfg_timebomb_message_enabled = { 0x745c9c02, 0x6a01, 0x468e, { 0x84, 0xe6, 0x9d, 0x4, 0x44, 0xb3, 0x8c, 0xf4 } };
advconfig_checkbox_factory_t<false> cfg_timebomb_message_enabled("Timebomb message", guid_cfg_timebomb_message_enabled, guid_cfg_branch_timebomb, 0, true);

// {F9E55B9E-AD10-481C-A91F-B77D2F091B03}
static const GUID guid_cfg_timebomb_message = { 0xf9e55b9e, 0xad10, 0x481c, { 0xa9, 0x1f, 0xb7, 0x7d, 0x2f, 0x9, 0x1b, 0x3 } };
advconfig_string_factory cfg_timebomb_message( "Timebomb# message", guid_cfg_timebomb_message, guid_cfg_branch_timebomb, 0, "appointment?" );

// {939944B9-C354-4284-95E0-D059F5407D39}
static const GUID guid_cfg_alarm = { 0x939944b9, 0xc354, 0x4284, { 0x95, 0xe0, 0xd0, 0x59, 0xf5, 0x40, 0x7d, 0x39 } };
advconfig_string_factory cfg_alarm( "Alarm# min", guid_cfg_alarm, guid_cfg_branch, 0, "10" );

// {3B69FC04-86E3-4C8C-8D9C-7EF929A0B2DE}
static const GUID guid_cfg_branch_alarm = { 0x3b69fc04, 0x86e3, 0x4c8c, { 0x8d, 0x9c, 0x7e, 0xf9, 0x29, 0xa0, 0xb2, 0xde } };
static advconfig_branch_factory cfg_branch_alarm("Alarm", guid_cfg_branch_alarm, guid_cfg_branch, 0);

// {B6A45B87-8757-4C41-BFCA-964925C41D4B}
static const GUID guid_cfg_alarm_message_enabled = { 0xb6a45b87, 0x8757, 0x4c41, { 0xbf, 0xca, 0x96, 0x49, 0x25, 0xc4, 0x1d, 0x4b } };
advconfig_checkbox_factory_t<false> cfg_alarm_message_enabled("Alarm message", guid_cfg_alarm_message_enabled, guid_cfg_branch_alarm, 0, false);

// {1F998CBE-9258-442A-BB58-8ED1184BB0AA}
static const GUID guid_cfg_alarm_message = { 0x1f998cbe, 0x9258, 0x442a, { 0xbb, 0x58, 0x8e, 0xd1, 0x18, 0x4b, 0xb0, 0xaa } };
advconfig_string_factory cfg_alarm_message( "Alarm# message", guid_cfg_alarm_message, guid_cfg_branch_alarm, 0, "appointment?" );

// {7D3B00B2-D433-43D9-9574-9B1B83C139B0}
static const GUID guid_cfg_gap = { 0x7d3b00b2, 0xd433, 0x43d9, { 0x95, 0x74, 0x9b, 0x1b, 0x83, 0xc1, 0x39, 0xb0 } };
advconfig_string_factory cfg_gap( "-Gap & play# msec", guid_cfg_gap, guid_cfg_branch, 0, "5000" );

// {AC8AF3DF-754E-4CB3-AAD7-099C3757704D}
static const GUID guid_cfg_gap2 = { 0xac8af3df, 0x754e, 0x4cb3, { 0xaa, 0xd7, 0x9, 0x9c, 0x37, 0x57, 0x70, 0x4d } };
advconfig_string_factory cfg_gap2( "-Gap & pause# msec", guid_cfg_gap2, guid_cfg_branch, 0, "0" );

// {C6F7D29A-AF34-440B-A7E2-AD43D7C78383}
static const GUID guid_cfg_paused_enabled = { 0xc6f7d29a, 0xaf34, 0x440b, { 0xa7, 0xe2, 0xad, 0x43, 0xd7, 0xc7, 0x83, 0x83 } };
advconfig_checkbox_factory_t<true> cfg_paused_enabled("-Gap & pause", guid_cfg_paused_enabled, guid_cfg_branch, 0, false);

// {F37950F0-BED5-476F-87A8-97B4F053A58E}
static const GUID guid_cfg_gap_enabled = { 0xf37950f0, 0xbed5, 0x476f, { 0x87, 0xa8, 0x97, 0xb4, 0xf0, 0x53, 0xa5, 0x8e } };
advconfig_checkbox_factory_t<true> cfg_gap_enabled("-Gap & play", guid_cfg_gap_enabled, guid_cfg_branch, 0, false);

// {30FCCCAB-1F28-4D96-ADD2-FAFF52127E43}
static const GUID guid_cfg_branch_repeatalbum = { 0x30fcccab, 0x1f28, 0x4d96, { 0xad, 0xd2, 0xfa, 0xff, 0x52, 0x12, 0x7e, 0x43 } };
static advconfig_branch_factory cfg_branch_repeatalbum("-Repeat album", guid_cfg_branch_repeatalbum, guid_cfg_branch, 0);

// {1349EDB1-44CD-4259-84EA-DCFCD17F49A1}
static const GUID guid_cfg_repeatalbum = { 0x1349edb1, 0x44cd, 0x4259, { 0x84, 0xea, 0xdc, 0xfc, 0xd1, 0x7f, 0x49, 0xa1 } };
advconfig_string_factory cfg_repeatalbum( "Back to tracknumber", guid_cfg_repeatalbum, guid_cfg_branch_repeatalbum, 0, "1" );

// {98D49937-93B2-4960-8A02-A27F64438750}
static const GUID guid_cfg_repeatalbum_enabled = { 0x98d49937, 0x93b2, 0x4960, { 0x8a, 0x2, 0xa2, 0x7f, 0x64, 0x43, 0x87, 0x50 } };
advconfig_checkbox_factory_t<true> cfg_repeatalbum_enabled("-Repeat album", guid_cfg_repeatalbum_enabled, guid_cfg_branch, 0, false);

// {0A02FC38-CB11-4CAC-87DC-90619034AD3D}
static const GUID guid_cfg_repeatalbum_only_once = { 0xa02fc38, 0xcb11, 0x4cac, { 0x87, 0xdc, 0x90, 0x61, 0x90, 0x34, 0xad, 0x3d } };
advconfig_checkbox_factory_t<true> cfg_repeatalbum_only_once("-Repeat album only once", guid_cfg_repeatalbum_only_once, guid_cfg_branch, 0, false);

// {7A8D4611-15E1-41A8-8B06-665C6A23B3BF}
static const GUID guid_cfg_skipalbum_enabled = { 0x7a8d4611, 0x15e1, 0x41a8, { 0x8b, 0x6, 0x66, 0x5c, 0x6a, 0x23, 0xb3, 0xbf } };
advconfig_checkbox_factory_t<true> cfg_skipalbum_enabled("-Skip album", guid_cfg_skipalbum_enabled, guid_cfg_branch, 0, false);

// {C8D0049C-5F3C-417A-982C-71F71BBCE1DD}
static const GUID guid_cfg_skipalbum_only_once = { 0xc8d0049c, 0x5f3c, 0x417a, { 0x98, 0x2c, 0x71, 0xf7, 0x1b, 0xbc, 0xe1, 0xdd } };
advconfig_checkbox_factory_t<true> cfg_skipalbum_only_once("-Skip album only once", guid_cfg_skipalbum_only_once, guid_cfg_branch, 0, false);

// {AB4C23E3-B9A8-44E6-8742-2E9F95C0EBD3}
static const GUID guid_cfg_stop_enabled = { 0xab4c23e3, 0xb9a8, 0x44e6, { 0x87, 0x42, 0x2e, 0x9f, 0x95, 0xc0, 0xeb, 0xd3 } };
advconfig_checkbox_factory_t<true> cfg_stop_enabled("-Stop", guid_cfg_stop_enabled, guid_cfg_branch, 0, true);

// {9D6F696B-6798-42BB-B412-20812B3A313D}
static const GUID guid_cfg_randomalbum_enabled = { 0x9d6f696b, 0x6798, 0x42bb, { 0xb4, 0x12, 0x20, 0x81, 0x2b, 0x3a, 0x31, 0x3d } };
advconfig_checkbox_factory_t<false> cfg_randomalbum_enabled("+Random album", guid_cfg_randomalbum_enabled, guid_cfg_branch, 0, false);

// {D5FF72E4-77B3-4F4C-81B1-DAC358D86A5D}
static const GUID guid_cfg_reverse_enabled = { 0xd5ff72e4, 0x77b3, 0x4f4c, { 0x81, 0xb1, 0xda, 0xc3, 0x58, 0xd8, 0x6a, 0x5d } };
advconfig_checkbox_factory_t<false> cfg_reverse_enabled("+Reverse", guid_cfg_reverse_enabled, guid_cfg_branch, 0, false);

// {E3A35EC3-67B5-49CE-B7D0-4E3E1363267E}
static const GUID guid_cfg_tracknumber_enabled = { 0xe3a35ec3, 0x67b5, 0x49ce, { 0xb7, 0xd0, 0x4e, 0x3e, 0x13, 0x63, 0x26, 0x7e } };
advconfig_checkbox_factory_t<false> cfg_tracknumber_enabled("Tracknumber", guid_cfg_tracknumber_enabled, guid_cfg_branch, 0, false);

// {460AA902-8299-4D36-BD33-AF975B9B98D7}
static const GUID guid_cfg_tracknumber = { 0x460aa902, 0x8299, 0x4d36, { 0xbd, 0x33, 0xaf, 0x97, 0x5b, 0x9b, 0x98, 0xd7 } };
advconfig_string_factory cfg_tracknumber( "Tracknumber#", guid_cfg_tracknumber, guid_cfg_branch, 0, "5" );

// {D8D1E11E-29A8-4FCF-9E75-7AE9225290A7}
static const GUID guid_cfg_only_stop_once_tracknumber = { 0xd8d1e11e, 0x29a8, 0x4fcf, { 0x9e, 0x75, 0x7a, 0xe9, 0x22, 0x52, 0x90, 0xa7 } };
advconfig_checkbox_factory_t<false> cfg_only_stop_once_tracknumber("Tracknumber only stop once", guid_cfg_only_stop_once_tracknumber, guid_cfg_branch, 0, false);

// {8B0E6842-3E60-4057-AE48-B688B706A1C5}
static const GUID guid_cfg_skiptrack_enabled = { 0x8b0e6842, 0x3e60, 0x4057, { 0xae, 0x48, 0xb6, 0x88, 0xb7, 0x6, 0xa1, 0xc5 } };
advconfig_checkbox_factory_t<true> cfg_skiptrack_enabled("-Skip next track", guid_cfg_skiptrack_enabled, guid_cfg_branch, 0, false);

// {9199C0E0-6895-42FE-ABA3-29BC012605E1}
static const GUID guid_cfg_nextplaylist_enabled = { 0x9199c0e0, 0x6895, 0x42fe, { 0xab, 0xa3, 0x29, 0xbc, 0x1, 0x26, 0x5, 0xe1 } };
advconfig_checkbox_factory_t<true> cfg_nextplaylist_enabled("-Next playlist (focused track)", guid_cfg_nextplaylist_enabled, guid_cfg_branch, 0, false);

// {89F8DF4B-377E-4EB2-9FA3-DBE572DFD7D3}
static const GUID guid_cfg_repeatplaylist_enabled = { 0x89f8df4b, 0x377e, 0x4eb2, { 0x9f, 0xa3, 0xdb, 0xe5, 0x72, 0xdf, 0xd7, 0xd3 } };
advconfig_checkbox_factory_t<false> cfg_repeatplaylist_enabled("+Repeat playlist", guid_cfg_repeatplaylist_enabled, guid_cfg_branch, 0, false);

// {910D6CB7-C9B8-49DE-B518-31551E5BECB5}
static const GUID guid_cfg_previousplaylistfirst_enabled = { 0x910d6cb7, 0xc9b8, 0x49de, { 0xb5, 0x18, 0x31, 0x55, 0x1e, 0x5b, 0xec, 0xb5 } };
advconfig_checkbox_factory_t<false> cfg_previousplaylistfirst_enabled("+Previous playlist", guid_cfg_previousplaylistfirst_enabled, guid_cfg_branch, 0, false);

// {2016F28B-0C9D-4B19-85C7-611B4B9A563F}
static const GUID guid_cfg_nextplaylistfirst_enabled = { 0x2016f28b, 0xc9d, 0x4b19, { 0x85, 0xc7, 0x61, 0x1b, 0x4b, 0x9a, 0x56, 0x3f } };
advconfig_checkbox_factory_t<false> cfg_nextplaylistfirst_enabled("+Next playlist", guid_cfg_nextplaylistfirst_enabled, guid_cfg_branch, 0, false);


//EOF