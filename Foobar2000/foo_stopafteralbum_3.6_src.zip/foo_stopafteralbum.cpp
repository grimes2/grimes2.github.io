#include "stdafx.h"

#include "config.h"
#include "option.h"

#define ID_TIMER 1001
#define ID_TIMER2 1011
#define ID_TIMER3 1111
#define ID_TIMER4 1000
#define ID_TIMER10 1010

DECLARE_COMPONENT_VERSION(
	"Stop after album",
	"3.6",
	"Stop after album v3.6\n"
	"Created by grimes\n"
	"Build: " __DATE__ " " __TIME__ "\n\n"
	"Usage:\n"
	"Menu | Playback | Control | Stop after album (ON/OFF)\n"
	"Menu | Playback | Control | Stop after last track (ON/OFF)\n"
	"Menu | Playback | Control | Stop after album & last track (ON/OFF)\n"
	"Menu | Playback | Control | Repeat album (ON/OFF)\n"
	"Menu | Playback | Control | Skip album once (ON/OFF)\n"
	"Menu | Playback | Control | Random album track (ON/OFF)\n"
	"Menu | Playback | Control | Repeat current track once (ON/OFF)\n"
	"Menu | Playback | Control | Skip next track once (ON/OFF)\n"
	"Menu | Playback | Control | Reverse (ON/OFF)\n"
	"Menu | Playback | Control | Previous playlist (ON/OFF)\n"
	"Menu | Playback | Control | Next playlist (ON/OFF)\n"
	"Menu | Playback | Control | Repeat playlist once (ON/OFF)\n"
	"Menu | Playback | Control | Postgap (ON/OFF)\n"
	"Menu | Playback | Control | Gap tracks | 5s - 1h (ON/OFF)\n"
	"Menu | Playback | Control | Gap albums | 5s - 1h (ON/OFF)\n"
	"Menu | Playback | Control | Stop after albums once | 1 - 10 (ON/OFF)\n"
	"Menu | Playback | Control | Stop after tracks once | 1 - 20 (ON/OFF)\n"
	"Menu | Playback | Control | Alarm | 5s - 5h (ON/OFF)\n"
	"Menu | Playback | Control | Timebomb | 0.5h - 5h (ON/OFF)\n\n"
	"Advanced Preferences | Playback | Stop after album (OPTION/MODE)\n\n"
	"MODE (triggers event 'stop after current->stop')\n"
	"(Core: Menu | Playback | Stop after current)\n"
	"Album\n"
	"Last track\n"
	"Time\n"
	"Timebomb\n"
	"Track\n"
	"Tracknumber\n\n"
	"OPTION (action following event 'stop after current->stop')\n"
	"-Gap & pause\n"
	"-Gap & play\n"
	"-Next playlist (focused track)\n"
	"-Repeat\n"
	"-Skip\n"
	"-Stop\n\n"
	"Comments:\n"
	"Stop after album: TRACKNUMBER = TOTALTRACKS\n"
	"Stop after last track: create field name LASTTRACK with field value 1\n"
	"Postgap: create field name POSTGAP with field value x.xx in seconds"
);

VALIDATE_COMPONENT_FILENAME("foo_stopafteralbum.dll");

//global variables
pfc::string8 tag1;
pfc::string8 tag2;
pfc::string8 tag3;
pfc::string8 tag4;
pfc::string8 tag5;
pfc::string8 tracknumber;
int tracknumber2;
pfc::string8 totaltracks;
int totaltracks2;
pfc::string8 lasttrack;
int lasttrack2;
pfc::string8 postgap;
double postgap2;
int gap_sec2;
pfc::string8 length;
double playback_new_track;
double length2;
double length3;
double length2_min;
pfc::string8 timemin;
pfc::string8 track;
pfc::string8 album;
pfc::string8 trackno;
int trackno2;
pfc::string8 stopaftercurrent_trackno;
int stopaftercurrent_trackno2;
bool cfg_track_enabled_old = false;
bool cfg_only_stop_once_track_old = false;
bool cfg_album_enabled_old = false;
bool cfg_time_enabled_old = false;
bool cfg_tracknumber_enabled_old = false;
int album_end;
pfc::string8 timebomb_min;
int timebomb_min2;
pfc::string8 alarm_min;
int alarm_min2;
bool deactivate = false;

bool trackonce = false;
bool albumonce = false;
bool timeonce = false;
bool tracknumberonce = false;

pfc::string8 gap_sec;
pfc::string8 albumoption;
pfc::string8 timeoption;
pfc::string8 trackoption;
pfc::string8 tracknumberoption;

int random_tracknumber;

UINT_PTR ptr10;
UINT_PTR ptr11;
UINT_PTR ptr12;
UINT_PTR ptr15;
UINT_PTR ptr21;

class random
{

public:

	static int get_random()
	{
		int random_integer;
		int lowest = 1;
		int highest = atoi(totaltracks);
		int range = (highest - lowest) + 1;
		random_integer = lowest + int(range * rand() / (RAND_MAX + 1.0));
		return random_integer;
	}
};

// {05C35BEA-7625-4BCE-B3FD-ABCD22FC71D3}
static const GUID guid_cfg_menu_control = { 0x5c35bea, 0x7625, 0x4bce, { 0xb3, 0xfd, 0xab, 0xcd, 0x22, 0xfc, 0x71, 0xd3 } };

class mainmenu_commands_stopafteralbum : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 8;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {42E2EBA7-F0CA-43b6-AAF5-13509598CFB4}
		static const GUID guid_main_stopafteralbum_toggle = { 0x42e2eba7, 0xf0ca, 0x43b6, { 0xaa, 0xf5, 0x13, 0x50, 0x95, 0x98, 0xcf, 0xb4 } };
		// {E11F16AA-780B-459D-9D0A-D71DB32F5070}
		static const GUID guid_main_lasttrack_toggle = { 0xe11f16aa, 0x780b, 0x459d, { 0x9d, 0xa, 0xd7, 0x1d, 0xb3, 0x2f, 0x50, 0x70 } };
		// {A2B305BF-817B-4ADB-96F3-8F4EE87C8FB9}
		static const GUID guid_main_albumlasttrack_toggle = { 0xa2b305bf, 0x817b, 0x4adb, { 0x96, 0xf3, 0x8f, 0x4e, 0xe8, 0x7c, 0x8f, 0xb9 } };
		// {F461BAA0-6FA5-4BFE-9D06-0D0B648C5755}
		static const GUID guid_main_repeatalbum_toggle = { 0xf461baa0, 0x6fa5, 0x4bfe, { 0x9d, 0x6, 0xd, 0xb, 0x64, 0x8c, 0x57, 0x55 } };
		// {AF17E296-88EC-4BCD-BC0C-02ECEB1213F9}
		static const GUID guid_main_skipalbum_toggle = { 0xaf17e296, 0x88ec, 0x4bcd, { 0xbc, 0xc, 0x2, 0xec, 0xeb, 0x12, 0x13, 0xf9 } };
		// {8DB4ADDC-992D-4562-84E7-CC0161EC2E29}
		static const GUID guid_main_randomalbum_toggle = { 0x8db4addc, 0x992d, 0x4562, { 0x84, 0xe7, 0xcc, 0x1, 0x61, 0xec, 0x2e, 0x29 } };
		// {072DAEE5-1966-4380-9F77-75F50C032E92}
		static const GUID guid_main_repeattrack_toggle = { 0x72daee5, 0x1966, 0x4380, { 0x9f, 0x77, 0x75, 0xf5, 0xc, 0x3, 0x2e, 0x92 } };
		// {8E704730-216C-468C-BA28-6C1E887E2FB4}
		static const GUID guid_main_skiptrack_toggle = { 0x8e704730, 0x216c, 0x468c, { 0xba, 0x28, 0x6c, 0x1e, 0x88, 0x7e, 0x2f, 0xb4 } };


		if (p_index == 0)
			return guid_main_stopafteralbum_toggle;
		if (p_index == 1)
			return guid_main_lasttrack_toggle;
		if (p_index == 2)
			return guid_main_albumlasttrack_toggle;
		if (p_index == 3)
			return guid_main_repeatalbum_toggle;
		if (p_index == 4)
			return guid_main_skipalbum_toggle;
		if (p_index == 5)
			return guid_main_randomalbum_toggle;
		if (p_index == 6)
			return guid_main_repeattrack_toggle;
		if (p_index == 7)
			return guid_main_skiptrack_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Stop after album";
		if (p_index == 1)
			p_out = "Stop after last track";
		if (p_index == 2)
			p_out = "Stop after album & last track";
		if (p_index == 3)
			p_out = "Repeat album";
		if (p_index == 4)
			p_out = "Skip album once";
		if (p_index == 5)
			p_out = "Random album track";
		if (p_index == 6)
			p_out = "Repeat current track once";
		if (p_index == 7)
			p_out = "Skip next track once";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Stop playback after currently played album (%tracknumber% = %totaltracks%).";
		else if (p_index == 1)
			p_out = "Stop playback after tracks with tag %lasttrack% and value 1.";
		else if (p_index == 2)
			p_out = "Stop playback after album & last track.";
		else if (p_index == 3)
			p_out = "Repeat currently played album.";
		else if (p_index == 4)
			p_out = "Skip next album once.";
		else if (p_index == 5)
			p_out = "Play random tracks of an album.";
		else if (p_index == 6)
			p_out = "Repeat currently playing track only once. Permanent: use playback order 'Repeat (track)'.";
		else if (p_index == 7)
			p_out = "Skip next track only once.";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_control;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		option2::set_option(3);
		option2::set_option(4);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_stopalbum_enabled = !cfg_menu_stopalbum_enabled;
			if (cfg_menu_stopalbum_enabled)
			{
				option4::set_option(1);
				cfg_menu_stopalbum_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				cfg_lasttrack_enabled = false;
				cfg_randomalbum_enabled = false;
				album2 = 1;
				option::set_option(7);
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
					console::info("Stop after current (album)");
				}
				else
				{
					console::info("Stop after album");
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_stoplasttrack_enabled = !cfg_menu_stoplasttrack_enabled;
			if (cfg_menu_stoplasttrack_enabled)
			{
				option4::set_option(1);
				cfg_menu_stoplasttrack_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_lasttrack_enabled = true;
				cfg_album_enabled = false;
				cfg_randomalbum_enabled = false;
				option::set_option(7);
				if ((lasttrack2 == 1) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
					console::info("Stop after current (last track)");
				}
				else
				{
					console::info("Stop after last track");
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_stopalbumlasttrack_enabled = !cfg_menu_stopalbumlasttrack_enabled;
			if (cfg_menu_stopalbumlasttrack_enabled)
			{
				option4::set_option(1);
				cfg_menu_stopalbumlasttrack_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_lasttrack_enabled = true;
				cfg_album_enabled = true;
				cfg_randomalbum_enabled = false;
				album2 = 1;
				option::set_option(7);
				if (((lasttrack2 == 1) || (totaltracks2 == tracknumber2)) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
					console::info("Stop after current (album & last track)");
				}
				else
				{
					console::info("Stop after album & last track");
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_repeatalbum_enabled = !cfg_menu_repeatalbum_enabled;
			if (cfg_menu_repeatalbum_enabled)
			{
				option4::set_option(1);
				cfg_menu_repeatalbum_enabled = true;
				option::set_option(10);
				cfg_album_enabled = true;
				album2 = 1;
				cfg_randomalbum_enabled = false;
				cfg_repeatalbum_enabled = true;
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				console::info("Repeat album");
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_skipalbum_enabled = !cfg_menu_skipalbum_enabled;
			if (cfg_menu_skipalbum_enabled)
			{
				option4::set_option(1);
				cfg_menu_skipalbum_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				cfg_randomalbum_enabled = false;
				cfg_skipalbum_only_once = true;
				console::info("Skip album once");
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = false;
				option::set_option(7);
			}
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_randomalbum_enabled = !cfg_menu_randomalbum_enabled;
			if (cfg_menu_randomalbum_enabled)
			{
				option4::set_option(1);
				cfg_menu_randomalbum_enabled = true;
				option::set_option(10);
				cfg_randomalbum_enabled = true;
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				console::info("Random album track");
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_randomalbum_enabled = false;
				option4::set_option(2);
				option::set_option(7);
			}
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_repeattrack_enabled = !cfg_menu_repeattrack_enabled;
			if (cfg_menu_repeattrack_enabled)
			{
				option4::set_option(1);
				cfg_menu_repeattrack_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::info("Repeat current once");
			}
			else static_api_ptr_t<playback_control>()->set_stop_after_current(false);

		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_skiptrack_enabled = !cfg_menu_skiptrack_enabled;
			if (cfg_menu_skiptrack_enabled)
			{
				option4::set_option(1);
				cfg_menu_skiptrack_enabled = true;
				option::set_option(10);
				cfg_skiptrack_enabled = true;
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::info("Skip next once");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
			}
		}
		option2::set_option(1);
		option2::set_option(5);
		option2::set_option(6);
		cfg_reverse_enabled = false;
		cfg_menu_reverse_enabled = false;
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_stopalbum_enabled;
		if (p_index == 1)
			return cfg_menu_stoplasttrack_enabled;
		if (p_index == 2)
			return cfg_menu_stopalbumlasttrack_enabled;
		if (p_index == 3)
			return cfg_menu_repeatalbum_enabled;
		if (p_index == 4)
			return cfg_menu_skipalbum_enabled;
		if (p_index == 5)
			return cfg_menu_randomalbum_enabled;
		if (p_index == 6)
			return cfg_menu_repeattrack_enabled;
		if (p_index == 7)
			return cfg_menu_skiptrack_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_stopafteralbum> g_mainmenu_commands_stopafteralbum;

static mainmenu_group_popup_factory mainmenu_group(guid_cfg_menu_control,
        mainmenu_groups::playback, mainmenu_commands::sort_priority_base,
        "Control");


// {0BE5EDBF-8154-4E12-8D98-47FE72653AF1}
static const GUID guid_cfg_menu_gaptracks = { 0xbe5edbf, 0x8154, 0x4e12, { 0x8d, 0x98, 0x47, 0xfe, 0x72, 0x65, 0x3a, 0xf1 } };

class mainmenu_commands_gaptracks : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		//return 20;
		return 19;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{

		// {2CF8C17C-15A1-4E9D-8F5A-AF193C63A694}
		static const GUID guid_main_gaptracks1_toggle = { 0x2cf8c17c, 0x15a1, 0x4e9d, { 0x8f, 0x5a, 0xaf, 0x19, 0x3c, 0x63, 0xa6, 0x94 } };
		// {708328E7-6CF9-4C7F-BC54-6576F048C020}
		static const GUID guid_main_gaptracks2_toggle = { 0x708328e7, 0x6cf9, 0x4c7f, { 0xbc, 0x54, 0x65, 0x76, 0xf0, 0x48, 0xc0, 0x20 } };
		// {F4DA5B01-F7A3-4876-80FA-1E2C272F92D3}
		static const GUID guid_main_gaptracks3_toggle = { 0xf4da5b01, 0xf7a3, 0x4876, { 0x80, 0xfa, 0x1e, 0x2c, 0x27, 0x2f, 0x92, 0xd3 } };
		// {434050DF-19AC-4894-9BFF-DAC8B8F54F91}
		static const GUID guid_main_gaptracks4_toggle = { 0x434050df, 0x19ac, 0x4894, { 0x9b, 0xff, 0xda, 0xc8, 0xb8, 0xf5, 0x4f, 0x91 } };
		// {9089F047-FD8D-4D74-B645-089AFA93A6A9}
		static const GUID guid_main_gaptracks5_toggle = { 0x9089f047, 0xfd8d, 0x4d74, { 0xb6, 0x45, 0x8, 0x9a, 0xfa, 0x93, 0xa6, 0xa9 } };
		// {B76A15D2-F2FC-42C9-9BA9-12EFB5D08676}
		static const GUID guid_main_gaptracks6_toggle = { 0xb76a15d2, 0xf2fc, 0x42c9, { 0x9b, 0xa9, 0x12, 0xef, 0xb5, 0xd0, 0x86, 0x76 } };
		// {FA9B6531-D0A7-497F-ACB7-BB31BADAFCDB}
		static const GUID guid_main_gaptracks7_toggle = { 0xfa9b6531, 0xd0a7, 0x497f, { 0xac, 0xb7, 0xbb, 0x31, 0xba, 0xda, 0xfc, 0xdb } };
		// {8BA7F5FC-44F1-4DCC-B157-4FBEB302C27B}
		static const GUID guid_main_gaptracks8_toggle = { 0x8ba7f5fc, 0x44f1, 0x4dcc, { 0xb1, 0x57, 0x4f, 0xbe, 0xb3, 0x2, 0xc2, 0x7b } };
		// {31041DD2-463E-45B5-97D8-F15736156DEA}
		static const GUID guid_main_gaptracks9_toggle = { 0x31041dd2, 0x463e, 0x45b5, { 0x97, 0xd8, 0xf1, 0x57, 0x36, 0x15, 0x6d, 0xea } };
		// {AA2AA0D1-2D59-4839-8E14-B6D87B99088C}
		static const GUID guid_main_gaptracks10_toggle = { 0xaa2aa0d1, 0x2d59, 0x4839, { 0x8e, 0x14, 0xb6, 0xd8, 0x7b, 0x99, 0x8, 0x8c } };
		// {95C51C3D-AFE8-417C-A6C6-64A66CA69494}
		static const GUID guid_main_gaptracks11_toggle = { 0x95c51c3d, 0xafe8, 0x417c, { 0xa6, 0xc6, 0x64, 0xa6, 0x6c, 0xa6, 0x94, 0x94 } };
		// {7A843788-FA3E-47B2-B669-13EE9DD8E4CE}
		static const GUID guid_main_gaptracks12_toggle = { 0x7a843788, 0xfa3e, 0x47b2, { 0xb6, 0x69, 0x13, 0xee, 0x9d, 0xd8, 0xe4, 0xce } };
		// {F20061CA-036D-43A3-A3E9-D19BC67B1EEF}
		static const GUID guid_main_gaptracks13_toggle = { 0xf20061ca, 0x36d, 0x43a3, { 0xa3, 0xe9, 0xd1, 0x9b, 0xc6, 0x7b, 0x1e, 0xef } };
		// {8E2F0D57-058A-4EBA-972F-B40C525F8662}
		static const GUID guid_main_gaptracks14_toggle = { 0x8e2f0d57, 0x58a, 0x4eba, { 0x97, 0x2f, 0xb4, 0xc, 0x52, 0x5f, 0x86, 0x62 } };
		// {A46EFB81-36EA-47DA-AE62-3F2866888D9C}
		static const GUID guid_main_gaptracks15_toggle = { 0xa46efb81, 0x36ea, 0x47da, { 0xae, 0x62, 0x3f, 0x28, 0x66, 0x88, 0x8d, 0x9c } };
		// {BD8241D5-B52B-48CA-AF0C-084A0D3645E9}
		static const GUID guid_main_gaptracks16_toggle = { 0xbd8241d5, 0xb52b, 0x48ca, { 0xaf, 0xc, 0x8, 0x4a, 0xd, 0x36, 0x45, 0xe9 } };
		// {318034A0-6611-4CDE-AF23-385D1B55DFA4}
		static const GUID guid_main_gaptracks17_toggle = { 0x318034a0, 0x6611, 0x4cde, { 0xaf, 0x23, 0x38, 0x5d, 0x1b, 0x55, 0xdf, 0xa4 } };
		// {5DAFE08D-288D-40F5-B846-EBE18A0C3284}
		static const GUID guid_main_gaptracks18_toggle = { 0x5dafe08d, 0x288d, 0x40f5, { 0xb8, 0x46, 0xeb, 0xe1, 0x8a, 0xc, 0x32, 0x84 } };
		// {1B8DCA75-E3CB-4E71-8458-6E58C5FEF4BC}
		static const GUID guid_main_gaptracks19_toggle = { 0x1b8dca75, 0xe3cb, 0x4e71, { 0x84, 0x58, 0x6e, 0x58, 0xc5, 0xfe, 0xf4, 0xbc } };
		// {9DDF86D6-369E-4C1F-82AD-166CE0D0BAED}
		static const GUID guid_main_gaptracks20_toggle = { 0x9ddf86d6, 0x369e, 0x4c1f, { 0x82, 0xad, 0x16, 0x6c, 0xe0, 0xd0, 0xba, 0xed } };



		if (p_index == 0)
			return guid_main_gaptracks1_toggle;
		if (p_index == 1)
			return guid_main_gaptracks2_toggle;
		if (p_index == 2)
			return guid_main_gaptracks3_toggle;
		if (p_index == 3)
			return guid_main_gaptracks4_toggle;
		if (p_index == 4)
			return guid_main_gaptracks5_toggle;
		if (p_index == 5)
			return guid_main_gaptracks6_toggle;
		if (p_index == 6)
			return guid_main_gaptracks7_toggle;
		if (p_index == 7)
			return guid_main_gaptracks8_toggle;
		if (p_index == 8)
			return guid_main_gaptracks9_toggle;
		if (p_index == 9)
			return guid_main_gaptracks10_toggle;
		if (p_index == 10)
			return guid_main_gaptracks11_toggle;
		if (p_index == 11)
			return guid_main_gaptracks12_toggle;
		if (p_index == 12)
			return guid_main_gaptracks13_toggle;
		if (p_index == 13)
			return guid_main_gaptracks14_toggle;
		if (p_index == 14)
			return guid_main_gaptracks15_toggle;
		if (p_index == 15)
			return guid_main_gaptracks16_toggle;
		if (p_index == 16)
			return guid_main_gaptracks17_toggle;
		if (p_index == 17)
			return guid_main_gaptracks18_toggle;
		if (p_index == 18)
			return guid_main_gaptracks19_toggle;
		/*if (p_index == 19)
			return guid_main_gaptracks20_toggle;
		*/
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "0.5s";
		if (p_index == 1)
			p_out = "1s";
		if (p_index == 2)
			p_out = "1.5s";
		if (p_index == 3)
			p_out = "2s";
		if (p_index == 4)
			p_out = "2.5s";
		if (p_index == 5)
			p_out = "3s";
		if (p_index == 6)
			p_out = "4s";
		if (p_index == 7)
			p_out = "5s";
		if (p_index == 8)
			p_out = "6s";
		if (p_index == 9)
			p_out = "12s";
		if (p_index == 10)
			p_out = "18s";
		if (p_index == 11)
			p_out = "24s";
		if (p_index == 12)
			p_out = "30s";
		if (p_index == 13)
			p_out = "1min";
		if (p_index == 14)
			p_out = "1.5min";
		if (p_index == 15)
			p_out = "2min";
		if (p_index == 16)
			p_out = "3min";
		if (p_index == 17)
			p_out = "6min";
		if (p_index == 18)
			p_out = "Gap# sec";
		/*if (p_index == 19)
			p_out = "Track length";
		*/
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "0.5 seconds gap between tracks.";
		else if (p_index == 1)
			p_out = "1 seonds gap between tracks.";
		else if (p_index == 2)
			p_out = "1.5 seconds gap between tracks.";
		else if (p_index == 3)
			p_out = "2 seconds gap between tracks.";
		else if (p_index == 4)
			p_out = "2.5 seconds gap between tracks.";
		else if (p_index == 5)
			p_out = "3 seconds gap between tracks.";
		else if (p_index == 6)
			p_out = "4 seconds gap between tracks.";
		else if (p_index == 7)
			p_out = "5 seconds gap between tracks.";
		else if (p_index == 8)
			p_out = "6 seconds gap between tracks.";
		else if (p_index == 9)
			p_out = "12 seconds gap between tracks.";
		else if (p_index == 10)
			p_out = "18 seconds gap between tracks.";
		else if (p_index == 11)
			p_out = "24 seconds gap between tracks.";
		else if (p_index == 12)
			p_out = "30 seconds gap between tracks.";
		else if (p_index == 13)
			p_out = "1 minutes gap between tracks.";
		else if (p_index == 14)
			p_out = "1.5 minutes gap between tracks.";
		else if (p_index == 15)
			p_out = "2 minutes gap between tracks.";
		else if (p_index == 16)
			p_out = "3 minutes gap between tracks.";
		else if (p_index == 17)
			p_out = "6 minutes gap between tracks.";
		else if (p_index == 18)
			p_out = "# seconds gap between tracks.";
		/*else if (p_index == 19)
			p_out = "Track length gap between tracks.";
		*/
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_gaptracks;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		option4::set_option(1);
		option4::set_option(2);
		option::set_option(10);
		option::set_option(7); //stop
		option2::set_option(4);
		static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks1_enabled = !cfg_menu_gaptracks1_enabled;
			if (cfg_menu_gaptracks1_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks1_enabled = true;
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 500;
				option::set_option(10);
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 0.5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks2_enabled = !cfg_menu_gaptracks2_enabled;
			if (cfg_menu_gaptracks2_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks2_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 1000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 1s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks3_enabled = !cfg_menu_gaptracks3_enabled;
			if (cfg_menu_gaptracks3_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks3_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 1500;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 1.5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks4_enabled = !cfg_menu_gaptracks4_enabled;
			if (cfg_menu_gaptracks4_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks4_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 2000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 2s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks5_enabled = !cfg_menu_gaptracks5_enabled;
			if (cfg_menu_gaptracks5_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks5_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 2500;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 2.5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks6_enabled = !cfg_menu_gaptracks6_enabled;
			if (cfg_menu_gaptracks6_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks6_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 3000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 3s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks7_enabled = !cfg_menu_gaptracks7_enabled;
			if (cfg_menu_gaptracks7_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks7_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 4000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 4s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks8_enabled = !cfg_menu_gaptracks8_enabled;
			if (cfg_menu_gaptracks8_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks8_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 5000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks9_enabled = !cfg_menu_gaptracks9_enabled;
			if (cfg_menu_gaptracks9_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks9_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 6000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 6s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks10_enabled = !cfg_menu_gaptracks10_enabled;
			if (cfg_menu_gaptracks10_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks10_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 12000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 12s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 10 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks11_enabled = !cfg_menu_gaptracks11_enabled;
			if (cfg_menu_gaptracks11_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks11_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 18000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 18");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 11 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks12_enabled = !cfg_menu_gaptracks12_enabled;
			if (cfg_menu_gaptracks12_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks12_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 24000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 24s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 12 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks13_enabled = !cfg_menu_gaptracks13_enabled;
			if (cfg_menu_gaptracks13_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks13_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 30000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 30s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 13 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks14_enabled = !cfg_menu_gaptracks14_enabled;
			if (cfg_menu_gaptracks14_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks14_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 60000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 1min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 14 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks15_enabled = !cfg_menu_gaptracks15_enabled;
			if (cfg_menu_gaptracks15_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks15_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 90000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 1.5min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 15 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks16_enabled = !cfg_menu_gaptracks16_enabled;
			if (cfg_menu_gaptracks16_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks16_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 120000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 2min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 16 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks17_enabled = !cfg_menu_gaptracks17_enabled;
			if (cfg_menu_gaptracks17_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks17_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 180000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 3min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 17 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks18_enabled = !cfg_menu_gaptracks18_enabled;
			if (cfg_menu_gaptracks18_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks18_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				gap_msec = 360000;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by 6min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		if (p_index == 18 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks19_enabled = !cfg_menu_gaptracks19_enabled;
			if (cfg_menu_gaptracks19_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks19_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by #");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}
		/*if (p_index == 19 && core_api::assert_main_thread())
		{
			cfg_menu_gaptracks20_enabled = !cfg_menu_gaptracks20_enabled;
			if (cfg_menu_gaptracks20_enabled)
			{
				option2::set_option(3);
				cfg_menu_gaptracks20_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				track2 = 1;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Gap tracks by track length");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(3);
			}
		}*/
		option2::set_option(1);
		option2::set_option(5);
		option2::set_option(6);
		cfg_reverse_enabled = false;
		cfg_menu_reverse_enabled = false;
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_gaptracks1_enabled;
		if (p_index == 1)
			return cfg_menu_gaptracks2_enabled;
		if (p_index == 2)
			return cfg_menu_gaptracks3_enabled;
		if (p_index == 3)
			return cfg_menu_gaptracks4_enabled;
		if (p_index == 4)
			return cfg_menu_gaptracks5_enabled;
		if (p_index == 5)
			return cfg_menu_gaptracks6_enabled;
		if (p_index == 6)
			return cfg_menu_gaptracks7_enabled;
		if (p_index == 7)
			return cfg_menu_gaptracks8_enabled;
		if (p_index == 8)
			return cfg_menu_gaptracks9_enabled;
		if (p_index == 9)
			return cfg_menu_gaptracks10_enabled;
		if (p_index == 10)
			return cfg_menu_gaptracks11_enabled;
		if (p_index == 11)
			return cfg_menu_gaptracks12_enabled;
		if (p_index == 12)
			return cfg_menu_gaptracks13_enabled;
		if (p_index == 13)
			return cfg_menu_gaptracks14_enabled;
		if (p_index == 14)
			return cfg_menu_gaptracks15_enabled;
		if (p_index == 15)
			return cfg_menu_gaptracks16_enabled;
		if (p_index == 16)
			return cfg_menu_gaptracks17_enabled;
		if (p_index == 17)
			return cfg_menu_gaptracks18_enabled;
		if (p_index == 18)
			return cfg_menu_gaptracks19_enabled;
		/*if (p_index == 19)
			return cfg_menu_gaptracks20_enabled;
			*/
		return false;
	}
};

static mainmenu_group_popup_factory mainmenu_group12(guid_cfg_menu_gaptracks,
        guid_cfg_menu_control, mainmenu_commands::sort_priority_base,
        "Gap tracks");

static mainmenu_commands_factory_t<mainmenu_commands_gaptracks> g_mainmenu_commands_gaptracks;


// {549C6243-1B9B-4A6E-8533-36E20FD9B085}
static const GUID guid_cfg_menu_gapalbums = { 0x549c6243, 0x1b9b, 0x4a6e, { 0x85, 0x33, 0x36, 0xe2, 0xf, 0xd9, 0xb0, 0x85 } };

class mainmenu_commands_gapalbums : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		//return 20;
		return 19;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {AEBB7954-7B24-4113-9198-7EA98E6AEB6F}
		static const GUID guid_main_gapalbums1_toggle = { 0xaebb7954, 0x7b24, 0x4113, { 0x91, 0x98, 0x7e, 0xa9, 0x8e, 0x6a, 0xeb, 0x6f } };
		// {41F41AE9-DE28-427F-94B2-EA3DB6784651}
		static const GUID guid_main_gapalbums2_toggle = { 0x41f41ae9, 0xde28, 0x427f, { 0x94, 0xb2, 0xea, 0x3d, 0xb6, 0x78, 0x46, 0x51 } };
		// {B720974A-D35D-4BA0-9B49-82D8B59D6680}
		static const GUID guid_main_gapalbums3_toggle = { 0xb720974a, 0xd35d, 0x4ba0, { 0x9b, 0x49, 0x82, 0xd8, 0xb5, 0x9d, 0x66, 0x80 } };
		// {2B05BF0A-17A4-4F15-A353-F137F76F4C16}
		static const GUID guid_main_gapalbums4_toggle = { 0x2b05bf0a, 0x17a4, 0x4f15, { 0xa3, 0x53, 0xf1, 0x37, 0xf7, 0x6f, 0x4c, 0x16 } };
		// {9D8C7A38-9DB9-45B4-A729-C59818434F58}
		static const GUID guid_main_gapalbums5_toggle = { 0x9d8c7a38, 0x9db9, 0x45b4, { 0xa7, 0x29, 0xc5, 0x98, 0x18, 0x43, 0x4f, 0x58 } };
		// {821A5B87-4780-4C49-8C34-7C5C64E592A9}
		static const GUID guid_main_gapalbums6_toggle = { 0x821a5b87, 0x4780, 0x4c49, { 0x8c, 0x34, 0x7c, 0x5c, 0x64, 0xe5, 0x92, 0xa9 } };
		// {4389511A-B26D-4A05-8281-C59977CB65F0}
		static const GUID guid_main_gapalbums7_toggle = { 0x4389511a, 0xb26d, 0x4a05, { 0x82, 0x81, 0xc5, 0x99, 0x77, 0xcb, 0x65, 0xf0 } };
		// {F511D723-3EBE-45A9-AEBB-C16C297120F0}
		static const GUID guid_main_gapalbums8_toggle = { 0xf511d723, 0x3ebe, 0x45a9, { 0xae, 0xbb, 0xc1, 0x6c, 0x29, 0x71, 0x20, 0xf0 } };
		// {23BB8E12-A8FB-4704-9320-F8BF7F487CE4}
		static const GUID guid_main_gapalbums9_toggle = { 0x23bb8e12, 0xa8fb, 0x4704, { 0x93, 0x20, 0xf8, 0xbf, 0x7f, 0x48, 0x7c, 0xe4 } };
		// {CECDB6FD-78C4-4979-93D5-18244BA2B3BE}
		static const GUID guid_main_gapalbums10_toggle = { 0xcecdb6fd, 0x78c4, 0x4979, { 0x93, 0xd5, 0x18, 0x24, 0x4b, 0xa2, 0xb3, 0xbe } };
		// {0A607181-0FD0-4C52-86F6-DA68E896D0DC}
		static const GUID guid_main_gapalbums11_toggle = { 0xa607181, 0xfd0, 0x4c52, { 0x86, 0xf6, 0xda, 0x68, 0xe8, 0x96, 0xd0, 0xdc } };
		// {46F254AB-EB17-4227-B32A-0F5F49B28A19}
		static const GUID guid_main_gapalbums12_toggle = { 0x46f254ab, 0xeb17, 0x4227, { 0xb3, 0x2a, 0xf, 0x5f, 0x49, 0xb2, 0x8a, 0x19 } };
		// {185D9FFB-B58D-43EF-967F-B39DE2371ED4}
		static const GUID guid_main_gapalbums13_toggle = { 0x185d9ffb, 0xb58d, 0x43ef, { 0x96, 0x7f, 0xb3, 0x9d, 0xe2, 0x37, 0x1e, 0xd4 } };
		// {DB2292CD-6AF2-421B-AFB1-82DE98340B0F}
		static const GUID guid_main_gapalbums14_toggle = { 0xdb2292cd, 0x6af2, 0x421b, { 0xaf, 0xb1, 0x82, 0xde, 0x98, 0x34, 0xb, 0xf } };
		// {859860D5-E0F4-4996-A39B-13923BE2A9A9}
		static const GUID guid_main_gapalbums15_toggle = { 0x859860d5, 0xe0f4, 0x4996, { 0xa3, 0x9b, 0x13, 0x92, 0x3b, 0xe2, 0xa9, 0xa9 } };
		// {171E0310-766C-4EC7-88A7-C6F1C335C813}
		static const GUID guid_main_gapalbums16_toggle = { 0x171e0310, 0x766c, 0x4ec7, { 0x88, 0xa7, 0xc6, 0xf1, 0xc3, 0x35, 0xc8, 0x13 } };
		// {9F0364A9-C527-4AF1-A8D5-7E69AE3A32AF}
		static const GUID guid_main_gapalbums17_toggle = { 0x9f0364a9, 0xc527, 0x4af1, { 0xa8, 0xd5, 0x7e, 0x69, 0xae, 0x3a, 0x32, 0xaf } };
		// {C68E4E75-DDCC-4A4A-AD85-C5BC1FFB3194}
		static const GUID guid_main_gapalbums18_toggle = { 0xc68e4e75, 0xddcc, 0x4a4a, { 0xad, 0x85, 0xc5, 0xbc, 0x1f, 0xfb, 0x31, 0x94 } };
		// {EA5E4AE9-B110-45A4-BB78-DB56D6F6F29A}
		static const GUID guid_main_gapalbums19_toggle = { 0xea5e4ae9, 0xb110, 0x45a4, { 0xbb, 0x78, 0xdb, 0x56, 0xd6, 0xf6, 0xf2, 0x9a } };
		// {9E85EE3A-D4CA-4DBD-A423-5182BCF48AB1}
		static const GUID guid_main_gapalbums20_toggle = { 0x9e85ee3a, 0xd4ca, 0x4dbd, { 0xa4, 0x23, 0x51, 0x82, 0xbc, 0xf4, 0x8a, 0xb1 } };


		if (p_index == 0)
			return guid_main_gapalbums1_toggle;
		if (p_index == 1)
			return guid_main_gapalbums2_toggle;
		if (p_index == 2)
			return guid_main_gapalbums3_toggle;
		if (p_index == 3)
			return guid_main_gapalbums4_toggle;
		if (p_index == 4)
			return guid_main_gapalbums5_toggle;
		if (p_index == 5)
			return guid_main_gapalbums6_toggle;
		if (p_index == 6)
			return guid_main_gapalbums7_toggle;
		if (p_index == 7)
			return guid_main_gapalbums8_toggle;
		if (p_index == 8)
			return guid_main_gapalbums9_toggle;
		if (p_index == 9)
			return guid_main_gapalbums10_toggle;
		if (p_index == 10)
			return guid_main_gapalbums11_toggle;
		if (p_index == 11)
			return guid_main_gapalbums12_toggle;
		if (p_index == 12)
			return guid_main_gapalbums13_toggle;
		if (p_index == 13)
			return guid_main_gapalbums14_toggle;
		if (p_index == 14)
			return guid_main_gapalbums15_toggle;
		if (p_index == 15)
			return guid_main_gapalbums16_toggle;
		if (p_index == 16)
			return guid_main_gapalbums17_toggle;
		if (p_index == 17)
			return guid_main_gapalbums18_toggle;
		if (p_index == 18)
			return guid_main_gapalbums19_toggle;
		/*if (p_index == 19)
			return guid_main_gapalbums20_toggle;
		*/
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "0.5s";
		if (p_index == 1)
			p_out = "1s";
		if (p_index == 2)
			p_out = "1.5s";
		if (p_index == 3)
			p_out = "2s";
		if (p_index == 4)
			p_out = "2.5s";
		if (p_index == 5)
			p_out = "3s";
		if (p_index == 6)
			p_out = "4s";
		if (p_index == 7)
			p_out = "5s";
		if (p_index == 8)
			p_out = "6s";
		if (p_index == 9)
			p_out = "12s";
		if (p_index == 10)
			p_out = "18s";
		if (p_index == 11)
			p_out = "24s";
		if (p_index == 12)
			p_out = "30s";
		if (p_index == 13)
			p_out = "1min";
		if (p_index == 14)
			p_out = "1.5min";
		if (p_index == 15)
			p_out = "2min";
		if (p_index == 16)
			p_out = "3min";
		if (p_index == 17)
			p_out = "6min";
		if (p_index == 18)
			p_out = "Gap# sec";
		/*if (p_index == 19)
			p_out = "Track length";
		*/
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "0.5 seconds gap between albums.";
		else if (p_index == 1)
			p_out = "1 seonds gap between albums.";
		else if (p_index == 2)
			p_out = "1.5 seconds gap between albums.";
		else if (p_index == 3)
			p_out = "2 seconds gap between albums.";
		else if (p_index == 4)
			p_out = "2.5 seconds gap between albums.";
		else if (p_index == 5)
			p_out = "3 seconds gap between albums.";
		else if (p_index == 6)
			p_out = "4 seconds gap between albums.";
		else if (p_index == 7)
			p_out = "5 seconds gap between albums.";
		else if (p_index == 8)
			p_out = "6 seconds gap between albums.";
		else if (p_index == 9)
			p_out = "12 seconds gap between albums.";
		else if (p_index == 10)
			p_out = "18 seconds gap between albums.";
		else if (p_index == 11)
			p_out = "24 seconds gap between albums.";
		else if (p_index == 12)
			p_out = "30 seconds gap between albums.";
		else if (p_index == 13)
			p_out = "1 minutes gap between albums.";
		else if (p_index == 14)
			p_out = "1.5 minutes gap between albums.";
		else if (p_index == 15)
			p_out = "2 minutes gap between albums.";
		else if (p_index == 16)
			p_out = "3 minutes gap between albums.";
		else if (p_index == 17)
			p_out = "6 minutes gap between albums.";
		else if (p_index == 18)
			p_out = "# seconds gap between albums.";
		/*else if (p_index == 19)
			p_out = "Track length gap between albums.";
		*/
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_gapalbums;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		option4::set_option(1);
		option4::set_option(2);
		option::set_option(10);
		option::set_option(7); //stop
		option2::set_option(3);
		static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums1_enabled = !cfg_menu_gapalbums1_enabled;
			if (cfg_menu_gapalbums1_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums1_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 500;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 0.5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums2_enabled = !cfg_menu_gapalbums2_enabled;
			if (cfg_menu_gapalbums2_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums2_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 1000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 1s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums3_enabled = !cfg_menu_gapalbums3_enabled;
			if (cfg_menu_gapalbums3_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums3_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 1500;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 1.5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums4_enabled = !cfg_menu_gapalbums4_enabled;
			if (cfg_menu_gapalbums4_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums4_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 2000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 2s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums5_enabled = !cfg_menu_gapalbums5_enabled;
			if (cfg_menu_gapalbums5_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums5_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 2500;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 2.5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums6_enabled = !cfg_menu_gapalbums6_enabled;
			if (cfg_menu_gapalbums6_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums6_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 3000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 3s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums7_enabled = !cfg_menu_gapalbums7_enabled;
			if (cfg_menu_gapalbums7_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums7_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 4000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 4s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums8_enabled = !cfg_menu_gapalbums8_enabled;
			if (cfg_menu_gapalbums8_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums8_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 5000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 5s");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums9_enabled = !cfg_menu_gapalbums9_enabled;
			if (cfg_menu_gapalbums9_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums9_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 6000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 6sec");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums10_enabled = !cfg_menu_gapalbums10_enabled;
			if (cfg_menu_gapalbums10_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums10_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 12000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 12sec");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 10 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums11_enabled = !cfg_menu_gapalbums11_enabled;
			if (cfg_menu_gapalbums11_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums11_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 18000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 18sec");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 11 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums12_enabled = !cfg_menu_gapalbums12_enabled;
			if (cfg_menu_gapalbums12_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums12_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 24000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 24sec");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 12 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums13_enabled = !cfg_menu_gapalbums13_enabled;
			if (cfg_menu_gapalbums13_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums13_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 30000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 30sec");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 13 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums14_enabled = !cfg_menu_gapalbums14_enabled;
			if (cfg_menu_gapalbums14_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums14_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 60000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 1min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 14 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums15_enabled = !cfg_menu_gapalbums15_enabled;
			if (cfg_menu_gapalbums15_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums15_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 90000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 1.5min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 15 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums16_enabled = !cfg_menu_gapalbums16_enabled;
			if (cfg_menu_gapalbums16_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums16_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 120000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 2min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 16 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums17_enabled = !cfg_menu_gapalbums17_enabled;
			if (cfg_menu_gapalbums17_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums17_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 180000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 3min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 17 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums18_enabled = !cfg_menu_gapalbums18_enabled;
			if (cfg_menu_gapalbums18_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums18_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				gap_msec = 360000;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by 6min");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		if (p_index == 18 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums19_enabled = !cfg_menu_gapalbums19_enabled;
			if (cfg_menu_gapalbums19_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums19_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by #");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		/*if (p_index == 19 && core_api::assert_main_thread())
		{
			cfg_menu_gapalbums20_enabled = !cfg_menu_gapalbums20_enabled;
			if (cfg_menu_gapalbums20_enabled)
			{
				option2::set_option(4);
				cfg_menu_gapalbums20_enabled = true;
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				cfg_album_enabled = true;
				album2 = 1;
				cfg_randomalbum_enabled = false;
				cfg_gap_enabled = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				console::info("Gap albums by track length");
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
				option::set_option(7);
				option2::set_option(4);
			}
		}
		*/
		option2::set_option(1);
		option2::set_option(5);
		option2::set_option(6);
		cfg_reverse_enabled = false;
		cfg_menu_reverse_enabled = false;
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_gapalbums1_enabled;
		if (p_index == 1)
			return cfg_menu_gapalbums2_enabled;
		if (p_index == 2)
			return cfg_menu_gapalbums3_enabled;
		if (p_index == 3)
			return cfg_menu_gapalbums4_enabled;
		if (p_index == 4)
			return cfg_menu_gapalbums5_enabled;
		if (p_index == 5)
			return cfg_menu_gapalbums6_enabled;
		if (p_index == 6)
			return cfg_menu_gapalbums7_enabled;
		if (p_index == 7)
			return cfg_menu_gapalbums8_enabled;
		if (p_index == 8)
			return cfg_menu_gapalbums9_enabled;
		if (p_index == 9)
			return cfg_menu_gapalbums10_enabled;
		if (p_index == 10)
			return cfg_menu_gapalbums11_enabled;
		if (p_index == 11)
			return cfg_menu_gapalbums12_enabled;
		if (p_index == 12)
			return cfg_menu_gapalbums13_enabled;
		if (p_index == 13)
			return cfg_menu_gapalbums14_enabled;
		if (p_index == 14)
			return cfg_menu_gapalbums15_enabled;
		if (p_index == 15)
			return cfg_menu_gapalbums16_enabled;
		if (p_index == 16)
			return cfg_menu_gapalbums17_enabled;
		if (p_index == 17)
			return cfg_menu_gapalbums18_enabled;
		if (p_index == 18)
			return cfg_menu_gapalbums19_enabled;
		/*if (p_index == 19)
			return cfg_menu_gapalbums20_enabled;
		*/
		return false;
	}
};

static mainmenu_group_popup_factory mainmenu_group13(guid_cfg_menu_gapalbums,
        guid_cfg_menu_control, mainmenu_commands::sort_priority_dontcare,
        "Gap albums");

static mainmenu_commands_factory_t<mainmenu_commands_gapalbums> g_mainmenu_commands_gapalbums;


class mainmenu_commands_reverse : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 5;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{

		// {D73565AC-953C-4949-BA1C-37EFAF346BC2}
		static const GUID guid_main_reverse_toggle = { 0xd73565ac, 0x953c, 0x4949, { 0xba, 0x1c, 0x37, 0xef, 0xaf, 0x34, 0x6b, 0xc2 } };
		// {BD8E17A5-1F94-4F74-9061-E60327C8FD4B}
		static const GUID guid_main_previousplaylistfirst_toggle = { 0xbd8e17a5, 0x1f94, 0x4f74, { 0x90, 0x61, 0xe6, 0x3, 0x27, 0xc8, 0xfd, 0x4b } };
		// {B80222DA-FCC0-41CF-80C5-B01F21C27400}
		static const GUID guid_main_nextplaylistfirst_toggle = { 0xb80222da, 0xfcc0, 0x41cf, { 0x80, 0xc5, 0xb0, 0x1f, 0x21, 0xc2, 0x74, 0x0 } };
		// {09497CCA-6AAF-48B0-91E9-4F19BF3B1F54}
		static const GUID guid_main_repeatplaylist_toggle = { 0x9497cca, 0x6aaf, 0x48b0, { 0x91, 0xe9, 0x4f, 0x19, 0xbf, 0x3b, 0x1f, 0x54 } };
		// {62443405-BF16-4438-A1C3-99D04357843F}
		static const GUID guid_main_postgap_toggle = { 0x62443405, 0xbf16, 0x4438, { 0xa1, 0xc3, 0x99, 0xd0, 0x43, 0x57, 0x84, 0x3f } };



		if (p_index == 0)
			return guid_main_reverse_toggle;
		if (p_index == 1)
			return guid_main_previousplaylistfirst_toggle;
		if (p_index == 2)
			return guid_main_nextplaylistfirst_toggle;
		if (p_index == 3)
			return guid_main_repeatplaylist_toggle;
		if (p_index == 4)
			return guid_main_postgap_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Reverse";
		if (p_index == 1)
			p_out = "Previous playlist";
		if (p_index == 2)
			p_out = "Next playlist";
		if (p_index == 3)
			p_out = "Repeat playlist once";
		if (p_index == 4)
			p_out = "Postgap";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Playback previous track.";
		else if (p_index == 1)
			p_out = "Playback first track of previous playlist after playlist end.";
		else if (p_index == 2)
			p_out = "Playback first track of next playlist after playlist end.";
		else if (p_index == 3)
			p_out = "Playback first track of current playlist after playlist end only once. Permanent: use playback order 'Repeat (playlist)'.";
		else if (p_index == 4)
			p_out = "Add a pause after the track in seconds (x.xx) defined by tag %postgap%.";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_control;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		option2::set_option(3);
		option2::set_option(4);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_reverse_enabled = !cfg_menu_reverse_enabled;
			if (cfg_menu_reverse_enabled)
			{
				option4::set_option(1);
				option4::set_option(2);
				option::set_option(10);
				cfg_menu_reverse_enabled = true;
				cfg_track_enabled = true;
				cfg_reverse_enabled = true;
				console::info("Reverse");
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				option4::set_option(2);
			}

			option::set_option(7); //stop
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_previousplaylistfirst_enabled = !cfg_menu_previousplaylistfirst_enabled;
			if (cfg_menu_previousplaylistfirst_enabled)
			{
				option4::set_option(1);
				option4::set_option(2);
				option::set_option(10);
				cfg_menu_previousplaylistfirst_enabled = true;
				cfg_previousplaylistfirst_enabled = true;
				cfg_menu_repeatplaylist_enabled = false;
				cfg_repeatplaylist_enabled = false;
				console::info("Previous playlist");
			}
			else
			{
				option4::set_option(2);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_nextplaylistfirst_enabled = !cfg_menu_nextplaylistfirst_enabled;
			if (cfg_menu_nextplaylistfirst_enabled)
			{
				option4::set_option(1);
				option4::set_option(2);
				option::set_option(10);
				cfg_menu_nextplaylistfirst_enabled = true;
				cfg_nextplaylistfirst_enabled = true;
				cfg_menu_repeatplaylist_enabled = false;
				cfg_repeatplaylist_enabled = false;
				console::info("Next playlist");
			}
			else
			{
				option4::set_option(2);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_repeatplaylist_enabled = !cfg_menu_repeatplaylist_enabled;
			if (cfg_menu_repeatplaylist_enabled)
			{
				option4::set_option(1);
				option4::set_option(2);
				option::set_option(10);
				cfg_menu_repeatplaylist_enabled = true;
				cfg_repeatplaylist_enabled = true;
				cfg_menu_nextplaylistfirst_enabled = false;
				cfg_nextplaylistfirst_enabled = false;
				console::info("Repeat playlist once");
			}
			else
			{
				option4::set_option(2);
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_postgap_enabled = !cfg_menu_postgap_enabled;
			if (cfg_menu_postgap_enabled)
			{
				option4::set_option(1);
				option4::set_option(2);
				option::set_option(10);
				cfg_menu_postgap_enabled = true;
				if (postgap2 > 0)
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
				track2 = 1;
				cfg_track_enabled = true;
				cfg_gap_enabled = true;
				console::info("Postgap");
			}
			else
			{
				option::set_option(10);
				static_api_ptr_t<playback_control>()->set_stop_after_current(false);
			}
		}
		option2::set_option(1);
		option2::set_option(5);
		option2::set_option(6);
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_reverse_enabled;
		if (p_index == 1)
			return cfg_menu_previousplaylistfirst_enabled;
		if (p_index == 2)
			return cfg_menu_nextplaylistfirst_enabled;
		if (p_index == 3)
			return cfg_menu_repeatplaylist_enabled;
		if (p_index == 4)
			return cfg_menu_postgap_enabled;
		return false;
	}
};

static mainmenu_commands_factory_t<mainmenu_commands_reverse> g_mainmenu_commands_reverse;


// {4C72D8A8-E987-466F-AD8A-0070C6D6182F}
static const GUID guid_cfg_menu_stopafteralbums = { 0x4c72d8a8, 0xe987, 0x466f, { 0xad, 0x8a, 0x0, 0x70, 0xc6, 0xd6, 0x18, 0x2f } };

class mainmenu_commands_stopafteralbums : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 10;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{

		// {3648CFC1-07A1-48F8-9333-4B70D5B7F356}
		static const GUID guid_main_stopafteralbums1_toggle = { 0x3648cfc1, 0x7a1, 0x48f8, { 0x93, 0x33, 0x4b, 0x70, 0xd5, 0xb7, 0xf3, 0x56 } };
		// {16AC2803-2754-4966-8D8D-2C8DF5358F08}
		static const GUID guid_main_stopafteralbums2_toggle = { 0x16ac2803, 0x2754, 0x4966, { 0x8d, 0x8d, 0x2c, 0x8d, 0xf5, 0x35, 0x8f, 0x8 } };
		// {EEA91162-91CE-4358-9C1C-D8A7C2A11980}
		static const GUID guid_main_stopafteralbums3_toggle = { 0xeea91162, 0x91ce, 0x4358, { 0x9c, 0x1c, 0xd8, 0xa7, 0xc2, 0xa1, 0x19, 0x80 } };
		// {A0686CB8-926A-4DBE-B081-D230472F1143}
		static const GUID guid_main_stopafteralbums4_toggle = { 0xa0686cb8, 0x926a, 0x4dbe, { 0xb0, 0x81, 0xd2, 0x30, 0x47, 0x2f, 0x11, 0x43 } };
		// {15057498-ABAC-47F8-ACB0-F8A65093ED34}
		static const GUID guid_main_stopafteralbums5_toggle = { 0x15057498, 0xabac, 0x47f8, { 0xac, 0xb0, 0xf8, 0xa6, 0x50, 0x93, 0xed, 0x34 } };
		// {D5562A37-AC49-4E86-B5E6-E298C5AFA006}
		static const GUID guid_main_stopafteralbums6_toggle = { 0xd5562a37, 0xac49, 0x4e86, { 0xb5, 0xe6, 0xe2, 0x98, 0xc5, 0xaf, 0xa0, 0x6 } };
		// {630DBF5F-2CB3-414E-A85E-48126111B7BD}
		static const GUID guid_main_stopafteralbums7_toggle = { 0x630dbf5f, 0x2cb3, 0x414e, { 0xa8, 0x5e, 0x48, 0x12, 0x61, 0x11, 0xb7, 0xbd } };
		// {8244D303-6877-4B26-AE84-1F2B5B2C1B00}
		static const GUID guid_main_stopafteralbums8_toggle = { 0x8244d303, 0x6877, 0x4b26, { 0xae, 0x84, 0x1f, 0x2b, 0x5b, 0x2c, 0x1b, 0x0 } };
		// {AC3ED9C3-4C6A-40D5-9158-B8ACB824FCA4}
		static const GUID guid_main_stopafteralbums9_toggle = { 0xac3ed9c3, 0x4c6a, 0x40d5, { 0x91, 0x58, 0xb8, 0xac, 0xb8, 0x24, 0xfc, 0xa4 } };
		// {7C6F9180-2B4F-4BE4-900A-5042A7A35BAC}
		static const GUID guid_main_stopafteralbums10_toggle = { 0x7c6f9180, 0x2b4f, 0x4be4, { 0x90, 0xa, 0x50, 0x42, 0xa7, 0xa3, 0x5b, 0xac } };


		if (p_index == 0)
			return guid_main_stopafteralbums1_toggle;
		if (p_index == 1)
			return guid_main_stopafteralbums2_toggle;
		if (p_index == 2)
			return guid_main_stopafteralbums3_toggle;
		if (p_index == 3)
			return guid_main_stopafteralbums4_toggle;
		if (p_index == 4)
			return guid_main_stopafteralbums5_toggle;
		if (p_index == 5)
			return guid_main_stopafteralbums6_toggle;
		if (p_index == 6)
			return guid_main_stopafteralbums7_toggle;
		if (p_index == 7)
			return guid_main_stopafteralbums8_toggle;
		if (p_index == 8)
			return guid_main_stopafteralbums9_toggle;
		if (p_index == 9)
			return guid_main_stopafteralbums10_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "1";
		if (p_index == 1)
			p_out = "2";
		if (p_index == 2)
			p_out = "3";
		if (p_index == 3)
			p_out = "4";
		if (p_index == 4)
			p_out = "5";
		if (p_index == 5)
			p_out = "6";
		if (p_index == 6)
			p_out = "7";
		if (p_index == 7)
			p_out = "8";
		if (p_index == 8)
			p_out = "9";
		if (p_index == 9)
			p_out = "10";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Stop after 1 album.";
		else if (p_index == 1)
			p_out = "Stop after 2 albums.";
		else if (p_index == 2)
			p_out = "Stop after 3 albums.";
		else if (p_index == 3)
			p_out = "Stop after 4 albums..";
		else if (p_index == 4)
			p_out = "Stop after 5 albums.";
		else if (p_index == 5)
			p_out = "Stop after 6 albums.";
		else if (p_index == 6)
			p_out = "Stop after 7 albums.";
		else if (p_index == 7)
			p_out = "Stop after 8 albums.";
		else if (p_index == 8)
			p_out = "Stop after 9 albums.";
		else if (p_index == 9)
			p_out = "Stop after 10 albums.";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_stopafteralbums;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		option4::set_option(1);
		option4::set_option(2);
		option2::set_option(3);
		option2::set_option(4);
		option::set_option(7); //stop
		static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums1_enabled = !cfg_menu_stopafteralbums1_enabled;
			if (cfg_menu_stopafteralbums1_enabled)
			{
				album2 = 1;
				option2::set_option(6);
				cfg_menu_stopafteralbums1_enabled = true;
				cfg_only_stop_once_album = true;
				if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				}
			}
			else option4::set_option(2);
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums2_enabled = !cfg_menu_stopafteralbums2_enabled;
			if (cfg_menu_stopafteralbums2_enabled)
			{
				album2 = 2;
				option2::set_option(6);
				cfg_menu_stopafteralbums2_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums3_enabled = !cfg_menu_stopafteralbums3_enabled;
			if (cfg_menu_stopafteralbums3_enabled)
			{
				album2 = 3;
				option2::set_option(6);
				cfg_menu_stopafteralbums3_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums4_enabled = !cfg_menu_stopafteralbums4_enabled;
			if (cfg_menu_stopafteralbums4_enabled)
			{
				album2 = 4;
				option2::set_option(6);
				cfg_menu_stopafteralbums4_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums5_enabled = !cfg_menu_stopafteralbums5_enabled;
			if (cfg_menu_stopafteralbums5_enabled)
			{
				album2 = 5;
				option2::set_option(6);
				cfg_menu_stopafteralbums5_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums6_enabled = !cfg_menu_stopafteralbums6_enabled;
			if (cfg_menu_stopafteralbums6_enabled)
			{
				album2 = 6;
				option2::set_option(6);
				cfg_menu_stopafteralbums6_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums7_enabled = !cfg_menu_stopafteralbums7_enabled;
			if (cfg_menu_stopafteralbums7_enabled)
			{
				album2 = 7;
				option2::set_option(6);
				cfg_menu_stopafteralbums7_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums8_enabled = !cfg_menu_stopafteralbums8_enabled;
			if (cfg_menu_stopafteralbums8_enabled)
			{
				album2 = 8;
				option2::set_option(6);
				cfg_menu_stopafteralbums8_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums9_enabled = !cfg_menu_stopafteralbums9_enabled;
			if (cfg_menu_stopafteralbums9_enabled)
			{
				album2 = 9;
				option2::set_option(6);
				cfg_menu_stopafteralbums9_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			cfg_menu_stopafteralbums10_enabled = !cfg_menu_stopafteralbums10_enabled;
			if (cfg_menu_stopafteralbums10_enabled)
			{
				album2 = 10;
				option2::set_option(6);
				cfg_menu_stopafteralbums10_enabled = true;
				cfg_only_stop_once_album = true;
			}
			else option4::set_option(2);
		}
		option4::set_option(1);
		option2::set_option(5);
		option2::set_option(1);
		cfg_reverse_enabled = false;
		cfg_menu_reverse_enabled = false;
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_stopafteralbums1_enabled;
		if (p_index == 1)
			return cfg_menu_stopafteralbums2_enabled;
		if (p_index == 2)
			return cfg_menu_stopafteralbums3_enabled;
		if (p_index == 3)
			return cfg_menu_stopafteralbums4_enabled;
		if (p_index == 4)
			return cfg_menu_stopafteralbums5_enabled;
		if (p_index == 5)
			return cfg_menu_stopafteralbums6_enabled;
		if (p_index == 6)
			return cfg_menu_stopafteralbums7_enabled;
		if (p_index == 7)
			return cfg_menu_stopafteralbums8_enabled;
		if (p_index == 8)
			return cfg_menu_stopafteralbums9_enabled;
		if (p_index == 9)
			return cfg_menu_stopafteralbums10_enabled;
		return false;
	}
};

static mainmenu_group_popup_factory mainmenu_group4(guid_cfg_menu_stopafteralbums,
        guid_cfg_menu_control, mainmenu_commands::sort_priority_dontcare,
        "Stop after albums once");

static mainmenu_commands_factory_t<mainmenu_commands_stopafteralbums> g_mainmenu_commands_stopafteralbums;



// {CB08DDFB-7EA7-4EEE-B04B-C8EFD928E135}
static const GUID guid_cfg_menu_stopaftertracks = { 0xcb08ddfb, 0x7ea7, 0x4eee, { 0xb0, 0x4b, 0xc8, 0xef, 0xd9, 0x28, 0xe1, 0x35 } };

class mainmenu_commands_stopaftertracks : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 20;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{

		// {8486EF20-841D-4AE2-BCF7-A38AE2525B1E}
		static const GUID guid_main_stopaftertracks1_toggle = { 0x8486ef20, 0x841d, 0x4ae2, { 0xbc, 0xf7, 0xa3, 0x8a, 0xe2, 0x52, 0x5b, 0x1e } };
		// {3EDF42DE-37C8-4212-84E3-81308C7C7F65}
		static const GUID guid_main_stopaftertracks2_toggle = { 0x3edf42de, 0x37c8, 0x4212, { 0x84, 0xe3, 0x81, 0x30, 0x8c, 0x7c, 0x7f, 0x65 } };
		// {988D1255-DEC6-4842-BE5A-B02E88EA5114}
		static const GUID guid_main_stopaftertracks3_toggle = { 0x988d1255, 0xdec6, 0x4842, { 0xbe, 0x5a, 0xb0, 0x2e, 0x88, 0xea, 0x51, 0x14 } };
		// {FEE816A4-7F61-4513-BC37-9E7846B5439B}
		static const GUID guid_main_stopaftertracks4_toggle = { 0xfee816a4, 0x7f61, 0x4513, { 0xbc, 0x37, 0x9e, 0x78, 0x46, 0xb5, 0x43, 0x9b } };
		// {F2B3C1AB-7681-4883-B157-54294600B519}
		static const GUID guid_main_stopaftertracks5_toggle = { 0xf2b3c1ab, 0x7681, 0x4883, { 0xb1, 0x57, 0x54, 0x29, 0x46, 0x0, 0xb5, 0x19 } };
		// {22F09188-3C0E-46A6-8ED4-D5743E16962B}
		static const GUID guid_main_stopaftertracks6_toggle = { 0x22f09188, 0x3c0e, 0x46a6, { 0x8e, 0xd4, 0xd5, 0x74, 0x3e, 0x16, 0x96, 0x2b } };
		// {F366C38D-7D38-4F6E-B6E7-377967DE20A9}
		static const GUID guid_main_stopaftertracks7_toggle = { 0xf366c38d, 0x7d38, 0x4f6e, { 0xb6, 0xe7, 0x37, 0x79, 0x67, 0xde, 0x20, 0xa9 } };
		// {E6D8AD94-FF9D-49CA-9A7F-51410E127538}
		static const GUID guid_main_stopaftertracks8_toggle = { 0xe6d8ad94, 0xff9d, 0x49ca, { 0x9a, 0x7f, 0x51, 0x41, 0xe, 0x12, 0x75, 0x38 } };
		// {16112F05-4619-4956-AB2D-959C5DE1A544}
		static const GUID guid_main_stopaftertracks9_toggle = { 0x16112f05, 0x4619, 0x4956, { 0xab, 0x2d, 0x95, 0x9c, 0x5d, 0xe1, 0xa5, 0x44 } };
		// {097BB510-E520-4255-AFE2-2203FD6B6F6C}
		static const GUID guid_main_stopaftertracks10_toggle = { 0x97bb510, 0xe520, 0x4255, { 0xaf, 0xe2, 0x22, 0x3, 0xfd, 0x6b, 0x6f, 0x6c } };
		// {4B408A96-DE1F-419D-826A-EAB1DEECA709}
		static const GUID guid_main_stopaftertracks11_toggle = { 0x4b408a96, 0xde1f, 0x419d, { 0x82, 0x6a, 0xea, 0xb1, 0xde, 0xec, 0xa7, 0x9 } };
		// {5837A69D-1B5B-46A3-AF9F-97C386D3D5E4}
		static const GUID guid_main_stopaftertracks12_toggle = { 0x5837a69d, 0x1b5b, 0x46a3, { 0xaf, 0x9f, 0x97, 0xc3, 0x86, 0xd3, 0xd5, 0xe4 } };
		// {6892F6B7-ACCC-4949-A907-1B8BFE0E14E1}
		static const GUID guid_main_stopaftertracks13_toggle = { 0x6892f6b7, 0xaccc, 0x4949, { 0xa9, 0x7, 0x1b, 0x8b, 0xfe, 0xe, 0x14, 0xe1 } };
		// {D4B15724-6940-4DC6-A4AF-BF2ABD1CFB94}
		static const GUID guid_main_stopaftertracks14_toggle = { 0xd4b15724, 0x6940, 0x4dc6, { 0xa4, 0xaf, 0xbf, 0x2a, 0xbd, 0x1c, 0xfb, 0x94 } };
		// {C229CF64-3787-45AA-BAC5-C6C3A14EEC70}
		static const GUID guid_main_stopaftertracks15_toggle = { 0xc229cf64, 0x3787, 0x45aa, { 0xba, 0xc5, 0xc6, 0xc3, 0xa1, 0x4e, 0xec, 0x70 } };
		// {0E13AF7B-2DB1-4A2F-A196-A4F43F64FC5F}
		static const GUID guid_main_stopaftertracks16_toggle = { 0xe13af7b, 0x2db1, 0x4a2f, { 0xa1, 0x96, 0xa4, 0xf4, 0x3f, 0x64, 0xfc, 0x5f } };
		// {18AE0AD8-8124-4A91-8F5B-6084D35ED590}
		static const GUID guid_main_stopaftertracks17_toggle = { 0x18ae0ad8, 0x8124, 0x4a91, { 0x8f, 0x5b, 0x60, 0x84, 0xd3, 0x5e, 0xd5, 0x90 } };
		// {0EA4D145-67F7-448D-9864-CE2D2D4CA9E0}
		static const GUID guid_main_stopaftertracks18_toggle = { 0xea4d145, 0x67f7, 0x448d, { 0x98, 0x64, 0xce, 0x2d, 0x2d, 0x4c, 0xa9, 0xe0 } };
		// {FCD93044-7364-4A93-9B9A-D961BC198936}
		static const GUID guid_main_stopaftertracks19_toggle = { 0xfcd93044, 0x7364, 0x4a93, { 0x9b, 0x9a, 0xd9, 0x61, 0xbc, 0x19, 0x89, 0x36 } };
		// {6743FF06-F5E0-47D7-B782-C0EE85C1CCD1}
		static const GUID guid_main_stopaftertracks20_toggle = { 0x6743ff06, 0xf5e0, 0x47d7, { 0xb7, 0x82, 0xc0, 0xee, 0x85, 0xc1, 0xcc, 0xd1 } };


		if (p_index == 0)
			return guid_main_stopaftertracks1_toggle;
		if (p_index == 1)
			return guid_main_stopaftertracks2_toggle;
		if (p_index == 2)
			return guid_main_stopaftertracks3_toggle;
		if (p_index == 3)
			return guid_main_stopaftertracks4_toggle;
		if (p_index == 4)
			return guid_main_stopaftertracks5_toggle;
		if (p_index == 5)
			return guid_main_stopaftertracks6_toggle;
		if (p_index == 6)
			return guid_main_stopaftertracks7_toggle;
		if (p_index == 7)
			return guid_main_stopaftertracks8_toggle;
		if (p_index == 8)
			return guid_main_stopaftertracks9_toggle;
		if (p_index == 9)
			return guid_main_stopaftertracks10_toggle;
		if (p_index == 10)
			return guid_main_stopaftertracks11_toggle;
		if (p_index == 11)
			return guid_main_stopaftertracks12_toggle;
		if (p_index == 12)
			return guid_main_stopaftertracks13_toggle;
		if (p_index == 13)
			return guid_main_stopaftertracks14_toggle;
		if (p_index == 14)
			return guid_main_stopaftertracks15_toggle;
		if (p_index == 15)
			return guid_main_stopaftertracks16_toggle;
		if (p_index == 16)
			return guid_main_stopaftertracks17_toggle;
		if (p_index == 17)
			return guid_main_stopaftertracks18_toggle;
		if (p_index == 18)
			return guid_main_stopaftertracks19_toggle;
		if (p_index == 19)
			return guid_main_stopaftertracks20_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "1";
		if (p_index == 1)
			p_out = "2";
		if (p_index == 2)
			p_out = "3";
		if (p_index == 3)
			p_out = "4";
		if (p_index == 4)
			p_out = "5";
		if (p_index == 5)
			p_out = "6";
		if (p_index == 6)
			p_out = "7";
		if (p_index == 7)
			p_out = "8";
		if (p_index == 8)
			p_out = "9";
		if (p_index == 9)
			p_out = "10";
		if (p_index == 10)
			p_out = "11";
		if (p_index == 11)
			p_out = "12";
		if (p_index == 12)
			p_out = "13";
		if (p_index == 13)
			p_out = "14";
		if (p_index == 14)
			p_out = "15";
		if (p_index == 15)
			p_out = "16";
		if (p_index == 16)
			p_out = "17";
		if (p_index == 17)
			p_out = "18";
		if (p_index == 18)
			p_out = "19";
		if (p_index == 19)
			p_out = "20";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Stop after 1 track.";
		else if (p_index == 1)
			p_out = "Stop after 2 tracks.";
		else if (p_index == 2)
			p_out = "Stop after 3 tracks.";
		else if (p_index == 3)
			p_out = "Stop after 4 tracks.";
		else if (p_index == 4)
			p_out = "Stop after 5 tracks.";
		else if (p_index == 5)
			p_out = "Stop after 6 tracks.";
		else if (p_index == 6)
			p_out = "Stop after 7 tracks.";
		else if (p_index == 7)
			p_out = "Stop after 8 tracks.";
		else if (p_index == 8)
			p_out = "Stop after 9 tracks.";
		else if (p_index == 9)
			p_out = "Stop after 10 tracks.";
		else if (p_index == 10)
			p_out = "Stop after 11 track.";
		else if (p_index == 11)
			p_out = "Stop after 12 tracks.";
		else if (p_index == 12)
			p_out = "Stop after 13 tracks.";
		else if (p_index == 13)
			p_out = "Stop after 14 tracks.";
		else if (p_index == 14)
			p_out = "Stop after 15 tracks.";
		else if (p_index == 15)
			p_out = "Stop after 16 tracks.";
		else if (p_index == 16)
			p_out = "Stop after 17 tracks.";
		else if (p_index == 17)
			p_out = "Stop after 18 tracks.";
		else if (p_index == 18)
			p_out = "Stop after 19 tracks.";
		else if (p_index == 19)
			p_out = "Stop after 20 tracks.";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_stopaftertracks;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		option4::set_option(1);
		option4::set_option(2);
		option2::set_option(3);
		option2::set_option(4);
		option::set_option(10);
		option::set_option(7); //stop
		static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks1_enabled = !cfg_menu_stopaftertracks1_enabled;
			if (cfg_menu_stopaftertracks1_enabled)
			{
				track2 = 1;
				option2::set_option(5);
				cfg_menu_stopaftertracks1_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks2_enabled = !cfg_menu_stopaftertracks2_enabled;
			if (cfg_menu_stopaftertracks2_enabled)
			{
				track2 = 2;
				option2::set_option(5);
				cfg_menu_stopaftertracks2_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks3_enabled = !cfg_menu_stopaftertracks3_enabled;
			if (cfg_menu_stopaftertracks3_enabled)
			{
				track2 = 3;
				option2::set_option(5);
				cfg_menu_stopaftertracks3_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks4_enabled = !cfg_menu_stopaftertracks4_enabled;
			if (cfg_menu_stopaftertracks4_enabled)
			{
				track2 = 4;
				option2::set_option(5);
				cfg_menu_stopaftertracks4_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks5_enabled = !cfg_menu_stopaftertracks5_enabled;
			if (cfg_menu_stopaftertracks5_enabled)
			{
				track2 = 5;
				option2::set_option(5);
				cfg_menu_stopaftertracks5_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks6_enabled = !cfg_menu_stopaftertracks6_enabled;
			if (cfg_menu_stopaftertracks6_enabled)
			{
				track2 = 6;
				option2::set_option(5);
				cfg_menu_stopaftertracks6_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks7_enabled = !cfg_menu_stopaftertracks7_enabled;
			if (cfg_menu_stopaftertracks7_enabled)
			{
				track2 = 7;
				option2::set_option(5);
				cfg_menu_stopaftertracks7_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks8_enabled = !cfg_menu_stopaftertracks8_enabled;
			if (cfg_menu_stopaftertracks8_enabled)
			{
				track2 = 8;
				option2::set_option(5);
				cfg_menu_stopaftertracks8_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks9_enabled = !cfg_menu_stopaftertracks9_enabled;
			if (cfg_menu_stopaftertracks9_enabled)
			{
				track2 = 9;
				option2::set_option(5);
				cfg_menu_stopaftertracks9_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks10_enabled = !cfg_menu_stopaftertracks10_enabled;
			if (cfg_menu_stopaftertracks10_enabled)
			{
				track2 = 10;
				option2::set_option(5);
				cfg_menu_stopaftertracks10_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 10 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks11_enabled = !cfg_menu_stopaftertracks11_enabled;
			if (cfg_menu_stopaftertracks11_enabled)
			{
				track2 = 11;
				option2::set_option(5);
				cfg_menu_stopaftertracks11_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 11 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks12_enabled = !cfg_menu_stopaftertracks12_enabled;
			if (cfg_menu_stopaftertracks12_enabled)
			{
				track2 = 12;
				option2::set_option(5);
				cfg_menu_stopaftertracks12_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 12 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks13_enabled = !cfg_menu_stopaftertracks13_enabled;
			if (cfg_menu_stopaftertracks13_enabled)
			{
				track2 = 13;
				option2::set_option(5);
				cfg_menu_stopaftertracks13_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 13 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks14_enabled = !cfg_menu_stopaftertracks14_enabled;
			if (cfg_menu_stopaftertracks14_enabled)
			{
				track2 = 14;
				option2::set_option(5);
				cfg_menu_stopaftertracks14_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 14 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks15_enabled = !cfg_menu_stopaftertracks15_enabled;
			if (cfg_menu_stopaftertracks15_enabled)
			{
				track2 = 15;
				option2::set_option(5);
				cfg_menu_stopaftertracks15_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 15 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks16_enabled = !cfg_menu_stopaftertracks16_enabled;
			if (cfg_menu_stopaftertracks16_enabled)
			{
				track2 = 16;
				option2::set_option(5);
				cfg_menu_stopaftertracks16_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 16 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks17_enabled = !cfg_menu_stopaftertracks17_enabled;
			if (cfg_menu_stopaftertracks17_enabled)
			{
				track2 = 17;
				option2::set_option(5);
				cfg_menu_stopaftertracks17_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 17 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks18_enabled = !cfg_menu_stopaftertracks18_enabled;
			if (cfg_menu_stopaftertracks18_enabled)
			{
				track2 = 18;
				option2::set_option(5);
				cfg_menu_stopaftertracks18_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 18 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks19_enabled = !cfg_menu_stopaftertracks19_enabled;
			if (cfg_menu_stopaftertracks19_enabled)
			{
				track2 = 19;
				option2::set_option(5);
				cfg_menu_stopaftertracks19_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		if (p_index == 19 && core_api::assert_main_thread())
		{
			cfg_menu_stopaftertracks20_enabled = !cfg_menu_stopaftertracks20_enabled;
			if (cfg_menu_stopaftertracks20_enabled)
			{
				track2 = 20;
				option2::set_option(5);
				cfg_menu_stopaftertracks20_enabled = true;
				cfg_only_stop_once_track = true;
			}
			else option4::set_option(2);
		}
		option4::set_option(1);
		option2::set_option(6);
		cfg_reverse_enabled = false;
		cfg_menu_reverse_enabled = false;
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_stopaftertracks1_enabled;
		if (p_index == 1)
			return cfg_menu_stopaftertracks2_enabled;
		if (p_index == 2)
			return cfg_menu_stopaftertracks3_enabled;
		if (p_index == 3)
			return cfg_menu_stopaftertracks4_enabled;
		if (p_index == 4)
			return cfg_menu_stopaftertracks5_enabled;
		if (p_index == 5)
			return cfg_menu_stopaftertracks6_enabled;
		if (p_index == 6)
			return cfg_menu_stopaftertracks7_enabled;
		if (p_index == 7)
			return cfg_menu_stopaftertracks8_enabled;
		if (p_index == 8)
			return cfg_menu_stopaftertracks9_enabled;
		if (p_index == 9)
			return cfg_menu_stopaftertracks10_enabled;
		if (p_index == 10)
			return cfg_menu_stopaftertracks11_enabled;
		if (p_index == 11)
			return cfg_menu_stopaftertracks12_enabled;
		if (p_index == 12)
			return cfg_menu_stopaftertracks13_enabled;
		if (p_index == 13)
			return cfg_menu_stopaftertracks14_enabled;
		if (p_index == 14)
			return cfg_menu_stopaftertracks15_enabled;
		if (p_index == 15)
			return cfg_menu_stopaftertracks16_enabled;
		if (p_index == 16)
			return cfg_menu_stopaftertracks17_enabled;
		if (p_index == 17)
			return cfg_menu_stopaftertracks18_enabled;
		if (p_index == 18)
			return cfg_menu_stopaftertracks19_enabled;
		if (p_index == 19)
			return cfg_menu_stopaftertracks20_enabled;
		return false;
	}
};

static mainmenu_group_popup_factory mainmenu_group2(guid_cfg_menu_stopaftertracks,
        guid_cfg_menu_control, mainmenu_commands::sort_priority_dontcare,
        "Stop after tracks once");

static mainmenu_commands_factory_t<mainmenu_commands_stopaftertracks> g_mainmenu_commands_stopaftertracks;


// {FDF0A0B0-E7E9-4DC5-8558-5F9BF90B7232}
static const GUID guid_cfg_menu_timebomb = { 0xfdf0a0b0, 0xe7e9, 0x4dc5, { 0x85, 0x58, 0x5f, 0x9b, 0xf9, 0xb, 0x72, 0x32 } };

class mainmenu_commands_timebomb : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 12;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {0ECA36EF-3A13-4A67-ADD8-1F7A752B46E1}
		static const GUID guid_main_timebomb1_toggle = { 0xeca36ef, 0x3a13, 0x4a67, { 0xad, 0xd8, 0x1f, 0x7a, 0x75, 0x2b, 0x46, 0xe1 } };
		// {5F8C2455-7EF2-4BAE-8C68-B6419A152487}
		static const GUID guid_main_timebomb2_toggle = { 0x5f8c2455, 0x7ef2, 0x4bae, { 0x8c, 0x68, 0xb6, 0x41, 0x9a, 0x15, 0x24, 0x87 } };
		// {75B9ADC3-8441-4B33-80CA-A3299D3DCF77}
		static const GUID guid_main_timebomb3_toggle = { 0x75b9adc3, 0x8441, 0x4b33, { 0x80, 0xca, 0xa3, 0x29, 0x9d, 0x3d, 0xcf, 0x77 } };
		// {AD0C0D0B-AA51-421B-B029-A0041319A54A}
		static const GUID guid_main_timebomb4_toggle = { 0xad0c0d0b, 0xaa51, 0x421b, { 0xb0, 0x29, 0xa0, 0x4, 0x13, 0x19, 0xa5, 0x4a } };
		// {55D0FC65-07B4-4D17-BDC3-81A54E0A462D}
		static const GUID guid_main_timebomb5_toggle = { 0x55d0fc65, 0x7b4, 0x4d17, { 0xbd, 0xc3, 0x81, 0xa5, 0x4e, 0xa, 0x46, 0x2d } };
		// {0BA2156B-0E98-41BC-B928-AE037926526F}
		static const GUID guid_main_timebomb6_toggle = { 0xba2156b, 0xe98, 0x41bc, { 0xb9, 0x28, 0xae, 0x3, 0x79, 0x26, 0x52, 0x6f } };
		// {19B26A7D-F346-48C0-A428-218E6F44199E}
		static const GUID guid_main_timebomb7_toggle = { 0x19b26a7d, 0xf346, 0x48c0, { 0xa4, 0x28, 0x21, 0x8e, 0x6f, 0x44, 0x19, 0x9e } };
		// {B59F606E-C4C5-4165-BC83-D9B35CC7E9D2}
		static const GUID guid_main_timebomb8_toggle = { 0xb59f606e, 0xc4c5, 0x4165, { 0xbc, 0x83, 0xd9, 0xb3, 0x5c, 0xc7, 0xe9, 0xd2 } };
		// {4ABD14C9-FEB4-482B-B7B9-EEA73E9281DA}
		static const GUID guid_main_timebomb9_toggle = { 0x4abd14c9, 0xfeb4, 0x482b, { 0xb7, 0xb9, 0xee, 0xa7, 0x3e, 0x92, 0x81, 0xda } };
		// {8F8C5BB7-91D2-44DF-B3D6-398D72D9FBAE}
		static const GUID guid_main_timebomb10_toggle = { 0x8f8c5bb7, 0x91d2, 0x44df, { 0xb3, 0xd6, 0x39, 0x8d, 0x72, 0xd9, 0xfb, 0xae } };
		// {1DEABE4F-F2F1-4452-A6CB-0CA1FC10848C}
		static const GUID guid_main_timebomb11_toggle = { 0x1deabe4f, 0xf2f1, 0x4452, { 0xa6, 0xcb, 0xc, 0xa1, 0xfc, 0x10, 0x84, 0x8c } };
		// {1CB748A6-F4EC-43A0-A161-FD86892CD0E4}
		static const GUID guid_main_timebombabort_toggle = { 0x1cb748a6, 0xf4ec, 0x43a0, { 0xa1, 0x61, 0xfd, 0x86, 0x89, 0x2c, 0xd0, 0xe4 } };


		if (p_index == 0)
			return guid_main_timebomb1_toggle;
		if (p_index == 1)
			return guid_main_timebomb2_toggle;
		if (p_index == 2)
			return guid_main_timebomb3_toggle;
		if (p_index == 3)
			return guid_main_timebomb4_toggle;
		if (p_index == 4)
			return guid_main_timebomb5_toggle;
		if (p_index == 5)
			return guid_main_timebomb6_toggle;
		if (p_index == 6)
			return guid_main_timebomb7_toggle;
		if (p_index == 7)
			return guid_main_timebomb8_toggle;
		if (p_index == 8)
			return guid_main_timebomb9_toggle;
		if (p_index == 9)
			return guid_main_timebomb10_toggle;
		if (p_index == 10)
			return guid_main_timebomb11_toggle;
		if (p_index == 11)
			return guid_main_timebombabort_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "0.5h";
		if (p_index == 1)
			p_out = "1h";
		if (p_index == 2)
			p_out = "1.5h";
		if (p_index == 3)
			p_out = "2h";
		if (p_index == 4)
			p_out = "2.5h";
		if (p_index == 5)
			p_out = "3h";
		if (p_index == 6)
			p_out = "3.5h";
		if (p_index == 7)
			p_out = "4h";
		if (p_index == 8)
			p_out = "4.5h";
		if (p_index == 9)
			p_out = "5h";
		if (p_index == 10)
			p_out = "Timebomb# min";
		if (p_index == 11)
			p_out = "Abort";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Stop playback after 0.5h. Start playback to burn fuse.";
		else if (p_index == 1)
			p_out = "Stop playback after 1h. Start playback to burn fuse.";
		else if (p_index == 2)
			p_out = "Stop playback after 1.5h. Start playback to burn fuse.";
		else if (p_index == 3)
			p_out = "Stop playback after 2h. Start playback to burn fuse.";
		else if (p_index == 4)
			p_out = "Stop playback after 2.5h. Start playback to burn fuse.";
		else if (p_index == 5)
			p_out = "Stop playback after 3h. Start playback to burn fuse.";
		else if (p_index == 6)
			p_out = "Stop playback after 3.5h. Start playback to burn fuse.";
		else if (p_index == 7)
			p_out = "Stop playback after 4h. Start playback to burn fuse.";
		else if (p_index == 8)
			p_out = "Stop playback after 4.5h. Start playback to burn fuse.";
		else if (p_index == 9)
			p_out = "Stop playback after 5h. Start playback to burn fuse.";
		else if (p_index == 10)
			p_out = "Stop playback after Timebomb# minutes. Start playback to burn fuse.";
		else if (p_index == 11)
			p_out = "Abort stop playback. ";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_timebomb;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb1_enabled = !cfg_menu_timebomb1_enabled;
			timebomb_min2 = 30;
			//timebomb_min2 = 1;
			if (cfg_menu_timebomb1_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb1_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb2_enabled = !cfg_menu_timebomb2_enabled;
			timebomb_min2 = 60;
			//timebomb_min2 = 2;
			if (cfg_menu_timebomb2_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb2_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb3_enabled = !cfg_menu_timebomb3_enabled;
			timebomb_min2 = 90;
			//timebomb_min2 = 3;
			if (cfg_menu_timebomb3_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb3_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb4_enabled = !cfg_menu_timebomb4_enabled;
			timebomb_min2 = 120;
			//timebomb_min2 = 4;
			if (cfg_menu_timebomb4_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb4_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb5_enabled = !cfg_menu_timebomb5_enabled;
			timebomb_min2 = 150;
			//timebomb_min2 = 5;
			if (cfg_menu_timebomb5_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb5_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb6_enabled = !cfg_menu_timebomb6_enabled;
			timebomb_min2 = 180;
			//timebomb_min2 = 6;
			if (cfg_menu_timebomb6_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb6_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb7_enabled = !cfg_menu_timebomb7_enabled;
			timebomb_min2 = 210;
			//timebomb_min2 = 7;
			if (cfg_menu_timebomb7_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb7_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb8_enabled = !cfg_menu_timebomb8_enabled;
			timebomb_min2 = 240;
			//timebomb_min2 = 8;
			if (cfg_menu_timebomb8_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb8_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb9_enabled = !cfg_menu_timebomb9_enabled;
			timebomb_min2 = 270;
			//timebomb_min2 = 9;
			if (cfg_menu_timebomb9_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb9_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb10_enabled = !cfg_menu_timebomb10_enabled;
			timebomb_min2 = 300;
			//timebomb_min2 = 10;
			if (cfg_menu_timebomb10_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb10_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 10 && core_api::assert_main_thread())
		{
			cfg_menu_timebomb11_enabled = !cfg_menu_timebomb11_enabled;
			cfg_timebomb.get(timebomb_min);
			timebomb_min2 = atoi(timebomb_min);
			if (cfg_menu_timebomb11_enabled)
			{
				cfg_timebomb_suddendeath_enabled = true;
				option2::set_option(1);
				cfg_menu_timebomb11_enabled = true;
				console::info("Timebomb: Start playback to burn fuse");
			}
			else cfg_timebomb_suddendeath_enabled = false;
		}
		if (p_index == 11 && core_api::assert_main_thread())
		{
			cfg_menu_timebombabort_enabled = !cfg_menu_timebombabort_enabled;
			console::info("Timebomb aborted");
			option2::set_option(1);
			cfg_tracknumber_enabled = false;
			cfg_only_stop_once_tracknumber = false;
			cfg_menu_timebombabort_enabled = false;
			KillTimer(NULL, ptr11);
			KillTimer(NULL, ptr12);
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_timebomb1_enabled;
		if (p_index == 1)
			return cfg_menu_timebomb2_enabled;
		if (p_index == 2)
			return cfg_menu_timebomb3_enabled;
		if (p_index == 3)
			return cfg_menu_timebomb4_enabled;
		if (p_index == 4)
			return cfg_menu_timebomb5_enabled;
		if (p_index == 5)
			return cfg_menu_timebomb6_enabled;
		if (p_index == 6)
			return cfg_menu_timebomb7_enabled;
		if (p_index == 7)
			return cfg_menu_timebomb8_enabled;
		if (p_index == 8)
			return cfg_menu_timebomb9_enabled;
		if (p_index == 9)
			return cfg_menu_timebomb10_enabled;
		if (p_index == 10)
			return cfg_menu_timebomb11_enabled;
		if (p_index == 11)
			return cfg_menu_timebombabort_enabled;
		return false;
	}
};


static mainmenu_group_popup_factory mainmenu_group3(guid_cfg_menu_timebomb,
        guid_cfg_menu_control, mainmenu_commands::sort_priority_last,
        "Timebomb");

static mainmenu_commands_factory_t<mainmenu_commands_timebomb> g_mainmenu_commands_timebomb;


//alarm
VOID CALLBACK Alarm(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent10,     // timer identifier
    DWORD dwTime)     // current system time
{
	static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
	pfc::string8 al_message;
	cfg_timebomb_message.get(al_message);
	if (cfg_alarm_message_enabled)
	{
		popup_message::g_show(al_message, "Alarm");
	}
	console::info("Alarm started");
	KillTimer(NULL, idEvent10);
	option2::set_option(2);
}

// {D1FC4F8B-CFEA-4B2A-9739-F0CD4930AB40}
static const GUID guid_cfg_menu_alarm = { 0xd1fc4f8b, 0xcfea, 0x4b2a, { 0x97, 0x39, 0xf0, 0xcd, 0x49, 0x30, 0xab, 0x40 } };

class mainmenu_commands_alarm : public mainmenu_commands
{

public:

	// Return the number of commands we provide.
	virtual t_uint32 get_command_count()
	{
		return 22;
	}

	// All commands are identified by a GUID.
	virtual GUID get_command(t_uint32 p_index)
	{
		// {9370EA04-77D0-4B3E-93AB-63A7D8126F40}
		static const GUID guid_main_alarm1_toggle = { 0x9370ea04, 0x77d0, 0x4b3e, { 0x93, 0xab, 0x63, 0xa7, 0xd8, 0x12, 0x6f, 0x40 } };
		// {9678DF9E-0F78-466C-8EB0-76F90B137EAE}
		static const GUID guid_main_alarm2_toggle = { 0x9678df9e, 0xf78, 0x466c, { 0x8e, 0xb0, 0x76, 0xf9, 0xb, 0x13, 0x7e, 0xae } };
		// {9FD2C9AF-4573-4ECF-B7E1-98131FE953EF}
		static const GUID guid_main_alarm3_toggle = { 0x9fd2c9af, 0x4573, 0x4ecf, { 0xb7, 0xe1, 0x98, 0x13, 0x1f, 0xe9, 0x53, 0xef } };
		// {F1CB0308-D195-4575-9154-1E2542D76EAE}
		static const GUID guid_main_alarm4_toggle = { 0xf1cb0308, 0xd195, 0x4575, { 0x91, 0x54, 0x1e, 0x25, 0x42, 0xd7, 0x6e, 0xae } };
		// {6C4736A3-9716-4B82-BBD6-FA2E796BA437}
		static const GUID guid_main_alarm5_toggle = { 0x6c4736a3, 0x9716, 0x4b82, { 0xbb, 0xd6, 0xfa, 0x2e, 0x79, 0x6b, 0xa4, 0x37 } };
		// {ECAAD2D9-79D1-473B-A4CA-5F58C35E0BF4}
		static const GUID guid_main_alarm6_toggle = { 0xecaad2d9, 0x79d1, 0x473b, { 0xa4, 0xca, 0x5f, 0x58, 0xc3, 0x5e, 0xb, 0xf4 } };
		// {2BF23CC1-76F1-4ADB-B44F-DA4584665F9A}
		static const GUID guid_main_alarm7_toggle = { 0x2bf23cc1, 0x76f1, 0x4adb, { 0xb4, 0x4f, 0xda, 0x45, 0x84, 0x66, 0x5f, 0x9a } };
		// {70C3BC8B-555F-4BD0-8BCD-731756287F07}
		static const GUID guid_main_alarm8_toggle = { 0x70c3bc8b, 0x555f, 0x4bd0, { 0x8b, 0xcd, 0x73, 0x17, 0x56, 0x28, 0x7f, 0x7 } };
		// {02C7940F-B69F-441C-8101-9118E4E396A7}
		static const GUID guid_main_alarm9_toggle = { 0x2c7940f, 0xb69f, 0x441c, { 0x81, 0x1, 0x91, 0x18, 0xe4, 0xe3, 0x96, 0xa7 } };
		// {F437DF6F-8A47-4011-9D4D-BE394EE11283}
		static const GUID guid_main_alarm10_toggle = { 0xf437df6f, 0x8a47, 0x4011, { 0x9d, 0x4d, 0xbe, 0x39, 0x4e, 0xe1, 0x12, 0x83 } };
		// {E2E6D1E9-98CC-4A4F-8587-8DDBF28D7F70}
		static const GUID guid_main_alarm11_toggle = { 0xe2e6d1e9, 0x98cc, 0x4a4f, { 0x85, 0x87, 0x8d, 0xdb, 0xf2, 0x8d, 0x7f, 0x70 } };
		// {1D07B0B5-E1EE-4F53-A707-969425EA885F}
		static const GUID guid_main_alarm12_toggle = { 0x1d07b0b5, 0xe1ee, 0x4f53, { 0xa7, 0x7, 0x96, 0x94, 0x25, 0xea, 0x88, 0x5f } };
		// {29F40317-272A-43E2-B6C6-42202AB52939}
		static const GUID guid_main_alarm13_toggle = { 0x29f40317, 0x272a, 0x43e2, { 0xb6, 0xc6, 0x42, 0x20, 0x2a, 0xb5, 0x29, 0x39 } };
		// {91C9EEEF-3176-4913-9B92-B5197823D2DB}
		static const GUID guid_main_alarm14_toggle = { 0x91c9eeef, 0x3176, 0x4913, { 0x9b, 0x92, 0xb5, 0x19, 0x78, 0x23, 0xd2, 0xdb } };
		// {ECE12587-0667-499E-9BEB-A28470B750C9}
		static const GUID guid_main_alarm15_toggle = { 0xece12587, 0x667, 0x499e, { 0x9b, 0xeb, 0xa2, 0x84, 0x70, 0xb7, 0x50, 0xc9 } };
		// {33A2AF4E-126E-40A2-A3C8-33F84F3990FB}
		static const GUID guid_main_alarm16_toggle = { 0x33a2af4e, 0x126e, 0x40a2, { 0xa3, 0xc8, 0x33, 0xf8, 0x4f, 0x39, 0x90, 0xfb } };
		// {0C0BB9D2-1B87-4B61-85F3-2845ACFC8D86}
		static const GUID guid_main_alarm17_toggle = { 0xc0bb9d2, 0x1b87, 0x4b61, { 0x85, 0xf3, 0x28, 0x45, 0xac, 0xfc, 0x8d, 0x86 } };
		// {D8AABEA3-E8E2-4A71-BF42-2BF0656F7447}
		static const GUID guid_main_alarm18_toggle = { 0xd8aabea3, 0xe8e2, 0x4a71, { 0xbf, 0x42, 0x2b, 0xf0, 0x65, 0x6f, 0x74, 0x47 } };
		// {D39A9E33-6457-497B-8226-CC07FB1BB752}
		static const GUID guid_main_alarm19_toggle = { 0xd39a9e33, 0x6457, 0x497b, { 0x82, 0x26, 0xcc, 0x7, 0xfb, 0x1b, 0xb7, 0x52 } };
		// {85A95B47-0898-438A-9108-96A0A6C403BC}
		static const GUID guid_main_alarm20_toggle = { 0x85a95b47, 0x898, 0x438a, { 0x91, 0x8, 0x96, 0xa0, 0xa6, 0xc4, 0x3, 0xbc } };
		// {B493C545-8395-4887-BD63-5E01C97ECFFC}
		static const GUID guid_main_alarm21_toggle = { 0xb493c545, 0x8395, 0x4887, { 0xbd, 0x63, 0x5e, 0x1, 0xc9, 0x7e, 0xcf, 0xfc } };
		// {AED7953E-59F1-474D-A7BA-561E9D5A3BE6}
		static const GUID guid_main_alarmabort_toggle = { 0xaed7953e, 0x59f1, 0x474d, { 0xa7, 0xba, 0x56, 0x1e, 0x9d, 0x5a, 0x3b, 0xe6 } };


		if (p_index == 0)
			return guid_main_alarm1_toggle;
		if (p_index == 1)
			return guid_main_alarm2_toggle;
		if (p_index == 2)
			return guid_main_alarm3_toggle;
		if (p_index == 3)
			return guid_main_alarm4_toggle;
		if (p_index == 4)
			return guid_main_alarm5_toggle;
		if (p_index == 5)
			return guid_main_alarm6_toggle;
		if (p_index == 6)
			return guid_main_alarm7_toggle;
		if (p_index == 7)
			return guid_main_alarm8_toggle;
		if (p_index == 8)
			return guid_main_alarm9_toggle;
		if (p_index == 9)
			return guid_main_alarm10_toggle;
		if (p_index == 10)
			return guid_main_alarm11_toggle;
		if (p_index == 11)
			return guid_main_alarm12_toggle;
		if (p_index == 12)
			return guid_main_alarm13_toggle;
		if (p_index == 13)
			return guid_main_alarm14_toggle;
		if (p_index == 14)
			return guid_main_alarm15_toggle;
		if (p_index == 15)
			return guid_main_alarm16_toggle;
		if (p_index == 16)
			return guid_main_alarm17_toggle;
		if (p_index == 17)
			return guid_main_alarm18_toggle;
		if (p_index == 18)
			return guid_main_alarm19_toggle;
		if (p_index == 19)
			return guid_main_alarm20_toggle;
		if (p_index == 20)
			return guid_main_alarm21_toggle;
		if (p_index == 21)
			return guid_main_alarmabort_toggle;
		return pfc::guid_null;
	}

	// Set p_out to the name of the n-th command.
	// This name is used to identify the command and determines
	// the default position of the command in the menu.
	virtual void get_name(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "5s";
		if (p_index == 1)
			p_out = "10s";
		if (p_index == 2)
			p_out = "15s";
		if (p_index == 3)
			p_out = "20s";
		if (p_index == 4)
			p_out = "30s";
		if (p_index == 5)
			p_out = "1min";
		if (p_index == 6)
			p_out = "2min";
		if (p_index == 7)
			p_out = "5min";
		if (p_index == 8)
			p_out = "10min";
		if (p_index == 9)
			p_out = "20min";
		if (p_index == 10)
			p_out = "0.5h";
		if (p_index == 11)
			p_out = "1h";
		if (p_index == 12)
			p_out = "1.5h";
		if (p_index == 13)
			p_out = "2h";
		if (p_index == 14)
			p_out = "2.5h";
		if (p_index == 15)
			p_out = "3h";
		if (p_index == 16)
			p_out = "3.5h";
		if (p_index == 17)
			p_out = "4h";
		if (p_index == 18)
			p_out = "4.5h";
		if (p_index == 19)
			p_out = "5h";
		if (p_index == 20)
			p_out = "Alarm# min";
		if (p_index == 21)
			p_out = "Abort";
	}

	// Set p_out to the description for the n-th command.
	virtual bool get_description(t_uint32 p_index, pfc::string_base & p_out)
	{
		if (p_index == 0)
			p_out = "Start playback after 5s.";
		else if (p_index == 1)
			p_out = "Start playback after 10s.";
		else if (p_index == 2)
			p_out = "Start playback after 15s.";
		else if (p_index == 3)
			p_out = "Start playback after 20s.";
		else if (p_index == 4)
			p_out = "Start playback after 30s.";
		else if (p_index == 5)
			p_out = "Start playback after 1min.";
		else if (p_index == 6)
			p_out = "Start playback after 2min.";
		else if (p_index == 7)
			p_out = "Start playback after 5min.";
		else if (p_index == 8)
			p_out = "Start playback after 10min.";
		else if (p_index == 9)
			p_out = "Start playback after 20min.";
		else if (p_index == 10)
			p_out = "Start playback after 0.5h.";
		else if (p_index == 11)
			p_out = "Start playback after 1h.";
		else if (p_index == 12)
			p_out = "Start playback after 1.5h.";
		else if (p_index == 13)
			p_out = "Start playback after 2h.";
		else if (p_index == 14)
			p_out = "Start playback after 2.5h.";
		else if (p_index == 15)
			p_out = "Start playback after 3.0h.";
		else if (p_index == 16)
			p_out = "Start playback after 3.5h.";
		else if (p_index == 17)
			p_out = "Start playback after 4h.";
		else if (p_index == 18)
			p_out = "Start playback after 4.5h.";
		else if (p_index == 19)
			p_out = "Start playback after 5h.";
		else if (p_index == 20)
			p_out = "Start playback after Alarm# minutes.";
		else if (p_index == 21)
			p_out = "Abort start playback. ";
		else
			return false;
		return true;
	}

	// Every set of commands needs to declare which group it belongs to.
	virtual GUID get_parent()
	{
		return guid_cfg_menu_alarm;
	}

	// Execute n-th command.
	// p_callback is reserved for future use.
	virtual void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback)
	{
		if (p_index == 0 && core_api::assert_main_thread())
		{
			cfg_menu_alarm1_enabled = !cfg_menu_alarm1_enabled;
			if (cfg_menu_alarm1_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm1_enabled = true;
				console::info("Alarm in 5s");
				ptr21 = SetTimer(NULL, ID_TIMER10, 5000, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 1 && core_api::assert_main_thread())
		{
			cfg_menu_alarm2_enabled = !cfg_menu_alarm2_enabled;
			if (cfg_menu_alarm2_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm2_enabled = true;
				console::info("Alarm in 10s");
				ptr21 = SetTimer(NULL, ID_TIMER10, 10000, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 2 && core_api::assert_main_thread())
		{
			cfg_menu_alarm3_enabled = !cfg_menu_alarm3_enabled;
			if (cfg_menu_alarm3_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm3_enabled = true;
				console::info("Alarm in 15s");
				ptr21 = SetTimer(NULL, ID_TIMER10, 15000, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 3 && core_api::assert_main_thread())
		{
			cfg_menu_alarm4_enabled = !cfg_menu_alarm4_enabled;
			if (cfg_menu_alarm4_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm4_enabled = true;
				console::info("Alarm in 20s");
				ptr21 = SetTimer(NULL, ID_TIMER10, 20000, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 4 && core_api::assert_main_thread())
		{
			cfg_menu_alarm5_enabled = !cfg_menu_alarm5_enabled;
			if (cfg_menu_alarm5_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm5_enabled = true;
				console::info("Alarm in 30s");
				ptr21 = SetTimer(NULL, ID_TIMER10, 30000, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 5 && core_api::assert_main_thread())
		{
			cfg_menu_alarm6_enabled = !cfg_menu_alarm6_enabled;
			if (cfg_menu_alarm6_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm6_enabled = true;
				console::info("Alarm in 1min");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 6 && core_api::assert_main_thread())
		{
			cfg_menu_alarm7_enabled = !cfg_menu_alarm7_enabled;
			alarm_min2 = 2;
			if (cfg_menu_alarm7_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm7_enabled = true;
				console::info("Alarm in 2min");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 7 && core_api::assert_main_thread())
		{
			cfg_menu_alarm8_enabled = !cfg_menu_alarm8_enabled;
			alarm_min2 = 5;
			if (cfg_menu_alarm8_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm8_enabled = true;
				console::info("Alarm in 5min");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 8 && core_api::assert_main_thread())
		{
			cfg_menu_alarm9_enabled = !cfg_menu_alarm9_enabled;
			alarm_min2 = 10;
			if (cfg_menu_alarm9_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm9_enabled = true;
				console::info("Alarm in 10min");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 9 && core_api::assert_main_thread())
		{
			cfg_menu_alarm10_enabled = !cfg_menu_alarm10_enabled;
			alarm_min2 = 20;
			if (cfg_menu_alarm10_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm10_enabled = true;
				console::info("Alarm in 20min");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 10 && core_api::assert_main_thread())
		{
			cfg_menu_alarm11_enabled = !cfg_menu_alarm11_enabled;
			alarm_min2 = 30;
			//alarm_min2 = 1;
			if (cfg_menu_alarm11_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm11_enabled = true;
				console::info("Alarm in 0.5h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 11 && core_api::assert_main_thread())
		{
			cfg_menu_alarm12_enabled = !cfg_menu_alarm12_enabled;
			alarm_min2 = 60;
			//alarm_min2 = 2;
			if (cfg_menu_alarm12_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm12_enabled = true;
				console::info("Alarm in 1h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 12 && core_api::assert_main_thread())
		{
			cfg_menu_alarm13_enabled = !cfg_menu_alarm13_enabled;
			alarm_min2 = 90;
			//alarm_min2 = 3;
			if (cfg_menu_alarm13_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm13_enabled = true;
				console::info("Alarm in 1.5h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 13 && core_api::assert_main_thread())
		{
			cfg_menu_alarm14_enabled = !cfg_menu_alarm14_enabled;
			alarm_min2 = 120;
			//alarm_min2 = 4;
			if (cfg_menu_alarm14_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm14_enabled = true;
				console::info("Alarm in 2h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 14 && core_api::assert_main_thread())
		{
			cfg_menu_alarm15_enabled = !cfg_menu_alarm15_enabled;
			alarm_min2 = 150;
			//alarm_min2 = 5;
			if (cfg_menu_alarm15_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm15_enabled = true;
				console::info("Alarm in 2.5h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 15 && core_api::assert_main_thread())
		{
			cfg_menu_alarm16_enabled = !cfg_menu_alarm16_enabled;
			alarm_min2 = 180;
			//alarm_min2 = 6;
			if (cfg_menu_alarm16_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm16_enabled = true;
				console::info("Alarm in 3h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 16 && core_api::assert_main_thread())
		{
			cfg_menu_alarm17_enabled = !cfg_menu_alarm17_enabled;
			alarm_min2 = 210;
			//alarm_min2 = 7;
			if (cfg_menu_alarm17_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm17_enabled = true;
				console::info("Alarm in 3.5h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 17 && core_api::assert_main_thread())
		{
			cfg_menu_alarm18_enabled = !cfg_menu_alarm18_enabled;
			alarm_min2 = 240;
			//alarm_min2 = 8;
			if (cfg_menu_alarm18_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm18_enabled = true;
				console::info("Alarm in 4h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 18 && core_api::assert_main_thread())
		{
			cfg_menu_alarm19_enabled = !cfg_menu_alarm19_enabled;
			alarm_min2 = 270;
			//alarm_min2 = 9;
			if (cfg_menu_alarm19_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm19_enabled = true;
				console::info("Alarm in 4.5h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 19 && core_api::assert_main_thread())
		{
			cfg_menu_alarm20_enabled = !cfg_menu_alarm20_enabled;
			alarm_min2 = 300;
			//alarm_min2 = 10;
			if (cfg_menu_alarm20_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm20_enabled = true;
				console::info("Alarm in 5h");
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 20 && core_api::assert_main_thread())
		{
			cfg_menu_alarm21_enabled = !cfg_menu_alarm21_enabled;
			cfg_alarm.get(alarm_min);
			alarm_min2 = atoi(alarm_min);
			if (cfg_menu_alarm21_enabled)
			{
				if (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing())
				{
					static_api_ptr_t<playback_control>()->stop();
				}
				option2::set_option(2);
				cfg_menu_alarm21_enabled = true;
				console::formatter() << "Alarm in " << alarm_min2 << " min.";
				ptr21 = SetTimer(NULL, ID_TIMER10, 60000 * alarm_min2, (TIMERPROC)Alarm);
			}
		}
		if (p_index == 21 && core_api::assert_main_thread())
		{
			cfg_menu_alarmabort_enabled = !cfg_menu_alarmabort_enabled;
			console::info("Alarm aborted");
			option2::set_option(2);
			cfg_menu_alarmabort_enabled = false;
			KillTimer(NULL, ptr21);
		}
	}

	// The standard version of this command does not support checked or disabled
	// commands, so we use our own version.
	virtual bool get_display(t_uint32 p_index, pfc::string_base & p_text, t_uint32 & p_flags)
	{
		p_flags = 0;
		if (is_checked(p_index))
			p_flags |= flag_checked;
		get_name(p_index, p_text);
		return true;
	}

	virtual t_uint32 get_sort_priority()
	{
		return sort_priority_base;
	}

private:

	// Return whether the n-th command is checked.
	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_alarm1_enabled;
		if (p_index == 1)
			return cfg_menu_alarm2_enabled;
		if (p_index == 2)
			return cfg_menu_alarm3_enabled;
		if (p_index == 3)
			return cfg_menu_alarm4_enabled;
		if (p_index == 4)
			return cfg_menu_alarm5_enabled;
		if (p_index == 5)
			return cfg_menu_alarm6_enabled;
		if (p_index == 6)
			return cfg_menu_alarm7_enabled;
		if (p_index == 7)
			return cfg_menu_alarm8_enabled;
		if (p_index == 8)
			return cfg_menu_alarm9_enabled;
		if (p_index == 9)
			return cfg_menu_alarm10_enabled;
		if (p_index == 10)
			return cfg_menu_alarm11_enabled;
		if (p_index == 11)
			return cfg_menu_alarm12_enabled;
		if (p_index == 12)
			return cfg_menu_alarm13_enabled;
		if (p_index == 13)
			return cfg_menu_alarm14_enabled;
		if (p_index == 14)
			return cfg_menu_alarm15_enabled;
		if (p_index == 15)
			return cfg_menu_alarm16_enabled;
		if (p_index == 16)
			return cfg_menu_alarm17_enabled;
		if (p_index == 17)
			return cfg_menu_alarm18_enabled;
		if (p_index == 18)
			return cfg_menu_alarm19_enabled;
		if (p_index == 19)
			return cfg_menu_alarm20_enabled;
		if (p_index == 20)
			return cfg_menu_alarm21_enabled;
		if (p_index == 21)
			return cfg_menu_alarmabort_enabled;
		return false;
	}
};


static mainmenu_group_popup_factory mainmenu_group5(guid_cfg_menu_alarm,
        guid_cfg_menu_control, mainmenu_commands::sort_priority_last,
        "Alarm");

static mainmenu_commands_factory_t<mainmenu_commands_alarm> g_mainmenu_commands_alarm;


//timebomb stop after current
VOID CALLBACK Timebomb(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent1,     // timer identifier
    DWORD dwTime)     // current system time
{
	pfc::string8 tb_message;
	cfg_timebomb_message.get(tb_message);
	static_api_ptr_t<playback_control>()->set_stop_after_current(true);
	if (cfg_timebomb_message_enabled)
	{
		popup_message::g_show(tb_message, "Timebomb stop after current");
	}
	console::info("Stop after current (timebomb)");
	KillTimer(NULL, idEvent1);
}

//timebomb sudden death
VOID CALLBACK Timebomb2(
    HWND hwnd,
    UINT message,
    UINT idEvent2,
    DWORD dwTime)
{
	cfg_tracknumber_enabled = false;
	cfg_only_stop_once_tracknumber = false;
	pfc::string8 tb_message;
	cfg_timebomb_message.get(tb_message);
	static_api_ptr_t<playback_control>()->stop();
	if (cfg_timebomb_message_enabled)
	{
		popup_message::g_show(tb_message, "Timebomb sudden death");
	}
	console::info("Timebomb sudden death");
	KillTimer(NULL, idEvent2);
	option2::set_option(1);
}

//repeat & skip
VOID CALLBACK Albumrepeat(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent3,     // timer identifier
    DWORD dwTime)     // current system time
{
	if (cfg_menu_repeattrack_enabled)
	{
		static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		KillTimer(NULL, idEvent3);
		cfg_menu_repeattrack_enabled = false;
		cfg_track_enabled = false;
	}
	if (cfg_reverse_enabled)
	{
		static_api_ptr_t<playback_control>()->start(playback_control::track_command_prev, false);
		KillTimer(NULL, idEvent3);
	}
	if (cfg_repeatalbum_enabled || cfg_repeatalbum_only_once)
	{
		if (tracknumber2 == trackno2)
		{
			if (cfg_repeatalbum_enabled)
			{
				static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
				KillTimer(NULL, idEvent3);
			}
			else if (cfg_repeatalbum_only_once)
			{
				static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
				cfg_repeatalbum_enabled = false;
				cfg_repeatalbum_only_once = false;
				cfg_album_enabled = false;
				option::set_option(7);
				KillTimer(NULL, idEvent3);
			}
		}
		else static_api_ptr_t<playback_control>()->start(playback_control::track_command_prev, true);
	}
	else if (cfg_skipalbum_enabled || cfg_skipalbum_only_once)
	{
		if (tracknumber2 >= totaltracks2)
		{
			if (cfg_skipalbum_enabled)
			{
				if (cfg_randomalbum_enabled)
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
				}
				else
				{
					static_api_ptr_t<playback_control>()->start(playback_control::track_command_next, false);
				}
				KillTimer(NULL, idEvent3);
			}
			else if (cfg_skipalbum_only_once)
			{
				static_api_ptr_t<playback_control>()->start(playback_control::track_command_next, false);
				cfg_skipalbum_enabled = false;
				cfg_skipalbum_only_once = false;
				cfg_menu_skipalbum_enabled = false;
				cfg_album_enabled = false;
				option::set_option(7);
				KillTimer(NULL, idEvent3);
			}
		}
		else
		{
			static_api_ptr_t<playback_control>()->start(playback_control::track_command_next, true);
		}
	}
}

//gap & repeat & skip
VOID CALLBACK Gap(
    HWND hwnd,        // handle to window for timer messages
    UINT message,     // WM_TIMER message
    UINT idEvent4,     // timer identifier
    DWORD dwTime)     // current system time
{
	if (cfg_paused_enabled)
	{
		static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, true);
	}
	else if (cfg_gap_enabled)
	{
		static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
	}
	else if (cfg_skiptrack_enabled)
	{
		static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
		standard_commands::main_next();
		if (cfg_menu_skiptrack_enabled)
		{
			option::set_option(7);
			cfg_menu_skiptrack_enabled = false;
		}
	}
	//random album
	else if (cfg_randomalbum_enabled)
	{
		random_tracknumber = random::get_random();

		if (random_tracknumber <= tracknumber2)
		{
			trackno2 = random_tracknumber;
			option::set_option(10);
			cfg_repeatalbum_enabled = true;
			cfg_randomalbum_enabled = true;
		}
		else if (random_tracknumber > tracknumber2 + 1)
		{
			totaltracks2 = random_tracknumber;
			option::set_option(10);
			cfg_skipalbum_enabled = true;
			cfg_randomalbum_enabled = true;
		}
		else if (random_tracknumber == tracknumber2 + 1)
		{
			static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
			option::set_option(7);
		}
	}
	else if (cfg_nextplaylist_enabled || cfg_nextplaylistfirst_enabled || cfg_previousplaylistfirst_enabled || cfg_repeatplaylist_enabled)
	{
		static_api_ptr_t<playback_control>()->start(playback_control::track_command_play, false);
		if (cfg_repeatplaylist_enabled)
		{
			cfg_menu_repeatplaylist_enabled = false;
			cfg_repeatplaylist_enabled = false;
			option::set_option(7);
		}
	}
	//repeat album, skip album, reverse
	if (cfg_menu_repeattrack_enabled || cfg_repeatalbum_enabled || cfg_skipalbum_enabled || cfg_repeatalbum_only_once || cfg_skipalbum_only_once || cfg_reverse_enabled)
	{
		if (cfg_reverse_enabled)
		{
			static_api_ptr_t<playback_control>()->start(playback_control::track_command_prev, true);
		}
		if (cfg_menu_repeattrack_enabled)
		{
			standard_commands::main_previous();
		}
		if (cfg_repeatalbum_enabled || cfg_repeatalbum_only_once)
		{
			cfg_skipalbum_enabled = false;
			cfg_skipalbum_only_once = false;
			static_api_ptr_t<playback_control>()->start(playback_control::track_command_prev, true);
		}
		else if (cfg_skipalbum_enabled || cfg_skipalbum_only_once)
		{
			cfg_repeatalbum_enabled = false;
			cfg_repeatalbum_only_once = false;
			if (!cfg_randomalbum_enabled)
			{
				static_api_ptr_t<playback_control>()->start(playback_control::track_command_next, true);
			}
		}
		ptr15 = SetTimer(NULL, ID_TIMER3, 500, (TIMERPROC)Albumrepeat);
	}
	KillTimer(NULL, idEvent4);
}



class play_callback_stopafteralbum : public play_callback_static
{

public:
	virtual unsigned get_flags(void)
	{
		return(flag_on_playback_new_track | flag_on_playback_stop);
	}

	virtual void FB2KAPI on_playback_new_track(metadb_handle_ptr p_track)
	{
		if ((cfg_only_stop_once_track_old != cfg_only_stop_once_track) || (cfg_track_enabled_old != cfg_track_enabled) || (cfg_album_enabled_old != cfg_album_enabled) || (cfg_time_enabled_old != cfg_time_enabled || (cfg_tracknumber_enabled_old != cfg_tracknumber_enabled)))
		{
			playback_new_track = 0;
			length2 = 0;
		}
		if (!cfg_repeatalbum_enabled)
		{
			cfg_menu_repeatalbum_enabled = false;
		}
		if (!cfg_skipalbum_only_once)
		{
			cfg_menu_skipalbum_enabled = false;
		}
		if (!cfg_gap_enabled)
		{
			option2::set_option(3);
			option2::set_option(4);
		}
		if (!cfg_randomalbum_enabled)
		{
			cfg_menu_randomalbum_enabled = false;
		}
		if (!cfg_album_enabled && !cfg_only_stop_once_album)
		{
			cfg_menu_stopalbum_enabled = false;
			option2::set_option(6);
		}
		if (!cfg_lasttrack_enabled)
		{
			cfg_menu_stoplasttrack_enabled = false;
		}
		if (!cfg_lasttrack_enabled && !cfg_album_enabled)
		{
			cfg_menu_stopalbumlasttrack_enabled = false;
		}
		if (!cfg_track_enabled && !cfg_only_stop_once_track)
		{
			cfg_menu_skiptrack_enabled = false;
			option2::set_option(5);
			option2::set_option(3);
		}
		if (!cfg_timebomb_suddendeath_enabled)
		{
			option2::set_option(1);
		}
		if (!cfg_reverse_enabled)
		{
			cfg_menu_reverse_enabled = false;
		}
		cfg_track_enabled_old = cfg_track_enabled;
		cfg_only_stop_once_track_old = cfg_only_stop_once_track;
		cfg_tracknumber_enabled_old = cfg_tracknumber_enabled;
		cfg_album_enabled_old = cfg_album_enabled;
		cfg_time_enabled_old = cfg_time_enabled;

		playback_new_track++;
		p_track->metadb_lock();
		service_ptr_t<titleformat_object> tagobj1;
		service_ptr_t<titleformat_object> tagobj2;
		service_ptr_t<titleformat_object> tagobj3;
		service_ptr_t<titleformat_object> tagobj4;
		service_ptr_t<titleformat_object> tagobj5;
		static_api_ptr_t<titleformat_compiler> compiler;
		tag1 = "%tracknumber%";
		compiler->compile(tagobj1, tag1);
		tag2 = "%totaltracks%";
		compiler->compile(tagobj2, tag2);
		tag3 = "%length_seconds%";
		compiler->compile(tagobj3, tag3);
		tag4 = "%lasttrack%";
		compiler->compile(tagobj4, tag4);
		tag5 = "%postgap%";
		compiler->compile(tagobj5, tag5);
		p_track->format_title(NULL, tracknumber, tagobj1, NULL);
		p_track->format_title(NULL, totaltracks, tagobj2, NULL);
		p_track->format_title(NULL, length, tagobj3, NULL);
		p_track->format_title(NULL, lasttrack, tagobj4, NULL);
		p_track->format_title(NULL, postgap, tagobj5, NULL);
		tagobj1.release();
		tagobj2.release();
		tagobj3.release();
		tagobj4.release();
		tagobj5.release();
		p_track->metadb_unlock();
		SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(tracknumber));
		SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(totaltracks));
		SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(length));
		SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(lasttrack));
		SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(postgap));
		lasttrack2 = atoi(lasttrack);
		postgap2 = atof(postgap);
		tracknumber2 = atoi(tracknumber);
		length2 += atoi(length);
		length3 = atoi(length);
		length2_min = length2 / 60;
		cfg_time.get(timemin);
		if (!cfg_menu_stopaftertracks1_enabled && !cfg_menu_stopaftertracks2_enabled && !cfg_menu_stopaftertracks3_enabled && !cfg_menu_stopaftertracks4_enabled && !cfg_menu_stopaftertracks5_enabled && !cfg_menu_stopaftertracks6_enabled && !cfg_menu_stopaftertracks7_enabled && !cfg_menu_stopaftertracks8_enabled && !cfg_menu_stopaftertracks9_enabled && !cfg_menu_stopaftertracks10_enabled && !cfg_menu_stopaftertracks11_enabled && !cfg_menu_stopaftertracks12_enabled && !cfg_menu_stopaftertracks13_enabled && !cfg_menu_stopaftertracks14_enabled && !cfg_menu_stopaftertracks15_enabled && !cfg_menu_stopaftertracks16_enabled && !cfg_menu_stopaftertracks17_enabled && !cfg_menu_stopaftertracks18_enabled && !cfg_menu_stopaftertracks19_enabled && !cfg_menu_stopaftertracks20_enabled)
		{
			cfg_track.get(track);
			track2 = atoi(track);
		}
		if (!cfg_menu_repeatalbum_enabled && !cfg_menu_skipalbum_enabled && !cfg_menu_stopalbum_enabled && !cfg_menu_stopafteralbums1_enabled && !cfg_menu_stopafteralbums2_enabled && !cfg_menu_stopafteralbums3_enabled && !cfg_menu_stopafteralbums4_enabled && !cfg_menu_stopafteralbums5_enabled && !cfg_menu_stopafteralbums6_enabled && !cfg_menu_stopafteralbums7_enabled && !cfg_menu_stopafteralbums8_enabled && !cfg_menu_stopafteralbums9_enabled && !cfg_menu_stopafteralbums10_enabled)
		{
			cfg_album.get(album);
			album2 = atoi(album);
		}
		cfg_tracknumber.get(stopaftercurrent_trackno);
		stopaftercurrent_trackno2 = atoi(stopaftercurrent_trackno);
		cfg_repeatalbum.get(trackno);
		if (!cfg_randomalbum_enabled)
		{
			totaltracks2 = atoi(totaltracks);
			trackno2 = atoi(trackno);
		}
		if (!cfg_menu_timebomb1_enabled && !cfg_menu_timebomb2_enabled && !cfg_menu_timebomb3_enabled && !cfg_menu_timebomb4_enabled && !cfg_menu_timebomb5_enabled && !cfg_menu_timebomb6_enabled && !cfg_menu_timebomb7_enabled && !cfg_menu_timebomb8_enabled && !cfg_menu_timebomb9_enabled && !cfg_menu_timebomb10_enabled)
		{
			cfg_timebomb.get(timebomb_min);
			timebomb_min2 = atoi(timebomb_min);
		}

		//tracknumber
		if ((stopaftercurrent_trackno2 == tracknumber2) && (!cfg_menu_repeattrack_enabled) && (cfg_tracknumber_enabled || cfg_only_stop_once_tracknumber))
		{
			if (cfg_only_stop_once_tracknumber)
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::formatter() << "Stop after current only once (tracknumber=" << tracknumber2 << ")";
				tracknumberonce = true;
				cfg_tracknumber_enabled = false;
				cfg_only_stop_once_tracknumber = false;

			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::formatter() << "Stop after current (tracknumber=" << tracknumber2 << ")";
			}
		}
		//timebomb
		else if ((cfg_timebomb_enabled || cfg_timebomb_suddendeath_enabled) && (!cfg_menu_repeattrack_enabled))
		{
			if (cfg_timebomb_enabled && (!cfg_timebomb_suddendeath_enabled))
			{
				ptr11 = SetTimer(NULL, ID_TIMER, timebomb_min2 * 60000, (TIMERPROC)Timebomb);
				console::formatter() << "Timebomb in " << timebomb_min2 << " min.";
				cfg_timebomb_enabled = false;
			}
			if (cfg_timebomb_suddendeath_enabled  || (cfg_timebomb_enabled && cfg_timebomb_suddendeath_enabled))
			{
				ptr12 = SetTimer(NULL, ID_TIMER4, timebomb_min2 * 60000, (TIMERPROC)Timebomb2);
				console::formatter() << "Timebomb in " << timebomb_min2 << " min.";
				cfg_timebomb_suddendeath_enabled = false;
				cfg_timebomb_enabled = false;
				option2::set_option(1);
			}
		}
		//time
		else if ((length2_min >= atoi(timemin)) && (!cfg_menu_repeattrack_enabled) && (cfg_time_enabled || cfg_only_stop_once_time))
		{
			if (cfg_only_stop_once_time)
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::formatter() << "Stop after current only once (time=" << atoi(timemin) << ")";
				length2 = 0;
				timeonce = true;
				cfg_time_enabled = false;
				cfg_only_stop_once_time = false;
			}
			else if (cfg_time_enabled && (!cfg_only_stop_once_time))
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::formatter() << "Stop after current (time=" << atoi(timemin) << ")";
				length2 = 0;
			}
		}
		//track
		else if ((!cfg_menu_postgap_enabled) && (playback_new_track == track2) && (!cfg_menu_repeattrack_enabled) && (cfg_track_enabled || cfg_only_stop_once_track))
		{
			if (cfg_only_stop_once_track)
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::formatter() << "Stop after current only once (track=" << track2 << ")";
				playback_new_track = 0;
				trackonce = true;
				cfg_track_enabled = false;
				cfg_only_stop_once_track = false;
				option2::set_option(5);
			}
			else
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				//console::formatter() << "Stop after current (track=" << track2 << ")";
				playback_new_track = 0;
			}
		}
		//album
		else if ( (tracknumber2 > 0) && (totaltracks2 > 0) && (tracknumber2 == totaltracks2) && (!cfg_lasttrack_enabled) && (!cfg_randomalbum_enabled) && (!cfg_menu_repeattrack_enabled) && (cfg_album_enabled || cfg_only_stop_once_album))
		{
			album_end++;

			if (album_end >= album2)
			{

				if (cfg_only_stop_once_album)
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
					console::formatter() << "Stop after current only once (album=" << album2 << ")";
					album_end = 0;
					albumonce = true;
					cfg_album_enabled = false;
					cfg_only_stop_once_album = false;
					option2::set_option(6);
				}
				else
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(true);
					console::formatter() << "Stop after current (album=" << album2 << ")";
					album_end = 0;
				}
			}
		}
		//lasttrack
		else if ((lasttrack2 == 1) && (!cfg_album_enabled) && (!cfg_randomalbum_enabled) && (!cfg_menu_repeattrack_enabled) && (cfg_lasttrack_enabled))
		{
			if (cfg_lasttrack_enabled)
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::info("Stop after current (last track)");
			}
		}
		else if (!cfg_album_enabled)
		{
			cfg_menu_stopalbum_enabled = false;
			cfg_menu_repeatalbum_enabled = false;
			cfg_menu_skipalbum_enabled = false;
			option2::set_option(4);
		}
		//album & lasttrack
		else if ( (tracknumber2 > 0) && (totaltracks2 > 0) && ((tracknumber2 == totaltracks2) || (lasttrack2 == 1)) && (cfg_album_enabled) && (!cfg_randomalbum_enabled) && (!cfg_menu_repeattrack_enabled) && (cfg_lasttrack_enabled))
		{
			if (cfg_lasttrack_enabled && cfg_album_enabled)
			{
				static_api_ptr_t<playback_control>()->set_stop_after_current(true);
				console::info("Stop after current (album & last track)");
			}
		}
		//random album
		if (cfg_randomalbum_enabled)
		{
			cfg_album_enabled = false;
			static_api_ptr_t<playback_control>()->set_stop_after_current(true);
			//console::info("Random album");
		}

		//repeat track only once
		if (cfg_menu_repeattrack_enabled)
		{
			static_api_ptr_t<playback_control>()->set_stop_after_current(true);
			cfg_track_enabled = true;
			//console::info("Repeat track once");
		}
		//reverse
		else if (cfg_reverse_enabled)
		{
			static_api_ptr_t<playback_control>()->set_stop_after_current(true);
			cfg_track_enabled = true;
			//console::info("Reverse");
		}
		//postgap
		if (cfg_menu_postgap_enabled && postgap2 > 0)
		{
			static_api_ptr_t<playback_control>()->set_stop_after_current(true);
		}
		if (cfg_menu_postgap_enabled && !(postgap2 > 0))
		{
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		}
	}

	virtual void on_playback_stop(play_control::t_stop_reason p_reason)
	{
		if ((p_reason == 1) && cfg_nextplaylist_enabled)
		{
			static_api_ptr_t<playlist_manager>()->playlist_activate_next();
			static_api_ptr_t<playlist_manager>()->set_playing_playlist(static_api_ptr_t<playlist_manager>()->get_active_playlist());
			ptr10 = SetTimer(NULL, ID_TIMER2, 0, (TIMERPROC)Gap);
		}
		if ((p_reason == 1) && !cfg_repeatplaylist_enabled && !cfg_previousplaylistfirst_enabled && cfg_nextplaylistfirst_enabled && !(static_api_ptr_t<playback_control>()->get_stop_after_current()))
		{
			static_api_ptr_t<playlist_manager>()->playlist_activate_next();
			static_api_ptr_t<playlist_manager>()->set_playing_playlist(static_api_ptr_t<playlist_manager>()->get_active_playlist());
			static_api_ptr_t<playlist_manager>()->queue_add_item_playlist(static_api_ptr_t<playlist_manager>()->get_active_playlist(), 0);
			ptr10 = SetTimer(NULL, ID_TIMER2, 0, (TIMERPROC)Gap);
		}
		if ((p_reason == 1) && !cfg_repeatplaylist_enabled && cfg_previousplaylistfirst_enabled && !cfg_nextplaylistfirst_enabled && !(static_api_ptr_t<playback_control>()->get_stop_after_current()))
		{
			static_api_ptr_t<playlist_manager>()->playlist_activate_previous();
			static_api_ptr_t<playlist_manager>()->set_playing_playlist(static_api_ptr_t<playlist_manager>()->get_active_playlist());
			static_api_ptr_t<playlist_manager>()->queue_add_item_playlist(static_api_ptr_t<playlist_manager>()->get_active_playlist(), 0);
			ptr10 = SetTimer(NULL, ID_TIMER2, 0, (TIMERPROC)Gap);
		}
		if ((p_reason == 1) && cfg_repeatplaylist_enabled && !(static_api_ptr_t<playback_control>()->get_stop_after_current()))
		{
			static_api_ptr_t<playlist_manager>()->queue_add_item_playlist(static_api_ptr_t<playlist_manager>()->get_active_playlist(), 0);
			ptr10 = SetTimer(NULL, ID_TIMER2, 0, (TIMERPROC)Gap);
		}
		//reset when stopping
		if (cfg_gap_enabled || cfg_lasttrack_enabled || cfg_skiptrack_enabled || cfg_album_enabled || cfg_only_stop_once_album || cfg_track_enabled || cfg_only_stop_once_track || cfg_time_enabled || cfg_only_stop_once_time || cfg_tracknumber_enabled || cfg_only_stop_once_tracknumber || cfg_reverse_enabled)
		{
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		}
		if (trackonce)
		{
			cfg_track_enabled = false;
			cfg_only_stop_once_track = false;
			trackonce = false;
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		}
		if (albumonce)
		{
			cfg_album_enabled = false;
			cfg_only_stop_once_album = false;
			albumonce = false;
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		}
		if (timeonce)
		{
			cfg_time_enabled = false;
			cfg_only_stop_once_time = false;
			timeonce = false;
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		}
		if (tracknumberonce)
		{
			cfg_tracknumber_enabled = false;
			cfg_only_stop_once_tracknumber = false;
			tracknumberonce = false;
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
		}
		//Gap every track
		if (cfg_gap_enabled && cfg_track_enabled)
		{
			static_api_ptr_t<playback_control>()->set_stop_after_current(true);
		}

		/*if (p_reason == 0 && cfg_gap_enabled)
		{
			option2::set_option(3);
			option2::set_option(4);
			static_api_ptr_t<playback_control>()->set_stop_after_current(false);
			cfg_album_enabled = false;
			cfg_track_enabled = false;
		}*/

		switch(p_reason)
		{
			case play_control::stop_reason_eof:
			{
				size_t playlist;
				size_t index;
				static_api_ptr_t<playlist_manager>()->get_playing_item_location(&playlist,&index);

				size_t count=static_api_ptr_t<playlist_manager>()->activeplaylist_get_item_count ();

				if(index + 1 < count)
				{
					//p_reason: 0=user;1=eof;2=starting another;3=shuting down
					if (cfg_gap_enabled || cfg_paused_enabled || cfg_skiptrack_enabled)
					{
						if (cfg_paused_enabled)
						{
							console::info("Gap & paused");
							cfg_gap2.get(gap_sec);
							ptr10 = SetTimer(NULL, ID_TIMER2, atoi(gap_sec), (TIMERPROC)Gap);
						}
						else if (cfg_gap_enabled)
						{
							if (cfg_menu_gaptracks19_enabled || cfg_menu_gapalbums19_enabled)
							{
								cfg_gap.get(gap_sec);
								gap_msec = atoi(gap_sec);
							}
							/*else if (cfg_menu_gaptracks20_enabled || cfg_menu_gapalbums20_enabled)
							{
								gap_sec2 = int(length3);
								gap_msec = gap_sec2 * 1000;
							}
							*/
							else if (cfg_menu_postgap_enabled && postgap2 > 0)
							{
								gap_msec = postgap2 * 1000;
							}
							console::formatter() << "Gap & play: " << gap_msec;
							ptr10 = SetTimer(NULL, ID_TIMER2, gap_msec, (TIMERPROC)Gap);
						}
						else if (cfg_skiptrack_enabled)
						{
							//console::info("Skip next");
							ptr10 = SetTimer(NULL, ID_TIMER2, 0, (TIMERPROC)Gap);
						}
					}
					if (cfg_menu_repeattrack_enabled || cfg_reverse_enabled || cfg_randomalbum_enabled || cfg_repeatalbum_enabled || cfg_skipalbum_enabled || cfg_repeatalbum_only_once || cfg_skipalbum_only_once)
					{
						ptr10 = SetTimer(NULL, ID_TIMER2, 0, (TIMERPROC)Gap);
					}
				}
				break;
			}
		}
	}
	virtual void on_playback_pause(bool p_state) {}
	virtual void on_playback_starting(play_control::t_track_command p_command, bool p_paused) {}
	virtual void on_playback_seek(double p_time) {}
	virtual void on_playback_edited(metadb_handle_ptr p_track) {}
	virtual void on_playback_dynamic_info(const file_info & info) {}
	virtual void on_playback_dynamic_info_track(const file_info & info) {}
	virtual void on_playback_time(double p_time) {}
	virtual void on_volume_change(float p_new_val) {}
};

static play_callback_static_factory_t<play_callback_stopafteralbum> g_play_callback_stopafteralbum;

//EOF