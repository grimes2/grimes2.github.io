//Helper classes for foo_stopafteralbum.cpp

class option
{

public:

	static void set_option(int p_option)
	{
		//stop
		if (p_option == 7)
		{
			cfg_paused_enabled = false;
			cfg_gap_enabled = false;
			cfg_repeatalbum_enabled = false;
			cfg_repeatalbum_only_once = false;
			cfg_skipalbum_enabled = false;
			cfg_skipalbum_only_once = false;
			cfg_stop_enabled = true;
			cfg_skiptrack_enabled = false;
			cfg_randomalbum_enabled = false;
		}
		//disabled
		else if (p_option == 10)
		{
			cfg_paused_enabled = false;
			cfg_gap_enabled = false;
			cfg_repeatalbum_enabled = false;
			cfg_repeatalbum_only_once = false;
			cfg_skipalbum_enabled = false;
			cfg_skipalbum_only_once = false;
			cfg_stop_enabled = false;
			cfg_track_enabled = false;
			cfg_skiptrack_enabled = false;
			cfg_album_enabled = false;
			cfg_lasttrack_enabled = false;
			cfg_time_enabled = false;
			cfg_tracknumber_enabled = false;
			cfg_randomalbum_enabled = false;
			cfg_only_stop_once_album = false;
			cfg_only_stop_once_track = false;
			cfg_only_stop_once_time = false;
			cfg_only_stop_once_tracknumber = false;
			cfg_nextplaylist_enabled = false;
			cfg_previousplaylistfirst_enabled = false;
			cfg_nextplaylistfirst_enabled = false;
			cfg_repeatplaylist_enabled = false;
		}
	}
};


class option2
{

public:

	static void set_option(int p_option)
	{
		if (p_option == 1)
		{
			cfg_menu_timebomb1_enabled = false;
			cfg_menu_timebomb2_enabled = false;
			cfg_menu_timebomb3_enabled = false;
			cfg_menu_timebomb4_enabled = false;
			cfg_menu_timebomb5_enabled = false;
			cfg_menu_timebomb6_enabled = false;
			cfg_menu_timebomb7_enabled = false;
			cfg_menu_timebomb8_enabled = false;
			cfg_menu_timebomb9_enabled = false;
			cfg_menu_timebomb10_enabled = false;
			cfg_menu_timebomb11_enabled = false;
		}
		if (p_option == 2)
		{
			cfg_menu_alarm1_enabled = false;
			cfg_menu_alarm2_enabled = false;
			cfg_menu_alarm3_enabled = false;
			cfg_menu_alarm4_enabled = false;
			cfg_menu_alarm5_enabled = false;
			cfg_menu_alarm6_enabled = false;
			cfg_menu_alarm7_enabled = false;
			cfg_menu_alarm8_enabled = false;
			cfg_menu_alarm9_enabled = false;
			cfg_menu_alarm10_enabled = false;
			cfg_menu_alarm11_enabled = false;
			cfg_menu_alarm12_enabled = false;
			cfg_menu_alarm13_enabled = false;
			cfg_menu_alarm14_enabled = false;
			cfg_menu_alarm15_enabled = false;
			cfg_menu_alarm16_enabled = false;
			cfg_menu_alarm17_enabled = false;
			cfg_menu_alarm18_enabled = false;
			cfg_menu_alarm19_enabled = false;
			cfg_menu_alarm20_enabled = false;
			cfg_menu_alarm21_enabled = false;
		}
		if (p_option == 3)
		{
			cfg_menu_gaptracks1_enabled = false;
			cfg_menu_gaptracks2_enabled = false;
			cfg_menu_gaptracks3_enabled = false;
			cfg_menu_gaptracks4_enabled = false;
			cfg_menu_gaptracks5_enabled = false;
			cfg_menu_gaptracks6_enabled = false;
			cfg_menu_gaptracks7_enabled = false;
			cfg_menu_gaptracks8_enabled = false;
			cfg_menu_gaptracks9_enabled = false;
			cfg_menu_gaptracks10_enabled = false;
			cfg_menu_gaptracks11_enabled = false;
			cfg_menu_gaptracks12_enabled = false;
			cfg_menu_gaptracks13_enabled = false;
			cfg_menu_gaptracks14_enabled = false;
			cfg_menu_gaptracks15_enabled = false;
			cfg_menu_gaptracks16_enabled = false;
			cfg_menu_gaptracks17_enabled = false;
			cfg_menu_gaptracks18_enabled = false;
			cfg_menu_gaptracks19_enabled = false;
			cfg_menu_gaptracks20_enabled = false;
		}
		if (p_option == 4)
		{
			cfg_menu_gapalbums1_enabled = false;
			cfg_menu_gapalbums2_enabled = false;
			cfg_menu_gapalbums3_enabled = false;
			cfg_menu_gapalbums4_enabled = false;
			cfg_menu_gapalbums5_enabled = false;
			cfg_menu_gapalbums6_enabled = false;
			cfg_menu_gapalbums7_enabled = false;
			cfg_menu_gapalbums8_enabled = false;
			cfg_menu_gapalbums9_enabled = false;
			cfg_menu_gapalbums10_enabled = false;
			cfg_menu_gapalbums11_enabled = false;
			cfg_menu_gapalbums12_enabled = false;
			cfg_menu_gapalbums13_enabled = false;
			cfg_menu_gapalbums14_enabled = false;
			cfg_menu_gapalbums15_enabled = false;
			cfg_menu_gapalbums16_enabled = false;
			cfg_menu_gapalbums17_enabled = false;
			cfg_menu_gapalbums18_enabled = false;
			cfg_menu_gapalbums19_enabled = false;
			cfg_menu_gapalbums20_enabled = false;
		}
		if (p_option == 5)
		{
			cfg_menu_stopaftertracks1_enabled = false;
			cfg_menu_stopaftertracks2_enabled = false;
			cfg_menu_stopaftertracks3_enabled = false;
			cfg_menu_stopaftertracks4_enabled = false;
			cfg_menu_stopaftertracks5_enabled = false;
			cfg_menu_stopaftertracks6_enabled = false;
			cfg_menu_stopaftertracks7_enabled = false;
			cfg_menu_stopaftertracks8_enabled = false;
			cfg_menu_stopaftertracks9_enabled = false;
			cfg_menu_stopaftertracks10_enabled = false;
			cfg_menu_stopaftertracks11_enabled = false;
			cfg_menu_stopaftertracks12_enabled = false;
			cfg_menu_stopaftertracks13_enabled = false;
			cfg_menu_stopaftertracks14_enabled = false;
			cfg_menu_stopaftertracks15_enabled = false;
			cfg_menu_stopaftertracks16_enabled = false;
			cfg_menu_stopaftertracks17_enabled = false;
			cfg_menu_stopaftertracks18_enabled = false;
			cfg_menu_stopaftertracks19_enabled = false;
			cfg_menu_stopaftertracks20_enabled = false;
		}
		if (p_option == 6)
		{
			cfg_menu_stopafteralbums1_enabled = false;
			cfg_menu_stopafteralbums2_enabled = false;
			cfg_menu_stopafteralbums3_enabled = false;
			cfg_menu_stopafteralbums4_enabled = false;
			cfg_menu_stopafteralbums5_enabled = false;
			cfg_menu_stopafteralbums6_enabled = false;
			cfg_menu_stopafteralbums7_enabled = false;
			cfg_menu_stopafteralbums8_enabled = false;
			cfg_menu_stopafteralbums9_enabled = false;
			cfg_menu_stopafteralbums10_enabled = false;
		}
	}
};


class option4
{

public:

	static void set_option(int p_option)
	{
		//disabled
		if (p_option == 1)
		{
			cfg_menu_stopalbum_enabled = false;
			cfg_menu_stoplasttrack_enabled = false;
			cfg_menu_stopalbumlasttrack_enabled = false;
			cfg_menu_repeatalbum_enabled = false;
			cfg_menu_skipalbum_enabled = false;
			cfg_menu_repeattrack_enabled = false;
			cfg_menu_skiptrack_enabled = false;
			cfg_menu_randomalbum_enabled = false;
			cfg_menu_reverse_enabled = false;
			cfg_menu_previousplaylistfirst_enabled = false;
			cfg_menu_nextplaylistfirst_enabled = false;
			cfg_menu_repeatplaylist_enabled = false;
			cfg_menu_postgap_enabled = false;
		}
		if (p_option == 2)
		{
			cfg_lasttrack_enabled = false;
			cfg_album_enabled = false;
			cfg_only_stop_once_album = false;
			cfg_track_enabled = false;
			cfg_only_stop_once_track = false;
			cfg_time_enabled = false;
			cfg_only_stop_once_time = false;
			cfg_tracknumber_enabled = false;
			cfg_only_stop_once_tracknumber = false;
			cfg_timebomb_enabled = false;
			cfg_timebomb_suddendeath_enabled = false;
			cfg_reverse_enabled = false;
			cfg_nextplaylist_enabled = false;
			cfg_previousplaylistfirst_enabled = false;
			cfg_nextplaylistfirst_enabled = false;
			cfg_repeatplaylist_enabled = false;
			cfg_stop_enabled = true;
		}
	}
};

//EOF