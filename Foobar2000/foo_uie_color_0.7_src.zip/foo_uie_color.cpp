#include "../SDK/foobar2000.h"
#include "../helpers/helpers.h"
#include <commctrl.h>
#include <windowsx.h>

#include "../columns_ui-sdk/ui_extension.h"


/** Declare some information about our component */
DECLARE_COMPONENT_VERSION(
	"Color",
	"0.7",
	"Color v0.7\n"
	"Created by grimes\n"
	"compiled: " __DATE__ " " __TIME__ "\n"
	"with Panel API version: " UI_EXTENSION_VERSION "\n\n"
	"4 colors: rating, playcount, date, tracklength\n"
);

VALIDATE_COMPONENT_FILENAME("foo_uie_color.dll");


pfc::string8 tag1;
pfc::string8 tag2;
pfc::string8 tag3;
pfc::string8 tag4;

pfc::string8 a_rating;
pfc::string8 a_playcount;
pfc::string8 a_date;
pfc::string8 a_tracklength;

t_uint32 rating;
t_uint32 playcount;
t_uint32 date;
t_uint32 tracklength;

int x_0 = 255;
int y_0 = 255;
int z_0 = 255;
int x_1 = 255;
int y_1 = 255;
int z_1 = 255;
int x_2 = 255;
int y_2 = 255;
int z_2 = 255;
int x_3 = 255;
int y_3 = 255;
int z_3 = 255;
int x_4 = 255;
int y_4 = 255;
int z_4 = 255;


/** Our window class */
class color_windows : public uie::container_ui_extension
{

public:

	color_windows();
	~color_windows();

	virtual const GUID & get_extension_guid() const;
	virtual void get_name(pfc::string_base & out)const;
	virtual void get_category(pfc::string_base & out)const;
	unsigned get_type() const;
	static void update_all_window_frames();
	static pfc::list_t<HWND> g_notify_list;

private:

	/** Our window procedure */
	LRESULT on_message(HWND wnd,UINT msg,WPARAM wp,LPARAM lp);

	virtual class_data & get_class_data()const;
	virtual void get_menu_items(uie::menu_hook_t & p_hook);

	static const GUID g_extension_guid;

public:

	/** Our child window */
	HWND wnd_static;
};

void color_windows::get_menu_items(uie::menu_hook_t & p_hook)
{

};

color_windows::color_windows() : wnd_static(NULL)
{}

color_windows::~color_windows()
{}

void color_windows::update_all_window_frames()
{
	unsigned n , count = g_notify_list.get_count();

	for (n=0; n<count; n++)
	{
		HWND wnd = g_notify_list[n];
		if (wnd)
		{
			SetWindowPos(wnd,0,0,0,0,0,SWP_NOOWNERZORDER|SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER);
			RedrawWindow(wnd, 0, 0, RDW_ERASENOW|RDW_ALLCHILDREN|RDW_INVALIDATE|RDW_UPDATENOW);
		}
	}
}


LRESULT color_windows::on_message(HWND wnd,UINT msg,WPARAM wp,LPARAM lp)
{
	HDC display;
	PAINTSTRUCT ps;
	RECT rc;
	GetClientRect(wnd, &rc);
	RECT rc1 = {0,0,rc.right/4-1,rc.bottom};
	RECT rc2 = {rc.right/4,0,rc.right/2-1,rc.bottom};
	RECT rc3 = {rc.right/2,0,rc.right-rc.right/4-1,rc.bottom};
	RECT rc4 = {rc.right-rc.right/4,0,rc.right,rc.bottom};
	TOOLINFO ti = { 0 };;

	switch (msg)
	{
	case WM_CREATE:
	{
		g_notify_list.add_item(wnd);
		/** Create a static window*/
		wnd_static = CreateWindowEx(
		                 WS_EX_STATICEDGE,
		                 WC_STATIC,
		                 _T("color"),
		                 WS_CHILD | WS_VISIBLE,
		                 0,
		                 0,
		                 rc.right,
		                 rc.bottom,
		                 wnd,
		                 HMENU(0),
		                 core_api::get_my_instance(),
		                 NULL);
	}
	break;
	case WM_SIZE:
		SetWindowPos(wnd_static, 0, 0, 0, LOWORD(lp), HIWORD(lp), SWP_NOOWNERZORDER|SWP_NOMOVE|SWP_NOZORDER);
		break;
	case WM_PAINT:
		display = BeginPaint(wnd_static, &ps);
		{
			FillRect(display, &rc, CreateSolidBrush(RGB(x_0,y_0,z_0)));
			FillRect(display, &rc1, CreateSolidBrush(RGB(x_1,y_1,z_1)));
			FillRect(display, &rc2, CreateSolidBrush(RGB(x_2,y_2,z_2)));
			FillRect(display, &rc3, CreateSolidBrush(RGB(x_3,y_3,z_3)));
			FillRect(display, &rc4, CreateSolidBrush(RGB(x_4,y_4,z_4)));
		}
		EndPaint(wnd_static, &ps);
		break;
	case WM_DESTROY:
		/** DefWindowProc will destroy our child window. Set our window handle to NULL now. */
		wnd_static=NULL;
		g_notify_list.remove_item(wnd);
		break;
	}
	return DefWindowProc(wnd, msg, wp, lp);

}


color_windows::class_data & color_windows::get_class_data() const
{
	__implement_get_class_data(_T("{DDB0930F-9CFB-4B08-9C07-22A7DAF15278}"), true);
}



const GUID & color_windows::get_extension_guid() const
{
	return g_extension_guid;
}

void color_windows::get_name(pfc::string_base & out)const
{
	out.set_string("Color");
}
void color_windows::get_category(pfc::string_base & out)const
{
	out.set_string("Panels");
}
unsigned color_windows::get_type() const
{
	return uie::type_toolbar;
}


// {DDB0930F-9CFB-4B08-9C07-22A7DAF15278}
const GUID color_windows::g_extension_guid = { 0xddb0930f, 0x9cfb, 0x4b08, { 0x9c, 0x7, 0x22, 0xa7, 0xda, 0xf1, 0x52, 0x78 } };

uie::window_factory<color_windows> g_color_windows_factory;
pfc::list_t<HWND> color_windows::g_notify_list;

class color
{

public:

	static void calculate_color()
	{

		x_1 = rating < 2 || rating > 4 ? 255 : 0;
		y_1 = rating > 0 && rating < 4 ? 255 : 0;
		z_1 = rating > 2 ? 255 : 0;
		if (playcount <= 25)
		{
			x_2 = 255;
			y_2 = playcount * 10;
			z_2 = 0;
		}
		else if (playcount > 25 && playcount <= 50)
		{
			x_2 = 255 - (playcount - 25) * 10;
			y_2 = 255;
			z_2 = 0;
		}
		else if (playcount > 50 && playcount <= 75)
		{
			x_2 = 0;
			y_2 = 255;
			z_2 = (playcount - 50) * 10;
		}
		else if (playcount > 75 && playcount <= 100)
		{
			x_2 = 0;
			y_2 = 255 - (playcount - 75) * 10;
			z_2 = 255;
		}
		else if (playcount > 100 && playcount <= 125)
		{
			x_2 = (playcount - 100) * 10;
			y_2 = 0;
			z_2 = 255;
		}
		else if (playcount > 125)
		{
			x_2 = 255;
			y_2 = 0;
			z_2 = 255;
		}
		if (date <= 25)
		{
			x_3 = 255;
			y_3 = date * 10;
			z_3 = 0;
		}
		else if (date > 25 && date <= 50)
		{
			x_3 = 255 - (date - 25) * 10;
			y_3 = 255;
			z_3 = 0;
		}
		else if (date > 50 && date <= 75)
		{
			x_3 = 0;
			y_3 = 255;
			z_3 = (date - 50) * 10;
		}
		else if (date > 75 && date <= 100)
		{
			x_3 = 0;
			y_3 = 255 - (date - 75) * 10;
			z_3 = 255;
		}
		else if (date > 100 && date <= 125)
		{
			x_3 = (date - 100) * 10;
			y_3 = 0;
			z_3 = 255;
		}
		else if (date > 125)
		{
			x_3 = 255;
			y_3 = 0;
			z_3 = 255;
		}
		if (tracklength <= 25)
		{
			x_4 = 255;
			y_4 = tracklength * 10;
			z_4 = 0;
		}
		else if (tracklength > 25 && tracklength <= 50)
		{
			x_4 = 255 - (tracklength - 25) * 10;
			y_4 = 255;
			z_4 = 0;
		}
		else if (tracklength > 50 && tracklength <= 75)
		{
			x_4 = 0;
			y_4 = 255;
			z_4 = (tracklength - 50) * 10;
		}
		else if (tracklength > 75 && tracklength <= 100)
		{
			x_4 = 0;
			y_4 = 255 - (tracklength - 75) * 10;
			z_4 = 255;
		}
		else if (tracklength > 100 && tracklength <= 125)
		{
			x_4 = (tracklength - 100) * 10;
			y_4 = 0;
			z_4 = 255;
		}
		else if (tracklength > 125)
		{
			x_4 = 255;
			y_4 = 0;
			z_4 = 255;
		}
	}
};

class play_callback_color : public play_callback_static
{

public:

	virtual unsigned get_flags(void)
	{
		return(flag_on_playback_new_track | flag_on_playback_stop);
	}
	virtual void on_playback_new_track(metadb_handle_ptr p_track)
	{
		p_track->metadb_lock();

		service_ptr_t<titleformat_object> tagobj1;
		service_ptr_t<titleformat_object> tagobj2;
		service_ptr_t<titleformat_object> tagobj3;
		service_ptr_t<titleformat_object> tagobj4;

		static_api_ptr_t<titleformat_compiler> compiler;

		tag1 = "%rating%";
		compiler->compile(tagobj1, tag1);
		tag2 = "%play_count%";
		compiler->compile(tagobj2, tag2);
		tag3 = "%date%";
		compiler->compile(tagobj3, tag3);
		tag4 = "%length_seconds%";
		compiler->compile(tagobj4, tag4);


		p_track->format_title(NULL, a_rating, tagobj1, NULL);
		p_track->format_title(NULL, a_playcount, tagobj2, NULL);
		p_track->format_title(NULL, a_date, tagobj3, NULL);
		p_track->format_title(NULL, a_tracklength, tagobj4, NULL);


		p_track->metadb_unlock();

		tagobj1.release();
		tagobj2.release();
		tagobj3.release();
		tagobj4.release();

		rating = atoi(a_rating);
		int playcount2 = atoi(a_playcount);
		playcount = playcount2 * 2; //advanced user
		int date2 = atoi(a_date);
		if (date2 < 1955)
		{
			date2 = 1955;
		}
		date = (date2 - 1955) * 2;
		int tracklength2 = atoi(a_tracklength);
		tracklength = tracklength2 / 10;
		color::calculate_color();
		color_windows::update_all_window_frames();

	}
	virtual void on_playback_stop(play_control::t_stop_reason p_reason)
	{
		x_1 = 255;
		y_1 = 255;
		z_1 = 255;
		x_2 = 255;
		y_2 = 255;
		z_2 = 255;
		x_3 = 255;
		y_3 = 255;
		z_3 = 255;
		x_4 = 255;
		y_4 = 255;
		z_4 = 255;
		color_windows::update_all_window_frames();
	}
	virtual void on_playback_seek(double p_time) {}
	virtual void on_playback_pause(bool p_state) {}
	virtual void on_playback_starting(play_control::t_track_command p_command, bool p_paused) {}
	virtual void on_playback_edited(metadb_handle_ptr p_track) {}
	virtual void on_playback_dynamic_info(const file_info & info) {}
	virtual void on_playback_dynamic_info_track(const file_info & info) {}
	virtual void on_playback_time(double p_time) {}
	virtual void on_volume_change(float p_new_val) {}
};

static play_callback_static_factory_t<play_callback_color> g_play_callback_color;

//EOF