#include "../SDK/foobar2000.h"
#include "../helpers/helpers.h"
#include <commctrl.h>
#include <windowsx.h>

#include "../columns_ui-sdk/ui_extension.h"

#define ID_TIMER2 1111


/** Declare some information about our component */
DECLARE_COMPONENT_VERSION(
	"Metronome",
	"0.7",
	"Metronome v0.7\n"
	"Created by grimes\n"
	"compiled: " __DATE__ " " __TIME__ "\n"
	"with Panel API version: " UI_EXTENSION_VERSION "\n\n"
	"left mouse button: start/stop metronome\n"
	"mouse wheel: change bpm (beats per minute)\n"
	"middle mouse button: beep on/off"
);

VALIDATE_COMPONENT_FILENAME("foo_uie_metronome.dll");


// {84053460-367B-4564-A4BD-7278983F4F07}
static const GUID guid_cfg_bpm = { 0x84053460, 0x367b, 0x4564, { 0xa4, 0xbd, 0x72, 0x78, 0x98, 0x3f, 0x4f, 0x7 } };
cfg_uint cfg_bpm(guid_cfg_bpm, 126);

UINT_PTR ptr2;
bool timer_started = false;
bool cfg_bpm_on = false;

// {55B3C05D-059B-4038-89EC-D259C91C688B}
static const GUID guid_cfg_beep_on = { 0x55b3c05d, 0x59b, 0x4038, { 0x89, 0xec, 0xd2, 0x59, 0xc9, 0x1c, 0x68, 0x8b } };
cfg_bool cfg_beep_on(guid_cfg_beep_on, false);

/** Our window class */
class metronome_window : public uie::container_ui_extension
{

public:

	metronome_window();
	~metronome_window();

	virtual const GUID & get_extension_guid() const;
	virtual void get_name(pfc::string_base & out)const;
	virtual void get_category(pfc::string_base & out)const;
	unsigned get_type() const;
	static void update_all_window_frames();
	static pfc::list_t<HWND> g_notify_list;

private:

	/** Our window procedure */
	LRESULT on_message(HWND wnd,UINT msg,WPARAM wp,LPARAM lp);

	virtual class_data & get_class_data()const;
	virtual void get_menu_items(uie::menu_hook_t & p_hook);

	static const GUID g_extension_guid;

public:

	/** Our child window */
	HWND wnd_static;
};

VOID CALLBACK Beat(
    HWND hwnd,
    UINT message,
    UINT idEvent2,
    DWORD dwTime)
{
	if (cfg_bpm_on)
	{
		cfg_bpm_on = false;
		if (cfg_beep_on) Beep(440,25);
	}
	else
	{
		cfg_bpm_on = true;
	}
	metronome_window::update_all_window_frames();
}

class menu_node_reset1 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Larghissimo (38 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 38;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset1(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset2 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Largo (44 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 44;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset2(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset3 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Larghetto (49 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 49;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset3(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset4 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Lento (53 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 53;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset4(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset5 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Adagietto (57 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 57;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset5(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset6 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Adagio cantabile (59 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 59;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset6(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset7 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Adagio ma non troppo (60 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 60;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset7(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset8 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Adagio (64 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 64;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset8(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset9 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Adagio maestoso (68 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 68;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset9(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset10 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Grave (67 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 67;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset10(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset11 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Andante sostenuto (71 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 71;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset11(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset12 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Andante un poco tranquillo (75 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 75;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset12(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset13 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Andante (80 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 80;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset13(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset14 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Andantino (88 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 88;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset14(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset15 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Moderato (97 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 97;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset15(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset16 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Allegretto (109 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 109;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset16(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset17 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Allegro (126 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 126;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset17(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset18 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Allegro risoluto (145 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 145;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset18(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset19 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Vivace, vivo (169 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 169;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset19(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset20 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Vivacissimo (176 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 176;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset20(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset21 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Presto (184 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 184;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset21(metronome_window * wnd) : p_this(wnd) {};
};

class menu_node_reset22 : public ui_extension::menu_node_command_t
{
	service_ptr_t<metronome_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Prestissimo (208 bpm)";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		cfg_bpm = 208;
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
	}
	menu_node_reset22(metronome_window * wnd) : p_this(wnd) {};
};

void metronome_window::get_menu_items(uie::menu_hook_t & p_hook)
{
	p_hook.add_node(new menu_node_reset1(this));
	p_hook.add_node(new menu_node_reset2(this));
	p_hook.add_node(new menu_node_reset3(this));
	p_hook.add_node(new menu_node_reset4(this));
	p_hook.add_node(new menu_node_reset5(this));
	p_hook.add_node(new menu_node_reset6(this));
	p_hook.add_node(new menu_node_reset7(this));
	p_hook.add_node(new menu_node_reset8(this));
	p_hook.add_node(new menu_node_reset9(this));
	p_hook.add_node(new menu_node_reset10(this));
	p_hook.add_node(new menu_node_reset11(this));
	p_hook.add_node(new menu_node_reset12(this));
	p_hook.add_node(new menu_node_reset13(this));
	p_hook.add_node(new menu_node_reset14(this));
	p_hook.add_node(new menu_node_reset15(this));
	p_hook.add_node(new menu_node_reset16(this));
	p_hook.add_node(new menu_node_reset17(this));
	p_hook.add_node(new menu_node_reset18(this));
	p_hook.add_node(new menu_node_reset19(this));
	p_hook.add_node(new menu_node_reset20(this));
	p_hook.add_node(new menu_node_reset21(this));
	p_hook.add_node(new menu_node_reset22(this));
};

metronome_window::metronome_window() : wnd_static(NULL)
{}

metronome_window::~metronome_window()
{}

void metronome_window::update_all_window_frames()
{
	unsigned n , count = g_notify_list.get_count();

	for (n=0; n<count; n++)
	{
		HWND wnd = g_notify_list[n];
		if (wnd)
		{
			SetWindowPos(wnd,0,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_FRAMECHANGED);
			RedrawWindow(wnd,0,0,RDW_ERASENOW|RDW_ALLCHILDREN|RDW_INVALIDATE|RDW_UPDATENOW);
		}
	}
}

LRESULT metronome_window::on_message(HWND wnd,UINT msg,WPARAM wp,LPARAM lp)
{
	HDC display;
	PAINTSTRUCT ps;
	RECT rc;
	GetClientRect(wnd, &rc);

	RECT rc1 = {0,0,rc.right/2,rc.bottom};
	RECT rc2 = {rc.right/2,0,rc.right,rc.bottom};

	switch (msg)
	{
	case WM_CREATE:
	{
		g_notify_list.add_item(wnd);
		/** Create a static window*/
		wnd_static = CreateWindowEx(
		                 WS_EX_STATICEDGE,
		                 WC_STATIC,
		                 _T("Metronome"),
		                 WS_CHILD | WS_VISIBLE,
		                 0,
		                 0,
		                 rc.right,
		                 rc.bottom,
		                 wnd,
		                 HMENU(0),
		                 core_api::get_my_instance(),
		                 NULL);
	}
	break;
	case WM_SIZE:
		SetWindowPos(wnd_static, 0, 0, 0, LOWORD(lp), HIWORD(lp), SWP_NOZORDER);
		break;
	case WM_PAINT:
		display = BeginPaint(wnd_static, &ps);
		{
			wchar_t istr[32];
			_itow_s(cfg_bpm, istr, 10);
			FillRect(display, &rc1, CreateSolidBrush(RGB(255,255,255)));
			if (cfg_bpm < 100)
			{
				DrawText(display,istr,2,&rc1,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			if (cfg_bpm >= 100)
			{
				DrawText(display,istr,3,&rc1,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			if (cfg_bpm_on)
			{
				FillRect(display, &rc2, CreateSolidBrush(RGB(255,255,255)));
			}
			else
			{
				if (timer_started)
				{
					FillRect(display, &rc2, CreateSolidBrush(RGB(255,0,0)));
				}
				else
				{
					FillRect(display, &rc2, CreateSolidBrush(RGB(220,220,220)));
				}
			}
		}
		EndPaint(wnd_static, &ps);
		break;
	case WM_DESTROY:
		/** DefWindowProc will destroy our child window. Set our window handle to NULL now. */
		wnd_static=NULL;
		g_notify_list.remove_item(wnd);
		break;
	case WM_LBUTTONDOWN:
		if (!timer_started)
		{
			if (cfg_beep_on) Beep(440,25);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
			timer_started = true;
			metronome_window::update_all_window_frames();
		}
		else
		{
			KillTimer(NULL,ptr2);
			cfg_bpm_on = false;
			timer_started = false;
			metronome_window::update_all_window_frames();
		}
		break;
	case WM_MBUTTONDOWN:
		if (!cfg_beep_on)
		{
			cfg_beep_on = true;
		}
		else cfg_beep_on = false;
		break;
	case WM_MOUSEWHEEL:
		if ((short)GET_WHEEL_DELTA_WPARAM(wp) > 0)
		{
			cfg_bpm = cfg_bpm + 1;
			if (cfg_bpm > 250) cfg_bpm = 250;
		}
		if ((short)GET_WHEEL_DELTA_WPARAM(wp) < 0)
		{
			cfg_bpm = cfg_bpm - 1;
			if (cfg_bpm < 20) cfg_bpm = 20;
		}
		if (timer_started)
		{
			KillTimer(NULL,ptr2);
			ptr2 = SetTimer(NULL,ID_TIMER2,30000 / cfg_bpm,(TIMERPROC)Beat);
		}
		metronome_window::update_all_window_frames();
		break;
	}
	return DefWindowProc(wnd, msg, wp, lp);

}

metronome_window::class_data & metronome_window::get_class_data() const
{
	__implement_get_class_data(_T("{AC3D8811-EB80-4D32-99A8-FEFAC27720CC}"), true);
}

const GUID & metronome_window::get_extension_guid() const
{
	return g_extension_guid;
}

void metronome_window::get_name(pfc::string_base & out)const
{
	out.set_string("Metronome");
}
void metronome_window::get_category(pfc::string_base & out)const
{
	out.set_string("Panels");
}
unsigned metronome_window::get_type() const
{
	return uie::type_toolbar;
}


// {AC3D8811-EB80-4D32-99A8-FEFAC27720CC}
const GUID metronome_window::g_extension_guid = { 0xac3d8811, 0xeb80, 0x4d32, { 0x99, 0xa8, 0xfe, 0xfa, 0xc2, 0x77, 0x20, 0xcc } };


uie::window_factory<metronome_window> g_metronome_window_factory;
pfc::list_t<HWND> metronome_window::g_notify_list;

//EOF