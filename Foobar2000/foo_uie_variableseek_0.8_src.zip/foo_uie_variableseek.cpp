#include "../SDK/foobar2000.h"
#include "../helpers/helpers.h"
#include <commctrl.h>
#include <windowsx.h>

#include "../columns_ui-sdk/ui_extension.h"


/** Declare some information about our component */
DECLARE_COMPONENT_VERSION(
	"Variable Seek",
	"0.8",
	"Variable Seek v0.8\n"
	"Created by grimes\n"
	"compiled: " __DATE__ " " __TIME__ "\n"
	"with Panel API version: " UI_EXTENSION_VERSION "\n"
	"++: left mouse button \n"
	"--: middle mouse button \n"
	"seek: mouse wheel"
);

VALIDATE_COMPONENT_FILENAME("foo_uie_variableseek.dll");


double seek = 5;

/** Our window class */
class variableseek_window : public uie::container_ui_extension
{

public:

	variableseek_window();
	~variableseek_window();

	virtual const GUID & get_extension_guid() const;
	virtual void get_name(pfc::string_base & out)const;
	virtual void get_category(pfc::string_base & out)const;
	unsigned get_type() const;
	static void update_all_window_frames();
	static pfc::list_t<HWND> g_notify_list;

private:

	/** Our window procedure */
	LRESULT on_message(HWND wnd,UINT msg,WPARAM wp,LPARAM lp);

	virtual class_data & get_class_data()const;
	virtual void get_menu_items(uie::menu_hook_t & p_hook);

	static const GUID g_extension_guid;

public:

	/** Our child window */
	HWND wnd_static;
};

class menu_node_reset : public ui_extension::menu_node_command_t
{
	service_ptr_t<variableseek_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Set seek by 5 second";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		seek = 5;
		variableseek_window::update_all_window_frames();
	}
	menu_node_reset(variableseek_window * wnd) : p_this(wnd) {};
};

class menu_node_ahead : public ui_extension::menu_node_command_t
{
	service_ptr_t<variableseek_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Set seek by 30 seconds";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		seek = 30;
		variableseek_window::update_all_window_frames();
	}
	menu_node_ahead(variableseek_window * wnd) : p_this(wnd) {};
};

class menu_node_back : public ui_extension::menu_node_command_t
{
	service_ptr_t<variableseek_window> p_this;

public:

	virtual bool get_display_data(pfc::string_base & p_out,unsigned & p_displayflags) const
	{
		p_out = "Set seek by 60 seconds";
		p_displayflags= 0;
		return true;
	}
	virtual bool get_description(pfc::string_base & p_out) const
	{
		return false;
	}
	virtual void execute()
	{
		seek = 60;
		variableseek_window::update_all_window_frames();
	}
	menu_node_back(variableseek_window * wnd) : p_this(wnd) {};
};

void variableseek_window::get_menu_items(uie::menu_hook_t & p_hook)
{
	p_hook.add_node(new menu_node_reset(this));
	p_hook.add_node(new menu_node_ahead(this));
	p_hook.add_node(new menu_node_back(this));
};

variableseek_window::variableseek_window() : wnd_static(NULL)
{}

variableseek_window::~variableseek_window()
{}

void variableseek_window::update_all_window_frames()
{
	unsigned n , count = g_notify_list.get_count();

	for (n=0; n<count; n++)
	{
		HWND wnd = g_notify_list[n];
		if (wnd)
		{
			SetWindowPos(wnd,0,0,0,0,0,SWP_NOOWNERZORDER|SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER);
			RedrawWindow(wnd, 0, 0, RDW_ERASENOW|RDW_ALLCHILDREN|RDW_INVALIDATE|RDW_UPDATENOW);
		}
	}
}


LRESULT variableseek_window::on_message(HWND wnd,UINT msg,WPARAM wp,LPARAM lp)
{
	HDC display;
	PAINTSTRUCT ps;
	RECT rc;
	GetClientRect(wnd, &rc);

	switch (msg)
	{
	case WM_CREATE:
	{
		g_notify_list.add_item(wnd);
		/** Create a static window*/
		wnd_static = CreateWindowEx(
		                 WS_EX_STATICEDGE,
		                 WC_STATIC,
		                 _T("Seek"),
		                 WS_CHILD | WS_VISIBLE,
		                 0,
		                 0,
		                 rc.right,
		                 rc.bottom,
		                 wnd,
		                 HMENU(0),
		                 core_api::get_my_instance(),
		                 NULL
		             );
	}
	break;
	case WM_SIZE:
		SetWindowPos(wnd_static, 0, 0, 0, LOWORD(lp), HIWORD(lp), SWP_NOZORDER);
		break;
	case WM_PAINT:
		display = BeginPaint(wnd_static, &ps);
		{
			wchar_t istr[32];
			wchar_t a[7] = L"s";
			_itow_s(int(seek), istr, 10);
			wcscat_s(istr, a);
			FillRect(display, &rc, CreateSolidBrush(RGB(255,255,255)));
			if (seek < 10 && seek >= 0)
			{
				DrawText(display,istr,2,&rc,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			else if (seek >= 10 && seek < 100)
			{
				DrawText(display,istr,3,&rc,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			else if (seek > -10 && seek < 0)
			{
				DrawText(display,istr,3,&rc,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			else if (seek <= -10 && seek > -100)
			{
				DrawText(display,istr,4,&rc,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			else if (seek <= -100)
			{
				DrawText(display,istr,5,&rc,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
			else
			{
				DrawText(display,istr,4,&rc,DT_VCENTER|DT_CENTER|DT_SINGLELINE);
			}
		}
		EndPaint(wnd_static, &ps);
		break;
	case WM_DESTROY:
		/** DefWindowProc will destroy our child window. Set our window handle to NULL now. */
		wnd_static=NULL;
		g_notify_list.remove_item(wnd);
		break;
	case WM_LBUTTONDOWN:
		++seek;
		if (seek > 999) seek = 999;
		variableseek_window::update_all_window_frames();
		break;
	case WM_MBUTTONDOWN:
		--seek;
		if (seek < 1) seek = 1;
		variableseek_window::update_all_window_frames();
		break;
	case WM_MOUSEWHEEL:
		if ((short)GET_WHEEL_DELTA_WPARAM(wp) > 0)
		{
			static_api_ptr_t<playback_control>()->playback_seek_delta(seek);
			
			break;
		}
		if ((short)GET_WHEEL_DELTA_WPARAM(wp) < 0)
		{
			static_api_ptr_t<playback_control>()->playback_seek_delta(-seek);
			break;
		}
	}
	return DefWindowProc(wnd, msg, wp, lp);
}


variableseek_window::class_data & variableseek_window::get_class_data() const
{
	__implement_get_class_data(_T("{D544633C-9183-4642-A158-7D0EAF6A3D1C}"), true);
}

const GUID & variableseek_window::get_extension_guid() const
{
	return g_extension_guid;
}

void variableseek_window::get_name(pfc::string_base & out)const
{
	out.set_string("Variable seek");
}
void variableseek_window::get_category(pfc::string_base & out)const
{
	out.set_string("Panels");
}
unsigned variableseek_window::get_type() const
{
	return uie::type_toolbar;
}


// {D544633C-9183-4642-A158-7D0EAF6A3D1C}
const GUID variableseek_window::g_extension_guid = { 0xd544633c, 0x9183, 0x4642, { 0xa1, 0x58, 0x7d, 0xe, 0xaf, 0x6a, 0x3d, 0x1c } };


uie::window_factory<variableseek_window> g_variableseek_window_factory;
pfc::list_t<HWND> variableseek_window::g_notify_list;

//EOF